# Stage 1: Find the opportunities

An optional opening stage for when there's no ask yet. The researcher wants
to propose research rather than wait for a request, and needs candidates
that serve users and the company at the same time.

## Goal

A short list of research opportunities, each with the user need it serves,
the company goal it serves, what's already known, and a rough cost. The
researcher picks one or two to take to stakeholders.

## When to use it

- Planning a quarter or a roadmap of research.
- A new researcher getting oriented in a team or company.
- A PM asks "what should we be looking into?"
- A researcher wants to show strategic value beyond answering tickets.

Skip it when there's already a decision waiting. Go to stage 2.

## Inputs

Whatever exists. None of these is required.

- The team profile: company goals and metrics, current bets, CUJs,
  personas, market context.
- The research library and past study records.
- Market research and market needs: analyst reports, competitor moves,
  win/loss data, market surveys, from the marketing or strategy team.
- Signals from partners: support ticket themes, analytics on where
  journeys stall, sales objections, renewal risks.
- The product roadmap, if it's shared.

## Before you build

Ask for whatever on this list isn't already in the study record, the
conversation or files you can reach, in one message, before you build
(`operating.md`, "Gather context before you build").
This list is the floor: add the questions this particular study or task
raises, within the same six.

**Minimum to draft:** the company's goals or bets, or the area the
researcher wants opportunities in. Without one of them, any brief is a
guess at what matters.

- The company's goals or bets for this period, in the company's own names.
- Which products, areas or users are in scope.
- Who the briefs are for. Guess what they'd do with a good one (fund a
  study, add it to a roadmap, start a conversation) rather than asking.
- What signals the researcher can share or point you to: support themes,
  analytics, sales notes, market research.

## What to do

0. **Collect with the guide.** Open `evidence-where-to-look.md`. Use
   whatever Magpie can reach in this setup (files, connectors, web) first
   and say so; then give the researcher the two or three places to look
   for each of the three sides below and the paste-in format. A morning,
   not a literature review. If the market side is thin after the team's
   own material, offer a wider web search once ("Wider web search" in
   `evidence-where-to-look.md`); the researcher decides.
1. **Lay out what the company is trying to do.** The goals and metrics in
   the team profile's own words. If there's no profile, ask for the two or
   three goals leadership talks about most, and mark anything uncertain as
   an assumption.
2. **Lay out what the market is saying.** What market research or market
   needs the company already has: who's buying, who's switching, what
   competitors are betting on, what customers ask for that nobody builds.
   Log each source with date and confidence, rated with the five
   questions in `methods-evidence-review.md` ("Judging an old study"),
   and for web sources "Judging a web source" in
   `evidence-where-to-look.md`. Market research describes markets and
   buyers; it's indirect evidence about users. Say so.
3. **Lay out what users are saying.** The library, support themes,
   analytics stalls, sales objections. Where do users struggle or go
   without?
4. **Find the overlaps.** An opportunity is where a user need, a company
   goal and a market signal line up, and the team doesn't yet know enough
   to act. Draft each one in one line: *"[Users] can't [do job] well, which
   touches [goal or metric], and [market signal]. We don't know [gap]."*
5. **Score roughly.** For each: how much it could matter to users, how
   much to the company goal, how little we know, how cheaply it could be
   studied. Plain words, not a formula. Pick the top three to five.
6. **Draft the pitch.** For each chosen opportunity, a short paragraph the
   researcher can take to the PM or the leadership team: the gap, who it
   affects, the decision it would inform, what a study would cost and
   return. Use `templates-opportunity-brief.md`. If the team writes hills
   (`workshops-stakeholder-workshops.md`, "Hills, for teams that use
   them"), add a draft one to the brief; otherwise leave that line out.
7. **Check the sources before you show it.** Every claim from a
   document in the list and the briefs carries a source receipt
   (`operating.md`, "Point to the exact words"). Then run the source
   check (`review-independent-review.md`, "The source check at stages 1
   and 2") and fix what it finds before the researcher sees the draft.
   In the review ask, name the two or three claims the picks rest on
   most, with their receipts, for the researcher to open and read
   themselves.

## What to draft

- An opportunity list (three to five, scored in plain words).
- One opportunity brief per chosen item.
- Evidence log entries for every market and partner source used.

## Challenge

Usually the **decision test** turned forward: "If this study came back
with a clear answer, who would act on it, and what would they do?" An
opportunity no team would act on is a curiosity, not a study.

Or the **evidence test**: "Marketing's survey says buyers want X. Buyers
aren't users. What do we know about what users do when they lack X?"

## Exit criteria

- Opportunities named with the user need, the company goal, the market
  signal and the gap, each labeled by source.
- Top three to five picked, with a plain-words reason.
- Every claim from a document has a source receipt or is marked an
  [assumption], and the source check has run.
- A brief drafted for each, with a proposed decision and the team that would make it.

## Pitfalls

- Opportunities that are really the roadmap with a research label on.
- Treating market research or buyer surveys as evidence about users.
- Scoring with a formula that hides judgment behind numbers.
- A list of twelve. Nobody reads past five.
- Proposing research for a decision nobody will make.
- A number or a quote that sounds right but isn't in any document the
  researcher shared. The receipt and the source check are there to
  catch it.

---

Part of Magpie version 2026-11-18, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.
