# Study record: [study name]

One file for the whole study. Every stage reads it and adds to it. Save it
somewhere your team can find it, and paste or upload it to pick up where you
left off in any assistant.

Last updated: [date]

## Questions for you to answer

What Magpie needs from the researcher right now, and nothing else. When a
question is answered, it comes off this list and the answer goes in its
section. When nothing is open, write "Nothing right now."

1. [the question, in a line; required ones first, then "(optional)" ones, then the review ask last: "Reply yes once you've reviewed [output]."]

## Where we are

Read this first when the record is pasted into a new conversation. Magpie
updates it whenever the stage changes or something here is settled.

- **Stage:** [1–8, as a plain phrase too: "3, framing the problem"]
- **Next step:** [what happens next, and who does it]
- **Waiting for the researcher's yes:** [outputs, or "nothing"]
- **Settings:** challenge level [standard / push me / light] · personality [on / off] · your-turn steps [offered / stopped at the researcher's request] · readout and report template [the team's: name or link / none: house style / not asked yet] · spelling and dates [American English / the researcher's variety, such as British English] · note before the first transcript [given / not yet]

**Your-turn steps and challenges.** Each is offered once per study.

| Step | Status |
| --- | --- |
| Stage 3 your turn: decision, primary question, team's questions, assumptions | not yet / done by the researcher / handed back |
| Stage 7 your turn: the researcher's patterns | not yet / done / handed back / not needed |
| Stage 8 your turn: what each partner should do | not yet / done / handed back / already in the material |
| Stage 8 impact log row | not yet / offered and made / offered and skipped |
| Stage 8 researcher debrief | not yet / offered and made / offered and skipped |
| Challenges given | [stage: the challenge in a few words, and answered / skipped / handled] |

## Product

Optional. What's being studied, so every stage works from the same
picture. Offered early, filled from the team profile, product docs or the
researcher, with guesses marked [assumption]. If the researcher leaves it
out, write "not added" and delete the lines below.

- **Product:** [name, and what it is in one plain sentence]
- **What it does:** [the main things people do with it, in their terms]
- **Part under study:** [the feature, flow or screen; "the whole product" is fine]
- **End users:** [who uses it day to day, by what they do and where; people who stopped using it, if they matter]
- **Buyers or admins, if different:** [who chooses, pays for or sets it up]
- **Where it stands:** [idea, prototype, beta or live; which platforms]
- **Recent changes:** [releases or redesigns that could date earlier evidence]
- **Source:** [team profile, product docs, the researcher, or [assumption]]

## Decision

- **Decision:** [What will be decided, in one sentence]
- **Who decides:** [the team or group that makes the call]
- **Deadline:** [When it has to be made]
- **Options on the table:** [The choices being weighed]

## Business context

- **Goal or metric this moves:** [The company goal or metric at stake]
- **Where it starts:** [the metric's value now, and when it was measured; or "[unknown: ask the team that owns it]"]
- **Who can tell us later:** [the team or role that owns the number, not a person's name]
- **Cost of getting it wrong:** [What happens if the decision goes the wrong way]
- **Decision risk:** [low / medium / high, because [can it be undone, how quickly, who and what it touches]; or [assumption]]
- **Who else cares:** [Stakeholders beyond the team that decides]
- **Job:** [what the user is trying to get done, in their terms]
- **Journey and step:** [which CUJ or journey, which step; "none tracked" is fine]
- **Persona or group:** [the team's name, with the behavior that defines them]
- **Upstream and downstream:** [what feeds this piece, what depends on it, who else touches it]

## Hypotheses

What the team believes going in. The study tests these; it doesn't set out
to prove them.

| Hypothesis | Whose belief | What would change it | Status |
| --- | --- | --- | --- |
| | | | open / supported / contradicted / no evidence |

## Evidence log

What we already know. "No prior evidence found" is a valid entry.

| Source | Date | Method | What it says | Where and exact words | Confidence | Still valid? |
| --- | --- | --- | --- | --- | --- | --- |
| | | | | | | |

Where and exact words: the place in the source (page, slide or section
heading, only if the source shows it) and a short quote copied from it.
"No source found" means the row is an assumption.

Confidence: **direct** (from users, by a sound method), **indirect** (secondhand,
such as a field rep's summary), **anecdotal** (one-off, unverified), or
**unverified lead** (who said it, how many, or how it was gathered isn't
known yet; kept out of "what we know" and out of findings).

For a claim passed on from memory or secondhand, "What it says" also
records who said it (role or segment), how many and how it was
gathered, with "not known" for any that's still missing.

## Research questions

Each question names the decision it serves.

1. **Primary:** [The question that most changes the decision]
2. **Secondary:** [Questions that sharpen the answer]

## Assumptions and risks

Known assumptions, plus every challenge that was skipped and why.

| Assumption or risk | Source | If wrong | Status |
| --- | --- | --- | --- |
| | | | open / handled / accepted |

## Approach

- **Method:** [Method chosen]
- **Why this method:** [One or two sentences]
- **What the team will get:** [One line, in words they could repeat]
- **Sample:** [Who, how many, how recruited]
- **Rigor for this risk:** [why this study is enough for the decision risk; any floor problem and the smaller question offered]
- **Trade-offs accepted:** [What this approach won't tell us]
- **Partner data requested:** [Team, what, status]

## Participants

Who the findings should speak for, and how well each participant fits.

**Target users:** [who the study is meant to speak for]

| Code | Role | Segment | Fit to target users |
| --- | --- | --- | --- |
| P1 | | | matches / partly: [how] / stand-in: [for whom] / not known |

## Instruments

- [Guide, script or survey: link or file name]

## Themes

**Coverage:** [what was read in full and coded start to end; what was
left out as logistics; anything not read, and whether the researcher
chose to go ahead without it]

**Guide-question sweep:** [each guide question two or more participants
answered is used by a finding, a single voice or "Coded but not
reported"; list any that isn't, and why; or "not run: no guide"]

**Researcher's patterns** (what they saw before coding, in their words):

-

**Theme review.** Riskiest first. The researcher's decision on each theme
before findings are written.

| Theme | Count and participants | Risk | Decision |
| --- | --- | --- | --- |
| | | | keep / change / split / drop |

Merged and dropped codes, and why:

-

## Findings

Each finding is a claim with its evidence, including what cuts against it.
Every count lists the participants and lines behind it: "3 of 8 (P1 06,
P5 06, P7 06)".

| Finding | Supporting evidence | Contradicting evidence | Strength and confidence line | Enough for the decision? |
| --- | --- | --- | --- | --- |
| | [codes, each tagged seen / past time / opinion] | | strong / moderate / weak: [count and segments; fit; seen or said; other sources agree / disagree / none yet] | yes / with a caveat: [what] / no: [what would make it enough] |

Strength: **strong** (consistent across most participants or statistically
reliable), **moderate** (clear pattern with exceptions), **weak** (few
participants or mixed signals). Behavior that rests only on opinions, or
a finding that rests only on stand-ins, is moderate at most. "No other
sources yet" lowers nothing (`lenses-confidence-and-priority.md`).

Each theme's finding includes one "what explains it" sentence from
participants' own reasons, with receipts, or says none were given.

### Single voices worth noting

Points one participant made that are specific and add something no theme
covers. One person's view each, not a theme.

- [P# line]: [the point]

### Coded but not reported

Codes no finding, single voice or "also noticed" line uses.

- [code]: [count] ([participants])

### Connections checked

Every background and warm-up code laid against each participant attribute
(`stages-07-analyze.md`, step 5a). List each pair checked, even with
nothing found.

| Background code | Attribute | What was found |
| --- | --- | --- |
| | | [pattern with count and participants] / nothing |

## Key findings: what would prove them wrong

For the findings the decision rests on, three at most. The researcher
goes first at the theme review (`stages-07-analyze.md`, steps 8 and
11a).

| Finding | Would be wrong if | Seen in the material? | Other explanations | Ruled out or still open |
| --- | --- | --- | --- | --- |
| | | no / yes: [codes and lines] | | ruled out: [codes and lines] / still open: [what would settle it] |

**Written by:** [the researcher, with Magpie's additions marked / Magpie, at the researcher's "you do it"]

## Priority

How much each finding matters, kept apart from how sure we are. Listed in
priority order.

| Finding | Impact and why | Reach and why | Priority | Check next? |
| --- | --- | --- | --- | --- |
| | high / medium / low: [on users; on the decision] | wide / some / narrow: [in the study; outside it, or "not known"] | high / medium / low | yes: [what would make us surer] / no |

**Order:** [agreed with the researcher on [date] / Magpie's draft, not yet
reviewed]

## Recommendations

| Action | Teams involved | Answers question | Serves decision | Confidence |
| --- | --- | --- | --- | --- |
| | | | | |

## Outputs

Everything Magpie drafted for this study, and whether the researcher has
reviewed it. An output stays "not yet" until the researcher says yes.

| Output | Version or date | Reviewed |
| --- | --- | --- |
| | | yes, [date] / not yet |

## Change log

| Date | What changed | Why |
| --- | --- | --- |
| | | |

---

Part of Magpie version 2026-11-20, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.
