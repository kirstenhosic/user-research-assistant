# Research report: [study name]

**Author:** [researcher] · **Date:** [date] · **For:** [the team or group] ·
**Study record:** [link]

A report is read by people who weren't in the readout and by people who come
back to it months later. It can go deeper than the readout, but it's still
written for a PM, designer or engineer, not for another researcher. Ten
pages or fewer, not counting images and the appendix. Less is better as long
as the background, the findings with their evidence, and the recommendations
are clear.

Formatting follows the team's template if there is one, and
`templates-house-style.md` for anything it leaves open. The headings below
are the ones Magpie uses. Where the document tool
supports it, the contents list links to each section; Magpie writes it as
Markdown links to the headings so it works in most tools.

## Contents

- [Summary](#summary)
- [Why we did this](#why-we-did-this)
- [What we did](#what-we-did)
- [Top findings](#top-findings)
- [Findings in detail](#findings-in-detail)
- [Other findings](#other-findings)
- [Recommendations](#recommendations)
- [Next steps](#next-steps)
- [Limits](#limits)
- [Glossary](#glossary)
- [Appendix](#appendix)

## Summary

Five to eight sentences, drawn from this study: its focus, its goals and
what it found. Things to look for, where the study speaks to them: the
answer the evidence supports, how confident we are, what it means for the
product, what it means for the business, and the main recommendation. Not
every summary needs all of them. Someone with two minutes reads only this.

## Why we did this

- **The product:** [optional: what it is, what it does, the part studied, and who
  uses it; who buys or sets it up, if different]
- **The decision:** By [when], the team will decide [what], choosing
  between [options].
- **The business need:** [goal or metric at stake; cost of getting it
  wrong]
- **What we already knew:** [two or three lines; link to prior research or
  the evidence log]
- **The questions:** [primary, then secondary, each in plain words]
- **Where it sits:** [the job, the journey step, the persona or group, in
  the team's names]

## What we did

One short paragraph: [method] with [N] [who], recruited by [how], [dates],
and why this method for these questions. Link to the plan and instruments
in the appendix. No timeline, no recruiting mechanics, no consent detail
here; those live in the study record and the appendix.

## Top findings

Never more than five, the highest-priority findings for this decision, in
priority order. At least one answers the primary research question; if
the data didn't answer it, one line says so and why. One or two lines
each, with the question it answers, priority, confidence and whether it's
enough for this decision. A not-enough finding says what would
make us surer and roughly what that costs; a high-priority finding with
weak confidence is marked "check next".

1. **[Finding]** · Priority: [high / medium / low] ([impact], [reach]) · Confidence: [strong / moderate / weak] ([why]) · [enough / enough if [caveat] / not enough: [what would make us surer]]
2. …

## Findings in detail

One section per top finding, same order. More depth than the readout:
the evidence, the counter-evidence, what it means, and where to look for
more. Images where they help: a screenshot of the moment people stalled, a
chart of task success, a photo of the workaround. Each image has a one-line
caption saying what to see in it.

### Finding 1: [claim in plain words]

**Priority:** [high / medium / low]. Impact: [what happens to people who hit it, and what it means for the decision]. Reach: [how many target users, how often; say if it isn't known outside the study].
**Confidence:** [strong / moderate / weak], because [count and segments; fit to the target users; seen, past time or opinion; other sources agree, disagree, or this is the first study on it].
**Answers:** [question].

[Evidence with numbers and participant codes. Two or three quotes at most,
each with its code and descriptor: "— P3, finance manager, SMB".]

[Image with caption, if it helps.]

**What cuts against it:** [participants who didn't fit, what they did or
said.]

**What would change this:** [what would prove it wrong, and the other
explanations: each ruled out, with the evidence, or still open, with what
would settle it.]

**What it means:** [for the decision, two or three sentences.]

**More:** [link to the appendix section, clips, or the study record.]

### Finding 2: …

## Other findings

Every finding that met the evidence bar but isn't in the top five, in
priority order, one line each with priority and confidence, tagged "unexpected" where it fell outside the
research questions. Nothing that passed the evidence bar is left out; a
finding whose evidence didn't hold is in the appendix with the reason.

## Recommendations

Detailed. Each is an action, the teams it touches, the finding it rests
on, the goal or metric it moves, and how confident we are. Number the
actions in the priority order of the findings they rest on, unless the
researcher orders them differently. Add a sentence or two under the table where an
action needs explaining.
Name the teams each action touches, not a person. Who takes each action
is often for the teams to agree together; name a person only when the
researcher asks for it.

| Action | Teams involved | Rests on | Moves | Confidence |
| --- | --- | --- | --- | --- |
| 1. [action] | [teams] | Finding [n] | [goal or metric] | |

[Notes on any recommendation that needs them.]

## Next steps

Magpie drafts all four from the findings and any relevant context in the
record (the decision and its date, partners, open risks), and labels them
"draft" until the researcher has reviewed and edited them. Name the teams
involved, not one person, unless the researcher asks for a name.

- **What happens now:** [step, the teams involved, by when]
- **Open questions:** [question → what would answer it: more research, a
  decision, or nothing yet]
- **Researcher's next steps:** [follow-up research, check-ins with
  partners, what the researcher will do next]
- **How we'll know it worked:** [when the team looks back, who looks with
  the researcher, and the sign that would show the change worked]

## Limits

Always in the report, briefly: sample gaps, what the method can't say,
challenges skipped during the study (from the record's risks). Two to five
lines. This is the durable record, so it stays even if the readout left it
out.

## Glossary

Only if the report uses terms the reader may not know. One line each.
Skip the section if there's nothing to define.

## Appendix

Linked from the contents and from the findings. Not counted in the ten
pages.

- Participant profile
- Research plan, instruments (guide, script, survey)
- Full findings with coding frame and all supporting quotes
- Partner data used, with source and date
- Consent, data handling and retention
- Independent review: what it found and what changed
- How AI was used (below)
- Library entries written from this study
- Links to recordings, clips and raw material (access-controlled)

### How AI was used

Five or six lines, written from the study record, so a stakeholder can
see which parts an AI drafted and which a person did or checked. Plain
facts, no reassurance.

- **Assistant:** Magpie, running in [the assistant, if known].
- **What it drafted:** [outputs from the record's Outputs table, such as
  the plan, the guide, the findings, this report]
- **What the researcher did:** [the your-turn steps they took, from the
  record; the theme decisions; each output's review date, or "not yet
  reviewed"]
- **Checks:** quotes and counts checked [by code / by hand]; independent
  review by a separate AI pass, [what it found and what changed]. The
  reviewer is a model too and can be wrong.
- **Other AI tools in the study:** [an AI moderator, transcription or
  summary tool, if the record names one; otherwise leave the line out]
- **Before acting on it:** AI can make mistakes. Check quotes and
  findings against the raw material before acting on them.

---

Part of Magpie version 2026-11-04, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.
