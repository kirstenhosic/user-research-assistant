# Stage 4: Choose the approach

Pick the cheapest method that can answer the primary question well enough
for the decision.

## Goal

A method, a rough sample, and the trade-offs accepted, written so the
people making the decision could understand why.

## Inputs

- The study record through stage 3.
- Constraints: deadline, budget, access to participants, tools available.
- Anything partner teams can provide (analytics, support data).

## Before you build

Ask for whatever on this list isn't already in the study record, the
conversation or files you can reach, in one message, before you build
(`operating.md`, "Gather context before you build").
This list is the floor: add the questions this particular study or task
raises, within the same six.

**Minimum to draft:** the primary research question, and roughly how
long the study can take.

- When findings are due (the decision date is in the record from stage
  3; the study needs to end before it).
- Budget, including incentives and tools.
- How the team can reach participants.
- Tools available for sessions, surveys or analysis.
- Any method someone expects or has ruled out.
- Partner data the team can get (analytics, support, sales).
- Where the product stands (an idea, being designed, or live), if the
  Product section doesn't already say.

**Your turn** (`operating.md`, "Your turn"). In the same message, ask the
researcher which method they'd pick and why, before you say what you'd
recommend. Give it as one numbered item with labeled fill-in lines.
Together they count as one of the six. For example:

> 1. Your turn: which method would you pick for this, and why? Rough is
>    fine. Copy the labels and fill them in (required):
>    Method: ...
>    Why it fits the primary question: ...
>    What it can't tell you (or "not sure"): ...

Choosing the method is core research craft, and Magpie's pick would
anchor theirs, so don't offer your guess or hint at a method first. If
they already named a method ("I'd rather do a survey"), that's their
pick: ask only for the other two lines. If they say "not sure" or "you
do it", recommend one yourself as below.

**When their pick comes back.** Read it against step 1 (the kind of
question, say or do, where the product stands, the setting). If it can't
answer the primary question well (a survey for a "why", a focus group to
judge usability, eight interviews for "how many"), hand it back once
(`operating.md`, "Your turn"): name the mismatch in a line, give the
principle in a sentence, and give a hint by pointing at step 1 ("Your
primary question starts with 'why'. Which methods let you hear or watch
the reasons?"), not the method you'd pick. Ask them to pick again or to
say why they'd keep it. A pick that fits goes straight to the approach.

## What to do

1. **Start from the question, not the method.** Answer four things about
   the primary question before naming a method. Together they narrow the
   list; none of them picks the method on its own.
   - **What kind of question.** *Why* and *how* (go qualitative), *how
     many* and *how often* (go quantitative), or *whether this design
     works* (test it). One caution: some *why* questions can't be
     answered by asking. If the likely cause is something people don't
     notice or can't report on (a button's size, a color, an order of
     steps), the answer comes from varying it and measuring, not from an
     interview. Qualitative work finds what matters; quantitative work
     says how much or how often. Most studies go round that loop more
     than once (S86).
   - **What people say, or what they do.** Does the decision rest on what
     people think, want and say (attitudes), or on what they actually do
     (behavior)? Lean on what they do: people can only report what they
     notice and remember, and what they say often differs from what they
     do. Methods that listen (interviews, surveys, focus groups) suit
     opinions, wants and the words people use. Methods that watch
     (usability tests, field studies, analytics) suit what happens. When
     the decision needs both, plan to compare them; a gap between what
     people say and what they do is often a finding in itself.
   - **Where the product stands.** Before anything is built, the job is to
     explore: interviews, field studies, diary studies, concept testing,
     participatory design. While it's being designed, the job is to test
     and improve it: usability testing, card sorting, tree testing and
     first-click testing, preference testing
     (`methods-preference-and-desirability.md`). Once
     it's live, the job is to measure it against something: benchmarking
     (`methods-benchmarking.md`), analytics and A/B tests
     (`methods-analytics-and-ab-tests.md`), surveys, unmoderated testing
     at scale. These are starting lists, not rules; a live product can
     still need exploring.
   - **Where and how people use it in the study.** Real use, in their own
     setting with their own data, shows the truest behavior but gives
     less control over what you see. Scripted tasks give results you can
     compare, with a narrower view. Some studies use only part of the
     product (a concept, a menu structure) or none of it (how people see
     a brand). Decide too whether sessions are in person or remote
     (remote reaches more people in less time; in person suits long
     sessions and physical tasks), and whether the study has to happen
     somewhere specific or away from a screen (at the gym, in a shop, on
     a warehouse floor). If the setting changes what people do, go to it
     (`methods-field-studies.md`).
2. **Check the cheap options first.** Could analytics, support tickets
   and reviews coded by theme (`methods-customer-feedback-coding.md`), a
   quick look at existing recordings, or five conversations answer it? Say
   so if yes, even if the researcher wanted something bigger. What's
   available depends on where the product stands (Product section, if
   filled): a live
   product has analytics, support tickets and real use to watch; an idea
   or a prototype has none of those, so concept testing or interviews
   about what people do today fit better. If there's a
   design to evaluate, an expert review (`methods-expert-review.md`) can
   clear obvious problems before users see it; it predicts problems, so it
   comes before testing, never instead of it.
3. **Consider how others solve it.** If the decision is about building
   something other tools already offer, or users will arrive with
   expectations from elsewhere, suggest a competitive analysis
   (`methods-competitive-analysis.md`) as a cheap first step or a companion
   to the main method. It works from public sources when nobody can get
   into the tools. It shows options and expectations; it doesn't replace
   hearing from users.
4. **Build the approach on their pick, with one backup.** Use the `methods-*.md` files
   for the fit, the sample guidance and the pitfalls. Where their pick
   fits, keep it and their reasons, and add what step 1 to 3 turned up
   (a cheap first step, a companion). Where it still doesn't fit after
   the one redo, recommend the method you'd use next to theirs, with the
   reason in two sentences, and let them choose (step 7). If they handed
   the turn back, recommend one method yourself, with the reason in two
   sentences. A focus group picked to judge usability or predict
   behavior is a common mismatch (`methods-focus-groups.md`).
5. **Pair methods when the question has two halves.** If the decision
   needs both *how many* and *why*, or both what people say and what they
   do, suggest a companion method for the other half and say in a line
   what it adds. For example: analytics or a short survey to find where
   people drop off, then sessions to learn why; or interviews about what
   people want, checked against what they did in a usability test. Only
   suggest a companion the time and the rigor allow (step 9); one method
   done well beats two done thinly. The researcher decides.
6. **Name what it can't tell you.** Every method has a blind spot. Write it
   under trade-offs so nobody is surprised at the readout.
7. **Show the reasoning and invite a counter** (`operating.md`, "Show the
   reasoning"). Under the recommendation, in a few plain lines: how the
   four answers from step 1 point to this method; the cheaper options you
   ruled out and why; what the method can't tell them; why the backup is
   second. Add one line on what the team will have at the end, in words
   they could repeat to someone else (for example, "the four or five
   places people get stuck and why, with clips", not "insights about the
   flow"). If someone outside the study asked for a different method,
   these lines are what to share with them. Where your approach differs
   from their pick, say where in a line, next to their own reasons. Then,
   as an optional item in the questions section: "Would you change any
   of these calls, and why? I'll rework it with your reasoning.
   (optional)" A counter is new input: rework the choice with their
   reasoning, or say in a line or two why you'd keep it. Their call
   stands; a method they keep against your advice goes in with its blind
   spot under trade-offs, and no log entry.
8. **Size the sample roughly.** Enough to see a pattern for the decision at
   hand, not a magic number. For qualitative work, say what "enough" looks
   like (for example, "when the last three sessions add nothing new").
9. **Match the rigor to the decision risk** (`lenses-minimum-viable-rigor.md`).
   Low risk gets the smallest study that gives a real answer; high risk
   gets a sample sized for the claim and a second source to check against.
   Say in a line how the recommendation fits the risk from stage 3. Check
   the plan against the floor in the lens, whatever the budget. If the
   time and money can't reach the floor, say so now: offer the smaller
   question they can answer well and what the original would take, and
   let the researcher and the team choose.
10. **Ask about partner data.** Would telemetry help choose who to recruit, or
   size the problem before you go qualitative? Draft the request if so.

## What to draft

- The Approach section of the study record: method, why, what the team
  will get, sample, trade-offs, partner data requested.
- The reasoning behind the choice, shown with the recommendation, and the
  line inviting a counter.
- A short comparison of the recommended method against the backup, if the
  researcher is weighing them, and against their own pick where the two
  differ.

## Challenge

Usually **method fit**. Example: "You've gone straight to a survey, but the
question is 'why do people stop after step 3?' What would eight sessions
watching them do step 3 tell you that the survey can't?"

## Exit criteria

- The researcher was asked for their pick and why before Magpie named a
  method, or handed the turn back; a pick that couldn't answer the
  primary question was handed back once with a hint.
- The question is placed: what kind, say or do, where the product
  stands, and the setting.
- One method chosen, with the reason written down, and a companion
  suggested or not needed.
- What the team will get is written in a line.
- Sample sized and described.
- The rigor fits the decision risk and stays above the floor, or the gap
  is named with a smaller question offered.
- Trade-offs written.
- Partner data requests drafted or marked not needed.

## Pitfalls

- Choosing the method the team is used to, not the one the question needs.
- A survey to answer a "why" question.
- A focus group to answer "can they use it?".
- Asking people what they would do when you could watch what they do.
- Asking which design people prefer and reporting it as which one works.
- An A/B test on a page with too little traffic to give an answer.
- An expert review reported as what users do.
- Treating a sample of five as proof of "how many".
- Skipping the cheap check because it feels like not doing research.
- A large study for a decision that's cheap to undo.
- Cutting below the floor to hit a deadline, and finding out at the
  readout.

---

Part of Magpie version 2026-11-18, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.
