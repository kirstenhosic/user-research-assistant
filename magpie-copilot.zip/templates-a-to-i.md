<!-- Magpie, combined for Copilot. Holds `templates-analysis-sheet.md`, `templates-card-sort-and-tree-test.md`, `templates-competitive-analysis.md`, `templates-concept-test.md`, `templates-diary-study.md`, `templates-house-style.md`, `templates-interview-guide.md`. -->

<!-- file: templates-analysis-sheet.md -->

# Analysis sheet: [study name]

An Excel workbook Magpie offers at stage 7, laid out like the note-taking
sheet so the researcher can put the two side by side. Every cell is
Magpie's draft from the transcripts and the study record, for the
researcher to check, change or delete. Made with
`scripts/make_sheet.py` (`operating.md`, "Files for the team").

Every sheet opens the same way: the study name as the title, the
document details block (Team, Date, Author(s), Reviewers, Status; Status
starts as Draft), then one line saying what the sheet is for. Keep that
line to one or two sentences on every sheet.

## Sheet 1: By participant

The same rows and research-question columns as the note-taking sheet.

| Participant | Who they are | RQ1: [question] | RQ2: [question] | Also noticed |
| --- | --- | --- | --- | --- |
| P1 | [role, segment] | [what they said or did, with line numbers, and the codes applied in brackets] | | |
| **Findings** | | [each finding for this question: claim, N of M with codes, strength, priority] | | |

- Each cell says what that participant said or did on that question,
  with transcript references written as in the study record ("Invited
  after locations were done (P1 06) [waits-for-setup]"). The intro line
  says once that "P1 06" means participant 1, line 6. "Not covered" where
  the session didn't reach it.
- The Findings row holds the findings for each research question, in the
  same words as the study record, with counts and the participants behind
  them.

## Sheet 2: Themes

| Theme | Finding | Research question | Count | Participants (lines) | Codes in it | Who didn't fit | Strength | Researcher decision | Notes |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| [short plain name, a few words] | F[n] | RQ1 | 2 of 8 | P1 06, P3 06 | [codes] | P2, P5 | moderate | [keep, change, split or drop] | |

Sorted by research question, then by count, most shared first, so the
strongest themes are on top. Single cases go last. The theme name is a
short plain label; the finding number links it to the study record.
Counts are always "N of M". "Researcher decision" stays blank until the
researcher fills it in; Magpie never fills it. Flag the riskiest theme in
its Notes cell.

## Sheet 3: Codes

| Code | What it means | Research question | Participants |
| --- | --- | --- | --- |
| [code] | [one-line definition] | RQ1 | P1, P3 |

The coding frame, so a teammate can check the work. Merged and dropped
codes go in a second small table below it (Code, What happened, Why), not
as rows of the coding frame.

## What it is not

The sheet is a working copy for review. The study record holds the
findings; if the researcher changes a cell, Magpie updates the record to
match and says what changed.

---

Part of Magpie version 2026-11-02, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: templates-card-sort-and-tree-test.md -->

# Card sort, tree test or first-click test: [study name]

| Document details | |
| --- | --- |
| Team | [team running the study] |
| Date | [date of this version] |
| Author(s) | [names] |
| Reviewers | [names] |
| Status | Draft |

Status is Draft, Under review or Final (`operating.md`, "Files for the
team").

## About this study

| | |
| --- | --- |
| Method | [open card sort / closed card sort / tree test / first-click test] |
| Tool | [name, and whether moderated sessions are added] |
| Who takes part | [participants, in a line; N per structure or design] |
| What's being tested | [the item set / the structure(s) / the page or design] |

### Research questions

1. [RQ1, in plain words]
2. [RQ2]

### How to use it

Fill in the section for the method chosen and delete the others. Cards,
tasks and labels are in participants' words, never internal names. Run
the question review (`review-question-review.md`) on the tasks before
fielding: a task that contains the label it tests gives away the answer.
Pilot with two people.

## Participant instructions

> [Card sort] Group these cards in whatever way makes sense to you. There
> are no right answers. When you're done, give each group a name you'd
> use.
>
> [Tree test] For each question, click through the menu to where you'd
> expect to find it. You can go back. Pick the place you'd try first.
>
> [First-click test] For each question, click once on the screen where
> you'd go first. Then tell us how sure you are.

## Card sort

### Cards ([30 to 50])

| # | Card (participants' words) | What it is (team only) |
| --- | --- | --- |
| 1 | [card] | [the thing it stands for] |
| 2 | [card] | |

*Team only: no two cards share a distinctive word; people group on the
word. Open sort: no group names given. Closed sort: list the group names
below, and consider a tree test instead.*

### Group names (closed sort only)

- [group]
- [group]

### Analysis sheet

| Card | Most common group | Grouped with (top 3 cards) | Went everywhere? |
| --- | --- | --- | --- |
| [card] | [name, N of M] | [cards] | [yes/no] |

Plus the names people gave the groups, counted, and the similarity matrix
from the tool.

## Tree test

### Structure(s)

Plain text, no design. One tree per participant when comparing.

```
Home
  [Section]
    [Subsection]
    [Subsection]
  [Section]
```

### Tasks ([8 to 12])

| # | Task (as shown) | Correct location(s) | Serves |
| --- | --- | --- | --- |
| T1 | "Where would you go to [goal, without the label]?" | [path] | RQ1 |

### Analysis sheet

| Task | Success | Direct success | Time (median) | First click went to | Note |
| --- | --- | --- | --- | --- | --- |
| T1 | [N of M] | [N of M] | | [top wrong paths] | |

## First-click test

### Screens and tasks

| # | Screen shown | Task (as shown) | Correct first click(s) | Serves |
| --- | --- | --- | --- | --- |
| T1 | [home / base screen] | "Where would you click to [goal]?" | [element] | RQ1 |

*Team only: every task starts from the base screen. Don't tell people it's
a first-click test.*

### After each task

1. How sure are you that you went the right way? ○ Not at all ○ A
   little ○ Fairly ○ Very
2. How easy or difficult was that? [1 very difficult to 7 very easy]

### Analysis sheet

| Task | Right first click | Time to first click (median) | Wrong clicks went to | Sure and wrong |
| --- | --- | --- | --- | --- |
| T1 | [N of M] | | [element, N] | [N] |

## Notes for the team

Not shown to participants.

### Assumptions in this draft

- [assumption] [Each guess, and where it shows up.]

### Fix before fielding

- [Anything that has to change before it goes live.]

### Waiting on

- [Pilot with two people; tool checked with a screen reader and the
  keyboard alone.]

---

Part of Magpie version 2026-11-02, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: templates-competitive-analysis.md -->

# Competitive analysis: [job or problem]

**Date:** [date] (competitors change; this has a shelf life) · **Study
record:** [link] · **Researcher:** [name]

## The question

How do people get [job] done in other tools, and what would fit our
[persona or group]?

- **Decision this serves:** [The team or group] will decide [what] by [when]
- **Persona and journey step:** [from the study record]
- **What we know about our users here:** [from the evidence log; one or
  two lines; "nothing yet" is fine]
- **Access:** [hands-on / public sources only / mixed: say which tools]

## The set

| Tool | Why it's in | How it solves the job | How we saw it | Sources and date |
| --- | --- | --- | --- | --- |
| [direct competitor] | | | [walked / shown / described] | [help doc URL, demo video, screenshots; date] |
| [direct competitor] | | | | |
| [different approach, e.g. spreadsheet or adjacent tool] | | | | |

## Fit matrix

Each cell: how the tool handles the step, what it assumes about the user,
and whether that holds for our persona, marked (walked), (shown) or
(described). A step nobody could see is "not shown publicly", not a guess.
What the tool does is observed only when it was walked or shown. Why, and
whether its users like it, is an assumption unless labeled with evidence.

| Job step | [Tool 1] | [Tool 2] | [Tool 3] |
| --- | --- | --- | --- |
| [step 1] | | | |
| [step 2] | | | |
| [step 3] | | | |

## Patterns

- **Everyone does:** [users will likely expect it]
- **Nobody does:** [a gap, or a dead end; say which you think and why]
- **One tool does well, and it would suit our persona:** [ ]
- **One tool does, and it would not suit our persona because:** [ ]

## Fit assessment

One per pattern worth considering.

### [Pattern]

- **What it would solve for our users:** [tied to the job] [their data /
  assumption]
- **What it would cost them:** [effort, learning, loss of something they
  rely on]
- **Which persona it suits:** [ ]
- **Before adopting, check with users:** [the one thing to test, and how]

## What this can't tell us

Their users' satisfaction, their data, why they chose it, whether it works
at scale for people like ours. Say it here so nobody reads the matrix as
proof. If any tool was seen only through public sources, say that its
errors, dead ends and slow steps are mostly invisible here.

## Next step

[Concept test / usability test of a pattern / nothing, with the reason.]

---

Part of Magpie version 2026-11-02, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: templates-concept-test.md -->

# Concept test guide: [study name]

| Document details | |
| --- | --- |
| Team | [team running the study] |
| Date | [date of this version] |
| Author(s) | [names] |
| Reviewers | [names] |
| Status | Draft |

Status is Draft, Under review or Final (`operating.md`, "Files for the
team").

## About this guide

| | |
| --- | --- |
| Length | [30–45] minutes |
| Format | [remote or in person; who moderates] |
| Who we're talking to | [participants, in a line] |
| What they'll see | [the concepts, their form, and their level of polish] |
| Order | [concepts rotated between participants: A-B-C, B-C-A, C-A-B] |

### Research questions

1. [RQ1, in plain words]
2. [RQ2]

### How to use it

Read the quoted lines aloud as written. The baseline comes before anyone
sees a concept, and the same questions are asked for each concept. Letters
under a question are follow-ups: use one at a time, only when needed.
Shaded notes in italics are for the moderator and are never read aloud.
Run `checks-guide-wording.md` and the question review
(`review-question-review.md`) before using.

## Opening (2 min)

> Thanks for making time. We're exploring some early ideas and want your
> honest reaction, including the critical parts; that's the most useful
> thing you can give us. Nothing's built yet, and nothing you say will be
> shared with your name on it. I'd like to record this; only [who] will
> see it. You can stop at any time. OK to start?

## Baseline, before anything is shown (8 min)

> First I'd like to hear how this goes for you today.

1. Tell me about the last time you [did the thing]. → RQ1
   a. What did you do first?
   b. What took the longest?
   c. What did it cost you: time, money, something else?
2. What have you tried to make that easier?
   a. What happened to it?
3. If nothing changed, what would you keep doing?

*Moderator: this is the data the reactions get compared with. Don't skip
it to save time.*

## Concept [A] (8 min each)

> I'm going to show you an idea. Take your time with it, and tell me what
> you think it is before I explain anything.

*Show concept [A] at the agreed polish. Say nothing for a minute.*

4. What do you think this is? Who is it for?
5. Where in your [week / day / job] would it fit, if anywhere? → RQ2
   a. What would you stop doing, or do instead?
6. What would make you not bother with it?
7. What questions do you have about it?

*Moderator: write down the questions they ask; they show the gaps. Don't
answer "would you use it?" if they ask whether they should say yes; ask
what they'd give up for it instead.*

## Concept [B], Concept [C]

*The same questions 4 to 7, in the rotated order.*

## Comparing (5 min)

8. If you could only have one of these, which, and why?
9. What's missing from all of them?

## Close (3 min)

10. What would you want to know before using something like this?
11. Can I show you the next version when there is one? *[A yes here is
    a small commitment; note it.]*

> Thank you. [What happens next.]

## Moderator notes

Not read aloud.

### What each question serves

| Question | Serves | Why it sits here |
| --- | --- | --- |
| 1–3 | RQ1 | Baseline before exposure |
| 5 | RQ2 | Value in their terms, not "do you like it" |

### Concepts

| Concept | Form | Polish | What it's testing |
| --- | --- | --- | --- |
| A | [storyboard / description / mock] | [sketch-level] | [the idea in a line] |

### Assumptions in this draft

- [assumption] [Each guess, and where it shows up.]

### Fix before sessions

- [Anything that has to change before the first session.]

### Waiting on

- [Concepts at the same polish; pilot with a colleague.]

---

Part of Magpie version 2026-11-02, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: templates-diary-study.md -->

# Diary study: [study name]

| Document details | |
| --- | --- |
| Team | [team running the study] |
| Date | [date of this version] |
| Author(s) | [names] |
| Reviewers | [names] |
| Status | Draft |

Status is Draft, Under review or Final (`operating.md`, "Files for the
team").

## About this study

| | |
| --- | --- |
| Length | [N] days or weeks, from [date] to [date] |
| Who takes part | [participants, in a line; N people, plus [N] extra for dropout] |
| What triggers an entry | [each time they X / each evening / when we prompt] |
| How entries are made | [the tool; the formats offered: text, rating, photo, voice, video] |
| Where entries go | [storage, who sees them, deletion date] |

### Research questions

1. [RQ1, in plain words]
2. [RQ2]

### How to use it

Everything from the welcome to the thank-you is what participants see,
written as if to one person. The entry prompt is kept short enough to
answer in about two minutes. Notes for the team are at the end. Run
`checks-guide-wording.md` on the prompts and the question review
(`review-question-review.md`) before the kick-off. Pilot the whole thing
with one person for two days first.

## Welcome (sent before the kick-off call)

Thanks for joining. For the next [N weeks] we'd like you to tell us about
[the thing], as it happens, in your own words. It takes about two minutes
each time. There are no right answers, and nothing you tell us will be
shared with your name on it. [Who] will see your entries, and we'll delete
them by [date]. You can stop at any time.

## Kick-off call (20 min)

1. What the study is for, in a sentence.
2. What counts as an entry: [the trigger, with two examples of moments
   that count and one that doesn't].
3. The tool: install it together, make a practice entry, check the
   formats work on their device.
4. Consent, including for photos, screenshots, voice or video, and for
   anyone else who might appear in them.
5. When they'll hear from us, and the incentive: [amount] for at least
   [N] entries, [amount] more for [N] or more.

## Entry prompt

Sent or shown [when]. The same every time.

1. What were you trying to do?
2. What happened? [A few words, a photo, or a voice note, whichever is
   easiest right now.]
3. How did it go? ○ Much worse than usual ○ Worse ○ About usual ○ Better
   ○ Much better than usual
4. Anything else? (optional)

*Team only: never show a sample entry; people copy it. If a format is
required, keep it to the lightest one, and let the others be optional.*

## Check-in messages

- Day [2]: "Thanks for your first entries. A reminder that an entry can
  be as short as a sentence. Anything unclear about what to log?"
- Day [N]: "Halfway. You've logged [N] so far. [Specific thanks.]"
- No entries for [3] days: "Just checking in. If nothing has happened,
  that's useful to know too; reply 'nothing yet' and we'll count it."

*Team only: reminders change behavior. Keep them neutral and don't tie
them to a time of day you want to study.*

## Exit interview (30 to 45 min)

> Thanks for keeping this up. I'd like to go through your entries with
> you and ask about a few of them.

1. [Walk through the entries in order.] Tell me about this one. What
   happened just before? What did you do next?
2. [For the gaps.] There's nothing between [date] and [date]. What was
   going on then?
3. [For the surprises.] You rated this one "much worse". What made it
   that bad?
4. Looking back over the [N weeks], what would you say changed, if
   anything?
5. Anything that happened that you didn't log, and why not?
6. Anything we should have asked?

## Thank-you

Thank you for [N weeks] of entries. [What happens next; the incentive and
when it arrives.]

## Notes for the team

Not shown to participants.

### What each part serves

| Part | Serves | Why it sits here |
| --- | --- | --- |
| Entry prompt Q1 | RQ1 | [reason] |
| Exit interview Q2 | RQ2 | [the gaps are where the behavior isn't happening] |

### Formats and why

[Which formats are offered, which are required, and what in the setup or
the participants made that the right choice. See
`methods-diary-studies.md`, "Ways to capture entries".]

### Assumptions in this draft

- [assumption] [Each guess, and where it shows up.]

### Fix before launch

- [Anything that has to change before the kick-off.]

### Waiting on

- [Pilot with one person for two days; tool checked with a screen
  reader; consent form sent.]

---

Part of Magpie version 2026-11-02, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: templates-house-style.md -->

# House style: readouts and reports

How Magpie formats anything written for the people who act on research:
the readout, the report, opportunity briefs and notes to partners. The
readers are UX designers, product managers, customer-facing teams (sales,
support, customer success) and engineers. Most of them skim, many read on
a phone or in a meeting, and few know research terms. Every rule below is
there so each of them can find their part and act on it quickly.

**The researcher's template comes first.** If the team has a template or
house style, follow its structure and formatting. Use these rules only for
what it leaves open, such as how quotes look or whether bullets are full
sentences.

## Structure

- **Lead with the point.** The first sentence of every section says what
  the section found or asks. Detail and evidence come after.
- **Three heading levels at most.** The title, the sections, and one level
  below for each finding. Deeper levels are hard to follow and break on
  slides.
- **Headings say something.** A finding's heading is the claim in plain
  words ("Managers lose track of swaps agreed in the chat"), not a topic
  ("Swaps"). The fixed sections (Summary, Recommendations) keep their names
  so readers know where to look.
- **Short paragraphs.** Three sentences at most. One idea each.

## Lists

- **Numbers only where order or rank matters:** top findings (ranked by
  priority, `lenses-confidence-and-priority.md`), recommendations (in
  priority order), and steps someone will follow. A reader can then say "finding
  2" in a meeting and everyone looks at the same thing.
- **Bullets for items with no order.** Three to seven per list. More than
  seven: group them under subheadings or make a table.
- **Each bullet is a full sentence**, with the key word first. A fragment
  makes the reader guess the verb, and readers from different roles guess
  differently.
- **One level of bullets.** No bullets inside bullets. If an item needs
  sub-points, it needs a heading or a short paragraph.
- **Bold labels only on fixed fields**, such as "**The decision:**" or
  "**What cuts against it:**", so the same label is in the same place in
  every finding.
- **No list of one.** One item is a sentence.

## Tables

- Use a table when several items share the same attributes:
  recommendations (action, teams involved, finding, goal, confidence), a usability
  issue list, the participant profile.
- Five columns at most, short cells, a header row. A table wider than a
  phone screen goes to the appendix with a short list in the body.

## Emphasis

- Bold for the fixed labels and, at most, one key phrase per finding.
- No italics for emphasis, no capitals for emphasis, no underlining (it
  looks like a link).
- Don't use color alone to carry meaning, such as red for bad. Say it in
  words too, for readers who can't see the color and for print.

## Quotes

- A quote sits on its own line as a block quote, word for word, followed
  by the participant code and descriptor: "— P3, finance manager, SMB"
  (`checks-claim-strength.md`, rule 6).
- Two or three per finding at most. Pick the shortest quote that shows the
  point; cut with a placeholder only to remove an identifying detail
  (`operating.md`, "Personal details in the material").

## Numbers and dates

- Numerals for every count: "6 of 8", never "six of eight" or "most".
- A percentage always shows its base: "41 of 120 (34%)".
- Dates with the month in words, so no reader mixes up day and month:
  "October 27, 2026", or "27 October 2026" in British English.

## Spelling

- American English by default: "analyze", "behavior", "color",
  "labeled", "center", "checkmark", and dates month first. When the
  researcher writes in or asks for another variety, such as British
  English, or the team profile names one, use that throughout instead,
  dates included. Quotes stay word for word, and titles and names stay
  as published (`operating.md`, "Spelling and dates").

## Words

- Plain words and short sentences. Active voice: say who did what ("P2
  renamed the file by hand"), not "the file was renamed".
- The team's own names for features, journeys and segments. A research
  term or acronym gets a four-word gloss the first time.
- Strength is always one of the same three words: strong, moderate, weak.

## For each reader

- The summary passes the reader test (`stages-08-read-out-and-report.md`,
  "Run the reader test"): each reader can tell what it means for them.
- Where it helps, recommendations are grouped under a heading per role:
  "For design", "For product", "For engineering", "For customer teams".
  Each reader can then go straight to their part.
- Mark anything that mustn't be shared with customers "Internal only", on
  the line itself, so a customer-facing reader can forward the rest.

## Images and links

- Each image has a one-line caption saying what to see in it, and alt
  text for screen readers.
- Link text says where it goes ("the study record"), never "click here".

## Slides

The same rules, plus:

- The slide title is the slide's message as a sentence.
- Six lines of text at most per slide. More goes to the appendix or the
  speaker notes.

---

Part of Magpie version 2026-11-02, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: templates-interview-guide.md -->

# Interview guide: [study name]

| Document details | |
| --- | --- |
| Team | [team running the study] |
| Date | [date of this version] |
| Author(s) | [names] |
| Reviewers | [names] |
| Status | Draft |

Status is Draft, Under review or Final (`operating.md`, "Files for the
team").

## About this guide

| | |
| --- | --- |
| Length | [45–60] minutes |
| Format | [remote or in person; who moderates] |
| Who we're talking to | [participants, in a line] |
| What they'll see | [nothing / the live product / a prototype] |

### Research questions

1. [RQ1, in plain words]
2. [RQ2]

### How to use it

Read the quoted lines (with a bar beside them in Word) aloud as written;
they carry you from one section to the next. Questions are numbered so the
team can refer to them ("question 7b"). Letters under a question are
follow-ups: use one at a time, only when you need it. Shaded notes in
italics are for the moderator and are never read aloud.

Notes for the team (what the guide is testing, timing, what to cut) are in
the moderator notes at the end. Run `checks-guide-wording.md` and the
question review (`review-question-review.md`) before using.

## Opening (2 min)

> Thanks for making time. I'm [name], and I'm trying to understand [topic
> in plain words].
>
> There are no right or wrong answers. I want to hear how things actually
> work for you.
>
> I'd like to record so I don't have to scribble. Only [who] will see it,
> and we'll delete it by [date]. You can skip anything or stop at any time.
> Is it OK if I start recording?

## Warm-up (5 min)

> Great, thanks. Before we get into [topic], I'd love to hear a little
> about you.

1. Tell me a bit about what you do and how [area] fits into your week.
2. [One more easy question about them, not the product.]

## Main questions (30 min)

### [Topic 1] → RQ1

> That's really helpful, thank you. Now I'd like to talk about [topic 1,
> in their words].

3. Tell me about the last time you [did the thing]. Walk me through it
   from the start.
   a. What happened next?
   b. What did you do instead?
   c. Can you show me?
4. [Question] → RQ1
   a. [Follow-up]

*Moderator only: [a routing or timing note, on its own line, for example
"if they say yes, ask question 5; if no, skip to question 6"].*

### [Topic 2] → RQ2

> Thanks, that gives me a clear picture. Now I'd like to shift our focus
> to [topic 2, in their words].

5. [Question]
   a. [Follow-up]
6. [Question]
   a. [Follow-up]

### Rating with a why (optional, one to three per session) → RQ[n]

> I've got a quick one now that I'm asking everyone.

7. Thinking about the last time you [did the thing], how easy or hard was
   it, from 1, very hard, to 7, very easy?
   a. Why that number?
   b. What happened that made it a [number]?

## Deep dive (10 min)

Pick the one thing they raised that matters most for the decision and go
deeper.

> I'd like to go back to something you said earlier, about [thing].

8. You mentioned [thing]. Say more about that.
9. What would have to be true for that to go differently?

## Close (3 min)

> We're almost out of time. This has been really useful.

10. Is there anything about [topic] I should have asked and didn't?

> Thank you. Here's what happens next: [incentive, findings, follow-up].

## Moderator notes

Short subheadings so the moderator can find a note mid-session.

### What this guide is testing

Never said to participants.

- [H1, in a line, and the questions that speak to it]
- [H2]

### Timing

- [Which research questions are covered by when.]
- If running short: skip [question numbers], keep [question numbers].
- If running long: the must-haves are [question numbers].

### If things get hard

- If they say "it's fine" to everything: ask for the last time it wasn't,
  or ask them to show you.
- If they get upset or uncomfortable: pause, offer to skip or stop, don't
  push.
- [Off-limits topics and the line to steer back.]

### Running the session

- [Note-takers, screen sharing, access needs, anything else practical.]

## Nice to have (only if time)

11. [Questions that didn't map to a research question but might be
    useful.]

Take notes in the note-taking sheet (`templates-notes-sheet.md`): one row
per participant, one column per research question.

---

Part of Magpie version 2026-11-02, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.
