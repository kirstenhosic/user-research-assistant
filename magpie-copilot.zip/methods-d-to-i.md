<!-- Magpie, combined for Copilot. Holds `methods-diary-studies.md`, `methods-evidence-review.md`, `methods-expert-review.md`, `methods-field-studies.md`, `methods-focus-groups.md`, `methods-interviews.md`. -->

<!-- file: methods-diary-studies.md -->

# Method: diary studies

Ask people to record what they do, when, and how it felt, over days or
weeks, as it happens rather than from memory.

## Use it when

- The question is about behavior over time: habits, frequency, triggers,
  how something fits into a day or a week.
- The moments that matter are unpredictable or private, so you can't
  observe them.
- You want to see change: before and after a release, or across a trial.

## Don't use it when

- The decision is due within a couple of weeks. A diary study takes time
  to run and to analyze.
- You could get the behavior from analytics and the "why" from a few
  interviews.
- Participants won't have the time or the motivation to keep it up.

## Sample

- Five to twelve people for a small, focused study; twelve to thirty for a
  broad one. Expect some to drop out; recruit a few extra.
- One to three weeks is typical, set by how often the behavior happens.
  Rare behavior needs a longer window.

## Study shape

1. **Pilot.** Run the study with one or two people for a couple of days to
   test the prompts, the tool and the instructions.
2. **Kick-off call (20 min).** Explain the task, the tool (a form, a
   messaging app, a diary app), what counts as an entry, and consent for
   anything they might capture (photos, screenshots).
3. **Entries.** Short and structured: what happened, when, what you were
   trying to do, how it went, a photo if useful. Triggered by the event
   ("every time you…"), by time ("each evening"), or by a prompt you send
   at varied times. Use events for things that happen a few times a week,
   time or prompts for things that happen all day.
4. **Check-ins.** A short message every few days. Answers questions, keeps
   people going, notices drop-off early.
5. **Exit interview (30 to 45 min).** Walk through their entries together.
   Ask about the gaps and the surprises. This is where most of the depth
   comes from.

## Ways to capture entries

People can make an entry in more than one way. Choose by what the study
needs to see and what participants can really do, not by what the tool
happens to offer. Most studies work best with a short core that every
entry has, plus one richer way to add detail when it helps.

- **Open text.** A typed answer to a specific prompt. Good for what
  happened and why, in their own words. Works in almost any tool, and is
  the quickest to read and code. It's hard work for people who don't like
  writing or are typing on a phone, and answers tend to get shorter as the
  weeks go on.
- **Ratings and choices.** A word-labeled rating (how it went, how hard
  it was, how they felt) or a pick from a short list (where they were,
  which device). Takes seconds, and lets you compare one person's entries
  over time. It says nothing about why, so pair every rating with "What
  made you pick that?" A rating trend in fifteen diaries describes those
  fifteen people, not the population.
- **Photos and screenshots.** Good for showing the setting, the object or
  the screen at that moment, and they make strong prompts in the exit
  interview. They can catch other people, the inside of someone's home,
  or personal details on screen, so participants need clear rules on what
  not to capture. Some form and document tools handle images badly.
- **Voice notes.** Quick to record on the move, and easier for people who
  find typing hard or who say more when they talk. They need transcribing
  before analysis, which costs time or money, and they're slow to skim.
  They can pick up people nearby, and they don't work where participants
  can't speak aloud: at a desk in an open office, on a bus.
- **Video.** A selfie video for the setting and how something felt, or a
  screen recording for a task on a computer or phone. It shows the most,
  and costs the most: effort for the participant, time to watch and
  transcribe, large files, and the highest privacy risk (faces, other
  people, homes, screens). Some people won't go on camera at all.
- **A mix.** For example, a rating and one line of text in every entry,
  with a photo or voice note when there's something words can't show.
  Keep the core questions the same whatever the format, so entries can be
  compared.

### What to find out first

Ask for whatever the record and conversation don't already say, within
the stage's six questions (`operating.md`, "Gather context before you
build"). Offer a best guess with each one.

- What the study needs to see or hear: the setting, the screen, the
  feeling, the order of steps. This decides whether pictures or
  recordings are worth their cost.
- Where and when the behavior happens: on the move, at a desk, at home,
  at work, in public, with other people around.
- Participants' devices and habits: phone or computer, data allowance, the
  apps they already use.
- Access needs: screen readers, voice control, dyslexia, limited hand
  movement, hearing or speech differences (`lenses-accessibility.md`).
- Budget and tools: a free form or messaging app, or a paid diary
  platform, and which tools the team is allowed to use for personal data.
- The team's rules on photos, audio and video: allowed or not, where
  they're stored, who can see them, when they're deleted.
- Analysis time: who will review entries, and how many there will be.
- How long the study runs and how often people make an entry.

### How to choose

1. **Start from the research question.** Use photos, audio or video only
   when seeing or hearing it answers a research question that text
   can't. Say which question each one serves.
2. **Make the core light.** The format every entry needs should be the
   quickest one that answers the question. Richer formats are optional
   unless the question depends on them.
3. **Match the effort to how often.** Several entries a day: a rating, a
   pick and one line. Once a week: there's room for a voice note or a
   short video.
4. **Offer more than one way in.** Where the tool allows, let people type
   or speak the same answer. Some people say more in writing, others on
   video or out loud. This is also an access choice. Never make video the
   only way to make an entry.
5. **Do the analysis sums.** Participants × days × entries a day, then the
   time to read, watch, listen and transcribe. Give the number, and say if
   it doesn't fit the time before the readout.
6. **Check the tool handles each format.** Messaging apps suit short
   text and quick replies, but entries are harder to export. Forms and
   shared documents suit longer written answers but handle images and
   video badly. Paid diary platforms take video, photos and
   questionnaires and help with transcription and tagging, at a cost.
7. **Try every format in the pilot,** on the devices and assistive
   technology participants will use.

Show the choice as a short table: each format, required or optional, the
research question it serves, why it fits these participants, and what it
costs. Mark guesses [assumption]. Then one line: "If a format won't work
for your participants or your team, say why and I'll rework it."

### Recordings, photos and consent

- Consent covers each format used: what may be captured, where it's
  stored, who sees it, and when it's deleted. Showing a clip or photo
  beyond the study team is a separate ask (`checks-ethics-and-consent.md`).
- Tell participants what not to capture: other people's faces or voices,
  children, ID documents, bank details, other people's messages on
  screen. Tell them how to delete an entry they regret.
- Photos, audio and video are personal data. Move them to approved
  storage, limit who can see them, and blur personal details in
  screenshots and clips before sharing.
- If a transcription or AI tool will process the recordings, the consent
  says so (standard 5.8).
- Recordings made at home, about health, or with children nearby need the
  extra care in `checks-ethics-and-consent.md`.

## What makes it good

- Entries take under two minutes. Anything longer, people stop.
- The entry prompt is specific. "Tell us about your day" gets nothing.
- Incentive paid in stages for longer studies, at a higher rate than a
  single session, with a realistic minimum number of entries and a maximum
  if more entries earn more.
- The researcher reads entries as they arrive and adjusts prompts if
  they're not working.

## Analysis

Timeline per participant, then patterns across: triggers, frequency,
sequences, how experience changed over the period. Entries plus exit
interviews together. Stage 7 covers this.

Each format needs its own handling. Read ratings per person over time,
next to their "why". Transcribe voice notes and video, and cite the
entry and timestamp for each quote. Describe what a photo or screenshot
shows in words, next to the participant's own caption, so it can be
coded with the rest.

## Worked example

> **Decision.** Whether Larder (meal planning) adds a "what's in the
> fridge" prompt, or improves the weekly plan. Product decides in six
> weeks.
>
> **Research question.** When and why do people change the plan during
> the week, and what do they do instead?
>
> **Sample.** Nine people who planned meals in the app in the last two
> weeks (six finished), two weeks, entries triggered by the event: "each
> time you cook something other than the plan, or skip a planned meal".
>
> **Capture.** Text or voice note as the core; optional photo of what
> was cooked. Check-ins on day 2, day 7 and after three silent days.
>
> **Finding, as reported.** 5 of 6 completers changed the plan at least
> three times in two weeks (P1, P2, P3, P4, P6; 31 entries); the most
> common reason, in 14 of 31 entries, was an ingredient missing or gone
> off. P5 left after day 4; their four entries are reported as four
> entries, not as "P5 never changed the plan". Entries clustered around
> 6pm because the reminder went out at 6pm; the study design shaped the
> timing, and the readout says so.

## Pitfalls

- Too many prompts, or prompts that change the behavior being studied.
- A minimum entry count so high that people log things they'd never
  normally do, or no maximum, so people invent entries for the money.
- A sample entry in the instructions that people then copy.
- Losing half the participants by week two because nobody checked in.
- Analyzing entries without the exit interview.
- Treating fifteen diaries as frequency data for the population.
- Video or photos required in every entry when text would answer the
  question. People drop out, and the analysis takes weeks.
- One format only, so people who can't type easily or can't be on camera
  stop making entries.
- Recordings with nothing on what not to capture, so other people end up
  in the data without consenting.

## Template

`templates-diary-study.md`: welcome, kick-off call, entry prompt,
check-ins, exit interview and team notes. The entry prompt there is the
core for every entry, typed or spoken: *When did this
happen? What were you trying to do? What did you do? How did it go (very
badly, badly, okay, well, very well)? What made you pick that? Anything
else?* Optional, when it helps the research question: *Add a photo,
screenshot, voice note or short video if it shows something words
don't. Leave out other people and personal details.* Exit interview:
adapt `templates-interview-guide.md`, and bring up the participant's own
photos and recordings as prompts.

## Basis

S44 (when to use diary studies; event, interval and signal logging and
when each fits; one to three weeks in its examples; five to twelve and
twelve to thirty for saturation; over-recruiting; the pilot and kick-off;
reading entries as they arrive and sending reminders; staged and higher
incentives with a minimum and maximum; the exit interview; pitfalls of
minimums, invented entries and sample entries); S52 (definition). The
two-minute entry limit and the entry prompt: practitioner judgment.
"Ways to capture entries": S65 (choose the tool by budget, the data
needed, and participants' devices and familiarity; some people express
themselves better in writing, others on video; voice notes and video as
entry formats; keep entries small and questions to what the research
needs; pilot first); S44 (messaging apps, forms and documents, and diary
platforms, with what each handles well and badly; data security and
participant convenience in choosing a tool); S66 (photos, audio and video
are personal data; consent covers what's collected, stored and shared;
approved storage, limited access, blurring personal data in screenshots
and clips). The format descriptions, the choosing steps and the analysis
sums: practitioner judgment.

---

Part of Magpie version 2026-11-03, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: methods-evidence-review.md -->

# Method: evidence review

Answer a question from research and data the organization already has,
instead of running a new study. Stage 2 in full.

## Use it when

- Stage 2 turned up enough evidence to answer the question, or nearly.
- The decision is due too soon for new research.
- Several past studies touched the question and nobody has put them
  together.

## Don't use it when

- The evidence is older than the last major change to the product or the
  market.
- The evidence is all secondhand or anecdotal.
- The question is about something the organization has never looked at.

## Sources

- The research library, if there is one.
- Past reports, decks and study records.
- Support ticket themes (`methods-customer-feedback-coding.md` says how to
  code them).
- Analytics and telemetry.
- Survey archives.
- Sales and customer success notes (indirect; label them).
- Public research, labeled as general rather than about your users.

## Shape

1. Write the question and the decision first, as in stage 3.
2. Gather what exists. Log every item in the evidence log with source,
   date, method, confidence and still-valid?
3. For each research question: what does the evidence say, how strongly,
   what disagrees, what's missing?
4. Write the evidence brief.
5. Say what a new study would add, if anything, and whether it's worth it
   for this decision.

## Judging an old study

Rate each item before it counts. Five questions, in order:

1. **Can you see the data?** A deck's conclusions are not evidence until
   you've seen what they rest on: the transcripts, the counts, the
   survey export. A study with no methods section and no data is a claim.
2. **Who took part, and how many?** Were they the people this decision is
   about? Five interviews with admins say nothing about end users. A
   survey of whoever answered describes the people who answered.
3. **What was done?** Did people do the thing or talk about it? Was the
   question asked neutrally? Did the method fit the question (stage 4's
   rules)?
4. **When, and what's changed since?** Date every item. A finding about a
   flow that has been redesigned since is history. Market and competitor
   facts age faster than findings about how people work.
5. **Who ran it, and why?** A study run to justify a decision already made
   reads differently from one run to make it. Vendor and analyst reports
   have a product to sell; label them.

The item's confidence is the lowest answer, not the average. Record it in
the evidence log in one line: "2025-03 usability test, 6 admins, moderated,
saw the data: high for admins, nothing for end users."

## Using a research repository

- Search by the user's job and the journey step, not by the feature
  name. Past studies were filed under the name the feature had then.
- Read the study, not the entry. A library entry is a summary written for
  reuse; it loses the caveats. Open the source before quoting it.
- Note who the past participants were. Repositories mix studies of
  different groups, and a theme that looks strong across five entries may
  be five different audiences.
- Look for what disagrees. Search for the opposite claim before concluding
  that the library agrees.
- When Magpie writes the library entry for this study (stage 8), it writes
  the one it wished it had found: the question, who took part, the
  method, the date, the caveats, and where the data lives.

## Summaries written by AI

Teams increasingly search their research with an AI tool, or get a
summary of past studies from one. Treat such a summary as a lead, not a
source.

- Ask for the source of every claim in it, and open that source.
- Check that each study it cites exists and says what the summary says.
  A summary can blend two studies, invent a number from "most", or
  attribute a quote to the wrong study.
- Count how many studies a "theme across our research" rests on, and who
  took part in each.
- Log the summary itself in the evidence log as a tool output, with the
  date and the prompt, never as a finding.

## The evidence brief (one page)

- The question and the decision.
- What the evidence says, with sources and dates.
- How confident we are, and why.
- What's still unknown.
- What the team should do: act, or run [specific study] to close [specific
  gap].

### Worked example

> **Question.** Should the mobile app get an offline mode? Decision due in
> three weeks; mobile team's planning.
>
> **What the evidence says.**
> - Support tickets, last 6 months (coded 2026-10, 312 tickets): 41
>   mention losing work with no signal; 29 of those from field
>   technicians. *Their data, coded by us: high for "it happens", says
>   nothing about how often per user.*
> - Diary study, 2025-11, 9 field technicians, 2 weeks: 7 of 9 logged at
>   least one day with no signal; 4 described re-entering a job on return.
>   *Saw the entries: high for this group; the app has changed since but
>   not the sync.*
> - Analytics, 2026-09: 6% of mobile sessions end in a failed sync.
>   *Partner data; counts sessions, not people.*
> - Sales notes, 2026: "customers ask for offline all the time."
>   *Anecdote; label indirect.*
>
> **Confidence.** High that losing work with no signal is real and painful
> for field technicians. Low on how many users beyond that group are
> affected, and none on whether an offline mode is what they'd want over,
> say, a draft that survives a failed sync.
>
> **Unknown.** Scale outside field technicians; what "offline" would need
> to cover.
>
> **Recommendation.** Act for field technicians: the problem is established.
> Before scoping the full feature, run five contextual inquiry sessions
> with technicians on a day in the field to see what work needs to
> survive (two weeks, fits the deadline). Don't run a survey; the
> question is what, not how many.

## What makes it good

- Honest dates. A 2023 finding about a flow that changed in 2025 is
  history, not evidence.
- Confidence labels on every source, and the brief's overall confidence
  no higher than its weakest load-bearing source.
- Disagreements between sources shown, not averaged.

## Pitfalls

- Treating a deck's conclusion as evidence without seeing its data.
- Stitching three weak sources into one strong claim.
- Skipping the brief and just saying "we already know this".
- Quoting a library entry or an AI summary without opening the study.

## Basis

S18 (secondary research as a standard first step; judge each source's
validity and limitations; a missing methods section is a red flag); S13
(one source's limits are offset by another); S14 (when sources disagree,
examine how each was done; quantitative data doesn't automatically
overrule qualitative); S10 (where AI tools break: blended sources,
invented specifics, confident summaries). The five judging questions, the
repository rules, the AI-summary rules, the evidence brief's shape, the
worked example and the confidence rule (no higher than the weakest
load-bearing source): practitioner judgment.

---

Part of Magpie version 2026-11-03, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: methods-expert-review.md -->

# Method: expert review

Reviewers, not users, inspect a design for likely problems. Two common
forms: a heuristic evaluation checks the design against a set of usability
principles; a cognitive walkthrough steps through a task as a new user
would. Neither involves users, so neither is user research.

## Use it when

- You want to clear obvious problems cheaply before testing with users,
  so the sessions find the problems only users can show you.
- The team needs a quick read on a design and there's no time to recruit.
- You're deciding what to test: the review shows which tasks look risky.
- Cognitive walkthrough: the system is new or unfamiliar to its users
  (new patterns, a kiosk, a first-time flow), and learnability is the
  question.

## Don't use it when

- The decision needs evidence about users. A review predicts problems;
  only users show them.
- The design follows familiar patterns throughout. A walkthrough of a
  standard checkout is overkill.
- You'd be the only reviewer. One reviewer misses problems, and someone
  who made the design is too close to it to see them.

## How Magpie labels the results

Every issue from an expert review is a reviewer's prediction. Label it
[assumption], not a finding, until a usability test or other evidence from
users confirms it. A review can sit in the study record's evidence log
and shape what to test; it can't stand behind a recommendation on its own.

In a readout or report, review issues get their own section or slide,
titled as predictions ("What our review predicts, to test with users"),
never "Top issues", "Findings" or "Key insights". Say what the review is
good for: a cheap first pass that clears obvious problems and picks what
to test first. The number of reviewers who flagged each issue is shown
only if the researcher gave it.

## Heuristic evaluation

1. **Prepare.** Pick the heuristics (Nielsen's ten usability heuristics
   are the common set, S95: visibility of system status, match with the
   real world, user control and freedom, consistency and standards, error
   prevention, recognition over recall, flexibility and efficiency,
   aesthetic and minimalist design, help with errors, help and
   documentation; add domain-specific ones if needed). Narrow the
   scope to a task, a section, a user group or a device. Agree how issues
   will be recorded.
2. **Review alone.** Three to five reviewers, each working independently
   for one to two hours. Go through the scope once to learn it, then again
   noting each place a heuristic is broken and why.
3. **Combine.** Only after everyone has finished, group the issues, discuss
   where reviewers disagree, and decide which issues matter most and which
   need data from users.

## Cognitive walkthrough

1. **Prepare.** Pick a few tasks, ideally the ones users do most or the
   ones the decision is about. Agree who the user is and what they know.
2. **Walk through.** A cross-functional group (design, product,
   engineering, someone who knows the domain). A facilitator does the task
   one step at a time. At each step the group asks:
   1. Will users try to achieve the right result?
   2. Will users notice that the correct action is available?
   3. Will users connect the correct action with what they're trying to do?
   4. After the action, will users see that they're making progress?
3. **Record.** Any "no" marks that step as a likely failure, with the
   reason. A note-taker records each answer.
4. **Summarize.** The failure points per task, and what to test with users.

## What makes it good

- Independent reviews before discussion, so one reviewer doesn't set the
  list.
- A narrow scope. The narrower it is, the more detailed the review.
- Each issue tied to the principle or the walkthrough question it fails,
  and to where it happens.
- Treating a broken heuristic as a question, not a verdict. Context
  matters, and principles are guidelines, not laws.

## Analysis

An issue list: where, which heuristic or question it fails, how many
reviewers found it, and a note on whether users need to confirm it. Then
the short list of tasks to put in front of users. Keep it separate from
findings from users, in the record and in any readout.

## Worked example

> **Decision.** Which tasks to put in next month's usability test of
> Tally's (expense tracking) new approvals flow, and what to fix before
> it.
>
> **Review.** Heuristic evaluation, four reviewers (two designers, a
> content designer, a support lead), independently, 90 minutes each, on
> the approvals flow only, against Nielsen's ten heuristics.
>
> **Combined list.** 23 issues; 6 found by three or more reviewers.
> Top: no confirmation after "Approve" (visibility of system status,
> 4 of 4 reviewers); "Reject" and "Return for changes" look the same
> (error prevention, 3 of 4).
>
> **As recorded.** Every issue is [assumption] in the evidence log:
> "Reviewers predict people won't know an approval went through." The
> two top issues become test tasks; three cheap fixes (labels) go in
> before the test. Nothing from the review appears as a finding.

## Pitfalls

- Presenting review issues as "users struggle with…".
- One reviewer, or reviewers who compare notes before they finish.
- Using a review instead of testing with users, rather than before it.
- Ranking issues by how many principles they break rather than by what
  they'd cost users.

## Template

An issue list with columns: location, heuristic or walkthrough question,
what happens, reviewers who found it, confirm with users (yes or no).

## Basis

S34 (heuristic evaluation: three to five independent reviewers, one to two
hours each, narrow scope, consolidate afterwards, heuristics are
guidelines, it can't replace user research); S35 (cognitive walkthrough:
the four questions, a cross-functional group, a facilitator and a recorder,
best for new or unfamiliar systems, to be combined with usability
testing); S95 (the ten heuristics by name). The [assumption] label and keeping results apart from user
findings follow `operating.md`. Avoiding self-review, the pitfalls and
the issue-list columns: practitioner judgment.

---

Part of Magpie version 2026-11-03, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: methods-field-studies.md -->

# Method: field studies

Go where people actually do the thing, at work, at home or out in the
world, and see it happen. Contextual inquiry is one kind of field study;
this guide covers the others and how to choose.

## Use it when

- You're early, still working out what the problem is, and you don't yet
  know what to ask.
- The setting changes the experience: noise, interruptions, other people,
  shared devices, paper next to the screen.
- People do the thing out of habit and can't describe it well.
- The audience's culture or work is unfamiliar to the team.

## Don't use it when

- The work is confidential, or watching it would be unsafe or intrusive.
  Simulate it in a lab, or interview instead.
- A remote session would show enough. It's cheaper and faster, and suits
  people spread far apart.
- The decision is due in days. Field work takes time to arrange: access,
  permissions, travel.

## Choose the kind

| Kind | What you do | Good for |
| --- | --- | --- |
| Direct observation | Watch without asking questions or stepping in | Natural task flow, the words people use, workarounds |
| Contextual inquiry | Watch and ask as the work happens | How work gets done and why; see `methods-contextual-inquiry.md` |
| Site visit | Observe and talk, often with the customer leading the tour | Industry-specific or large-scale problems, many roles in one place |
| Ethnography | Spend a long time in a group's setting | Social norms and culture, especially one unlike the team's |
| Remote field session | The participant shows their setting by camera or screen share | Spread-out participants, quick rounds, many observers |

Ethnography, in the full sense, takes weeks of immersion. Most product
teams run a few days of observation and should call it that.

## Sample

- Four to eight sites or people per role, chosen across the variation
  that matters (site size, experience, region).
- Where several people share the work, observe the handoffs between them,
  not only one person.

## Study shape

1. **Plan.** Research questions, who, where, and when the work actually
   happens (month-end, a night shift). A shared observation guide so every
   observer looks at the same things.
2. **Get access.** Permission from the participant, their manager and
   whoever runs the place. Find one person on site who can help with
   rooms, recruiting and equipment.
3. **Consent for everyone in view.** Photos, recordings, and colleagues or
   family who may appear. Agree what you won't record.
4. **Observe.** Notes on what people do, what they use, who they talk to,
   and where things stall. Hold most questions until a natural break so you
   don't interrupt the work.
5. **Debrief the same day.** Observers compare notes while memory is fresh.

## What makes it good

- One or two observers, not a crowd. More people change what you see.
- Rules for observers agreed beforehand: where to stand, when to stay
  quiet, no side conversations.
- Notes that keep what you saw separate from what you think it means.
- Remote sessions that ask for the context the camera misses: "Can you
  show me what's on the desk?", "Who else is in the room?"

## Analysis

As for contextual inquiry: map the work as it actually runs, mark the
breakdowns and workarounds, then themes across sites (stage 7). Note the
setting for every finding, since a problem that appears only at one site
may be about that site.

## Worked example

> **Decision.** Whether Dockside (warehouse returns) builds a mobile
> scanning app or improves the desk screens. Operations decides next
> quarter.
>
> **Research question.** Where does a return physically go between the
> loading bay and the desk, and who touches it?
>
> **Kind.** Direct observation, then a site visit led by the floor
> manager, at four sites across two regions; two observers, one shared
> observation guide.
>
> **Access.** Permission from the site manager and the clerks; consent
> for photos of the floor with no faces; agreed not to record the
> loading bay cameras' area.
>
> **Finding, as reported.** At 3 of 4 sites a return is handled by three
> people before it reaches the desk (bay, sorting, desk), and the paper
> slip travels with it; the desk screen is the first place it's typed.
> Site D (the smallest) has one person doing all three. Reported per
> site, with the setting next to each finding, since a problem seen at
> one site may be about that site.

## Pitfalls

- Turning it into an interview at a desk.
- Too many observers crowding the space, so people perform instead of
  work.
- Side conversations among the team that pull attention from the
  participant.
- Going in without agreed questions, so each observer comes back with a
  different study.
- Calling three days of visits "ethnography".

## Template

Use the observation sheet in `methods-contextual-inquiry.md` (time, what
happened, tools, people, breakdown), plus a short list of the research
questions for every observer.

## Basis

S33 (the four kinds, when to use field studies, planning and permissions,
observer rules, holding questions to avoid interrupting, remote sessions
and their limit); S11 (definition). Sample sizes and the same-day debrief:
practitioner judgment.

---

Part of Magpie version 2026-11-03, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: methods-focus-groups.md -->

# Method: focus groups

A moderated discussion with a small group of people about a set of topics,
to hear what they want, how they talk about it, and where they agree and
disagree.

## Use it when

- You're early, before design, and want to know what people want and the
  words they use for it.
- You want reactions and ideas from several people at once, and hearing
  them react to each other is part of the point.
- The topic is an activity that runs over days or weeks and would cost too
  much to observe.
- The group itself matters: how a team or a household decides together.

## Don't use it when

- The question is whether people can use a design. A focus group is a
  poor way to judge usability; people watch, talk and agree rather than
  try. Run a usability test.
- You need to know what people actually do. A group tells you what people
  say they do. Observe, or interview one to one about specific past
  events.
- The topic is sensitive, or people would hold back in front of
  colleagues, a manager or strangers. Interview them one at a time.
- It's the only method in the study. Pair it with one-to-one sessions or
  observation.

## When someone asks for one

Teams often ask for a focus group because it sounds efficient: ten people
in one hour. Before planning one, ask what decision it serves and what the
team wants to learn. If the answer is "will they use it" or "can they use
it", say which method answers that better and why. If a group still fits,
run it well.

## Sample

- Six to nine people per group, with a moderator.
- At least two groups. One group can be pulled off course by one person or
  one mood, and you can't tell from inside it.
- Each group drawn from one segment, so people have enough in common to
  talk. Different segments go in different groups.
- Recruit on recent behavior, as for interviews.

## Session shape (90 to 120 minutes)

1. **Opening (10 min).** Who you are, what it's for, what's recorded, that
   there are no right answers, and that people can disagree. Ask people
   not to share what others said outside the room; you can't promise it,
   so say so.
2. **Warm-up (10 min).** Each person, in turn, answers one easy question
   about their own experience. Everyone has spoken once early on.
3. **Topics (60 to 80 min).** Three or four topics from a written guide,
   each with an opening question and probes. Use concrete material
   (a scenario, a sketch, a prototype on screen) rather than abstract
   questions; people react better to something real.
4. **Individual exercise (10 min).** Before discussing a key question, each
   person writes or picks their answer alone. Then share. This captures
   views before the group shapes them.
5. **Close (5 min).** Anything we missed, thanks, what happens next.

## What makes it good

- A guide with set goals for what to learn, so the discussion stays on
  track without being cut short.
- Every person contributes. The moderator draws in the quiet ones and
  holds back the one who dominates.
- Writing before talking, so the first confident voice doesn't set
  everyone's answer.
- A second person taking notes on who said what, not just what was said.

## Analysis

Code the transcript as for interviews (stage 7), but keep track of who
spoke. Report the group's overall mood with a few quotes, the topics where
people disagreed, and the views that came from the written exercise versus
the discussion. Agreement in a group is not a count: "the room agreed" may
mean two people spoke and six nodded. Never turn group agreement into a
percentage.

## Worked example

> **Ask.** "Can we run a focus group to see if admins would use the new
> billing dashboard?" (BrightPay, payroll.)
>
> **Fit check.** "Would use" is a behavior question; a group would give
> opinions. Offered a usability test of the dashboard with five admins
> instead. The PM also wanted to know the words admins use for billing
> problems, before the dashboard's copy is written. A group fits that.
>
> **Plan.** Two groups of seven, each from one segment (small firms;
> accountants running payroll for clients), 90 minutes, a written
> exercise before the main discussion: "Write the last billing problem
> you had, in a sentence."
>
> **Finding, as reported.** The written exercise produced 14 problems,
> 9 about "I can't tell what we were charged for" in those words; the
> discussion that followed was led by two voices in group 1 and the
> written answers are reported separately from it. Not reported: "the
> room agreed". Next: the usability test with the dashboard's new copy.

## Pitfalls

- Using it to test usability.
- Treating what people say they'd do as what they do.
- One loud participant becoming "the group's view".
- Showing a demo and asking for opinions; watching a demo is not using the
  product.
- Running one group and reporting it as the finding.

## Template

Adapt `templates-interview-guide.md`: one block per topic with an opening
question and probes, plus the individual exercise.

## Basis

S31 (what focus groups are good and bad for, six to nine per group, more
than one group, moderation, demos are not use); S11 (definition; NN/g's
overview gives a wider range of 3 to 12 per group). Writing before
discussing: S15, S16, which make this point for workshops. The opening on
confidentiality and the session timings: practitioner judgment.

---

Part of Magpie version 2026-11-03, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: methods-interviews.md -->

# Method: interviews

One-to-one conversations to understand how people do something, why, and
what gets in the way.

## Use it when

- The question is about *why* or *how*: motivations, workflows, workarounds,
  decisions.
- You need to understand a problem before designing anything.
- You have access to the right people and time to talk to them.

## Don't use it when

- The question is *how many* or *how often*. Interviews can't tell you that.
- You already know the problem and need to know whether a design works.
  Test it instead.
- You can't reach the people the decision is about.

## Sample

- Start at five or six for a single, fairly uniform group, and analyze as
  you go. Add people while sessions still bring new codes; stop when they
  add little. Five is often not enough for interviews, and a broad question
  across varied people can need twenty or more.
- Where groups differ, recruit across the differences that could change the
  answers. A fixed number per persona ("five each") can mean far more
  interviews than the question needs.
- Recruit on recent behavior ("did X in the last month"), not on
  self-description ("considers themselves a power user").

## Session shape (45 to 60 minutes)

1. Opening: who you are, what it's for, what's recorded, they can stop. Two
   minutes.
2. Warm-up: about them and their work. Easy. Five minutes.
3. Main questions: past, specific, concrete. "Tell me about the last time…"
   Thirty minutes.
4. Deep dive on one thing they raised. Ten minutes.
5. Close: anything we didn't ask, thanks, what happens next.

## What makes it good

- Specific stories over general opinions. The last time, not the usual.
- Silence. Count to five before filling it.
- Probes ready: "what happened next?", "what did you do instead?", "can you
  show me?"
- Notes capture what they did and said, separately from what you think it
  means.

## Ratings with a "why"

A rating question followed by "why that number?" is a quick way into a
conversation, and it lets you compare how people felt about the same
moment. In an interview the reason is the data; the number is a prompt.

- **Ask about a specific moment.** "Thinking about the last time you
  [did the thing], how easy or hard was it, from 1, very hard, to 7, very
  easy?" Not "how easy is it in general".
- **Follow every rating with "Why that number?"** Then probe the reason
  as you would any answer: "What happened that made it a 3?" If it isn't
  already clear, ask what would have moved it up or down.
- **Keep it to one to three ratings per session.** Closed questions stop
  the conversation; too many turn an interview into a spoken survey.
- **Use the same scale every time,** with words on both ends, so answers
  can be compared across people.
- **Expect ratings to run kind.** People rate higher to the researcher's
  face than they feel. A 6 with a story of a workaround is a problem,
  whatever the number says.

In analysis, report each person's rating next to their reason ("P3: 2 of
7, because the export failed twice"). Don't average interview ratings or
turn them into percentages; with eight people a mean looks precise and
isn't. The reasons, coded like any other answer, are the finding.

## Analysis

Thematic analysis: read everything, code what's there, group codes into
themes, check each theme against the participants who don't fit it. Keep
quotes tied to participant codes and timestamps. Stage 7 covers this.

## Worked example

> **Decision.** Whether Harbor (a team task board) should build a guided
> setup for new admins, or leave setup as it is. Product leads decide in
> five weeks.
>
> **Research question.** How do new admins set up a workspace in their
> first week, and where does it stall?
>
> **Sample.** Six admins who created a workspace in the last 30 days, then
> two more when the sixth session still brought a new code (eight in all).
>
> **Guide, main block.** "Tell me about the first day you set up Harbor.
> What did you do first? When did you invite someone, and what made that
> the moment?" Probes ready: "What did you do instead?", "Can you show
> me?"
>
> **Finding, as reported.** 6 of 8 admins built one full board before
> inviting anyone (P1 06, P2 09, P3 04, P5 11, P6 07, P8 05); P4 and P7
> invited on day one. The reason given by five of the six: "something to
> show" (P1 10, P2 12, P3 08, P6 09, P8 07). Confidence: moderate; past
> behavior, told not seen; one study.

## Pitfalls

- Asking people to predict their future behavior.
- Letting a talkative participant set the agenda for the whole study.
- Hearing what you hoped to hear. Write down the disconfirming cases.
- Treating eight interviews as "most users think…". They tell you what
  exists, not how common it is.

## If an AI moderates

Some tools run interviews from a guide. They're blunter-friendly but shape
answers through phrasing and follow-ups, and the data comes out tidier than
the people were. Treat the moderator's instructions as a guide (wording
check, boundaries, fallback for unclear answers) and read the first three
transcripts in full before the rest run. `checks-ai-assisted-research.md`.

## Template

`templates-interview-guide.md`

## Basis

Sample: S42 (no fixed number; start with five or six and add while new
codes appear; five is often not enough; broad, varied studies can need 20
to 30 or more; a fixed number per persona can mean too many). Session and
questions: S41 (easy questions first to put people at ease; ask about
specific events, because memory is flawed; follow-up questions prepared,
probes used as they arise; leading questions compromise the data); S5
(past experience over hypotheticals); S8 (self-reported intentions are
unreliable). Recruiting on behavior: S9. Analysis: S1b. Ratings with a
"why": S38 (pair a rating with "why did you give it that score?" for
qualitative insight, and don't make much of the average from a few users);
S39 (closed questions used sparingly in qualitative research, because they
stop the conversation); S40 (word-labeled scales are easier to understand;
rating scales are prone to acquiescence and social-desirability bias); S12
(numbers from small qualitative studies carry large error). Session timings,
counting to five in silences, one to three ratings, and the AI-moderator
section's reading rule: practitioner judgment (the AI-moderator risks
themselves: S10).

---

Part of Magpie version 2026-11-03, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.
