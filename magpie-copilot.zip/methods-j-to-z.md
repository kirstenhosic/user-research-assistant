<!-- Magpie, combined for Copilot. Holds `methods-journey-maps-and-personas.md`, `methods-participatory-design.md`, `methods-preference-and-desirability.md`, `methods-stakeholder-interviews.md`, `methods-surveys.md`, `methods-usability-testing.md`. -->

<!-- file: methods-journey-maps-and-personas.md -->

# Method: journey maps and personas from research

Two ways to turn findings into something the team keeps using after the
readout. A journey map shows the steps one kind of person takes to reach
a goal, with what they do, think and feel at each step, and where it goes
wrong. A persona describes one kind of user: their goals, how they work,
what gets in their way. Both are outputs of research, built from
findings; neither is research.

## Use them when

- The study covered a whole journey (a diary study, field work, a round
  of interviews about a process) and the findings are a sequence, not a
  list.
- The team keeps arguing about "the user" and the research found two or
  three distinct kinds.
- The team already has journeys or personas and the study contradicts or
  extends them (`lenses-systems-and-journeys.md`).
- A map would show where the problems cluster better than a findings list
  would.

## Don't use them when

- The research didn't cover the journey. A map drawn from one touchpoint
  is a guess about the rest; label the guessed parts.
- The team wants a persona to settle an argument, with no research
  behind it. That's a proto persona: a written-down assumption. It can be
  useful for aligning a team, as long as it says so on its face.
- The deliverable would be the end of the work. A map or a persona is a
  tool for the next decision, not a poster.

## Journey maps

A map has five parts. Leave out what the research can't fill, and mark
what's inferred.

1. **The actor.** One persona or one kind of user. A map with two actors
   is two maps.
2. **The scenario and the expectation.** What they're trying to do, and
   what they expect it to be like. From the baseline questions in
   sessions.
3. **The phases.** Three to seven, in the user's words, from what people
   did, not from the product's screens.
4. **In each phase: actions, thoughts, feelings.** What they did; what
   they said they were thinking; how it felt, from what they said and
   did. Each cell carries a participant count or a code ("P2, P5, P7"),
   as any finding does.
5. **Opportunities.** Where it stalled, where they improvised, where
   they gave up. Each one points to a finding, and from there to a
   recommendation (stage 8).

How to build it from findings:

- Lay the sessions side by side (the sequences from contextual inquiry,
  the entries from a diary, the "last time" stories from interviews).
  Where did each person start, and what happened next?
- Name the phases from the steps most people had. Steps only some had
  go in as branches or notes.
- Fill each cell from coded findings, with the counts. A cell with one
  participant behind it says so.
- Mark the breakdowns, and how many hit each.
- Mark the parts the study didn't cover, so the map doesn't claim them.
- Draft it, then check it with two or three participants, or against two
  sessions you held back. A map nobody who lived it recognizes is wrong.

Related things the team may ask for: an experience map (the same, for a
whole activity, not tied to a product), a service blueprint (the same
journey from the organization's side: the people, systems and steps
behind each phase), and a user story map (the journey as a backlog, for
planning). The journey map is for understanding; the others come after.

## Personas

Three kinds, by what they rest on. Say which kind any persona is.

| Kind | Built from | Good for | Can't say |
| --- | --- | --- | --- |
| Proto persona | The team's assumptions, written down in a workshop | Aligning a team quickly; naming assumptions to test | Anything about real users; label it [assumption] |
| Qualitative persona | Interviews, field work, tests: a small sample, grouped by shared goals, attitudes and pain points | Most teams, most decisions; design and prioritization | How many users each one stands for |
| Statistical persona | A survey of a large sample (hundreds, often 500 or more) clustered by attitudes and behaviors, with qualitative research first | Sizing each group; big investment decisions | Much, without the qualitative work behind it |

How to build qualitative personas from findings:

- Group participants by what they're trying to do and how, not by who
  they are. Two people with the same job title can be different personas;
  two with different titles can be the same one.
- Look for the differences that changed the findings: the goal, the
  frequency, the setting, what they're measured on, what they fear.
  Those are the dividing lines. Demographics go in only where they
  changed behavior.
- Two to four personas. More than that and nobody remembers them.
- Each persona gets: a name and a one-line description; what they're
  trying to do; how they do it now, including the workarounds; what gets
  in the way; what they'd never do; a quote from a real participant; and
  the participant codes it's built from ("P1, P4, P6, P8").
- Say what the study can't say: how many users are each persona, and
  whether the groups hold outside the sample.
- Every persona is memorable, actionable and different from the others.
  If two personas would make the same decision in every scenario the team
  cares about, merge them.

## What makes it good

- Every cell and every trait traceable to findings, with counts or codes.
- Gaps marked, not filled in.
- Checked against people who lived it.
- Dated, and owned by someone who'll update it after the next study.
- Used: it appears in the next stage 3, when the team places a new
  question on the journey and names the persona it's about.

## Analysis

They are analysis outputs. Build them in stage 7 after the themes are
settled, and present them in stage 8 next to the findings they rest on,
never instead of them. The readout says what kind of persona it is and
how many sessions the map rests on.

## Worked example

> **Study.** Dockside (warehouse returns): five contextual inquiry
> sessions and a two-week diary with six clerks.
>
> **Journey map.** Actor: a returns clerk at a multi-person site.
> Scenario: "get a return off the floor and refunded." Five phases from
> the sequences laid side by side: receive, sort, find the order,
> refund, close. "Where it breaks" cells: search times out on unlabelled
> items (receive, 3 of 5 sessions); refund screen resets (refund, 2 of
> 5 sessions, 9 diary entries). The "close" phase was seen in only two
> sessions and is marked so. Checked with two clerks, who moved "sort"
> before "receive" for bulk deliveries; the map now shows that branch.
>
> **Personas.** Qualitative, two: the desk clerk (P1, P2, P3, P5; works
> the screen, keeps paper for the two failures) and the all-in-one clerk
> at a small site (P4; does bay, sort and desk alone, scanner-less).
> Each carries its codes, a real quote, and "can't say how many sites
> are like this". The team's existing persona, "warehouse operative",
> covered both; a library entry says why they're now two.

## Pitfalls

- A map drawn from the product's screens, not from what people did.
- A persona built from a demographic, a role or a plan tier.
- Filling the gaps with plausible guesses, unmarked.
- One participant's journey presented as the journey.
- Personas that live in a slide and never appear in a decision.
- Updating the poster, not the persona, after new research.

## Template

`templates-journey-map.md` for the map and `templates-persona.md` for
each persona. Both carry the participant codes column.

## Basis

S93 (a journey map as a visualization of the process a person goes
through to accomplish a goal; the five parts: actor, scenario and
expectations, phases, actions, mindsets and emotions, opportunities; how
it differs from experience maps, service blueprints and user story maps).
S94 (the three persona kinds: proto personas from assumptions, qualitative
personas from small-sample research grouped by attitudes, goals and pain
points, statistical personas from a large survey, ideally 500 or more,
with clustering and prior qualitative work; qualitative as the best fit
for most teams; personas rest on qualitative understanding, not
demographics or analytics correlations alone; good personas are
memorable, actionable and distinct). Building from coded findings with
counts, the two-to-four range, checking with participants, and the
pitfalls: practitioner judgment.

---

Part of Magpie version 2026-11-12, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: methods-participatory-design.md -->

# Method: participatory design (co-design)

Give participants materials and let them make their ideal version of an
experience, then ask them to explain what they made. What they make shows
what matters to them and why.

## Use it when

- You're at the start, before anyone has decided what to build, and the
  question is open: what should this be for these people?
- The people the decision is about are the experts on their own lives or
  work, and the team doesn't share that experience.
- You want people's priorities in their own terms, not reactions to the
  team's idea.
- The decision will affect a community that expects a say in it.

## Don't use it when

- You need to know whether a design works. Test it.
- The team won't act on what participants make. Asking people to design
  something and then ignoring it costs their trust and yours.
- You want a finished design from participants. They show what matters;
  the team still designs.

## How it differs from a stakeholder workshop

A stakeholder workshop (`workshops-stakeholder-workshops.md`) is the team
deciding together. Participatory design is research: the participants are
the people the decision is about, they're recruited and paid like any
other participants, and their consent covers what they make as well as
what they say.

## Sample

- Groups of four to six, or one-to-one making sessions for sensitive
  topics.
- Two to four sessions per user group. As with interviews, stop adding
  sessions when the last ones bring nothing new.

## Session shape (90 to 120 minutes)

1. **Opening (10 min).** What it's for, what's recorded (including
   photos of what they make), that there's no wrong answer and no drawing
   skill needed.
2. **Warm-up (15 min).** A small making task about their own recent
   experience: a timeline of the last time they did the thing, using cards
   or stickers. This gets people used to making, and it's data too.
3. **Make (40 min).** The main task, with a kit: cards with words and
   images, blank cards, a large sheet, simple shapes for screens or steps.
   The prompt is about their goal, not the product ("Make the way you'd
   want to get your monthly numbers to your boss").
4. **Tell (25 min).** Each person or pair walks the group through what they
   made. Ask why each piece is there, what they left out, what they'd fight
   to keep.
5. **Close (10 min).** What surprised them, what's next, and how they'll
   hear what came of it.

## What makes it good

- The researcher facilitates; the participant is the expert. Don't correct
  or improve what they make.
- A kit with enough ready-made pieces that nobody faces a blank page, and
  blank pieces for what you didn't think of.
- More than one way to take part: drawing, arranging cards, talking it
  through while someone else places the pieces.
- The "tell" step recorded. What people made matters less than why they
  made it.
- Participants hear back what changed because of their work.

## Analysis

Analyze the explanations, not the objects. Code the "tell" transcripts as
for interviews (stage 7), with photos of the artifacts as context. Look for
what people put first, what they repeated, what they left out, and the
reasons they gave. A pattern across people is a finding; one person's
design is a single case.

## Worked example

> **Decision.** What a "my week" view in Sparrow (team messaging) should
> be for, before design starts.
>
> **Research question.** What do people want to see at the start of a
> working day, and what do they want to keep out of it?
>
> **Sample.** Three making sessions of five people, recruited and paid
> as participants, 100 minutes each. Kit: cards for things Sparrow
> already shows (unread, mentions, meetings), blank cards, and a large
> sheet marked "morning", "midday", "end of day".
>
> **Prompt.** "Make the start of a day that would let you get to your
> real work faster." Not "design our home screen".
>
> **Finding, as reported.** From the "tell" step, coded like interviews:
> 11 of 15 put "what's waiting on me" first and left unread counts off
> the sheet entirely (P1 to P4, P6, P7, P9 to P11, P13, P14); the reason
> given by eight was "counts make me feel behind". One participant's
> layout (a calendar-first view) is reported as a single case. The
> participants heard back what the team did with it.

## Pitfalls

- Treating a participant's design as a design spec.
- A prompt about the product ("design our dashboard") instead of their goal.
- A kit made of the team's own concepts, so people can only rearrange the
  team's idea.
- Skipping the "tell" step and analyzing photos of sticky notes.
- No follow-up, so participants never learn what their work led to.

## Template

Adapt `templates-workshop-agenda.md` for the session plan and
`templates-interview-guide.md` for the "tell" questions.

## Basis

S32 (co-design as collective creativity; the participant as the expert on
their own experience; the researcher as facilitator who provides tools for
people to express themselves; most useful at the open, early stage of
design); S11 (definition: participants construct their ideal experience
from design elements or creative materials). Sample sizes, timings and the
session shape: practitioner judgment.

---

Part of Magpie version 2026-11-12, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: methods-preference-and-desirability.md -->

# Method: preference and desirability testing

Learn how people react to how a design looks and feels. A preference test
shows two or three versions and asks which one people prefer, and why. A
desirability test gives people a list of words and asks them to pick the
ones that describe the design (sometimes called the reaction card
method).

## Use it when

- The question is about look, feel, tone or brand fit, not whether people
  can use it.
- The team is choosing between two or three visual directions that differ
  enough for someone who isn't a designer to notice.
- The team wants to check that a design comes across the way the brand
  intends ("trustworthy", "simple", "friendly").

## Don't use it when

- The question is whether people can use it. Preference isn't
  performance; people may prefer the version they struggle with. Run a
  usability test.
- The versions differ in small details. People will invent a preference
  rather than say they can't tell.
- You need to know what people will do. This is what they say.

## Preference testing

- Show two or three versions. Vary only a few things, so you can tell
  what caused the reaction.
- Change the order the versions are shown in from one person to the next.
- Ask why in moderated sessions. In unmoderated tests, answers to "why"
  tend to be vague.
- In a usability test, ask about looks after the tasks, never before.
  Once people pick a favorite, they tend to overlook its problems.

## Desirability testing

- Build the word list from the traits the team wants, their opposites,
  and some unrelated words. About as many negative words as positive
  ones; a list of only flattering words tells you nothing.
- Keep it short: about 25 words or fewer in a survey.
- Drop words about features or content if you're testing looks.
- Shuffle the order for each person.
- People pick about five words that describe the design. A screenshot or
  mockup is enough; they don't need to use it.
- In a moderated session, ask about each word chosen: "What made you pick
  'cluttered'?" The reasons tell you what to change.

## Sample

The sources checked give no number. For reasons to explore, five to eight
people per group in moderated sessions is a common size. For shares you
want to compare (how many picked each word or each version), you need
many more, and stage 7's survey data rules apply: a share from ten
people carries a range of 30 points or more, and halving that range
takes four times the people.

## Analysis

- **Desirability:** for each word, how many people chose it, ranked.
  Compare user groups or versions on their words, and count how many
  people chose at least one of the traits the team was aiming for. With a
  small sample, give counts ("4 of 8"), not percentages.
- **Preference:** the reasons matter more than the tally. Group the
  reasons and say which parts of the design they point to.

## Worked example

> **Decision.** Which of two visual directions Larder (meal planning)
> takes for its recipe pages; the brand goal is "calm, not a food blog".
>
> **Setup.** Inside a usability test of the recipe page (eight people,
> moderated), both directions shown after the tasks, order switched
> between people. Then a 24-word list, half negative, shuffled: pick
> five that describe the page.
>
> **Result, as reported.** 6 of 8 preferred direction B (P1, P2, P4,
> P5, P6, P8), with the reasons grouped: "less to read" (4), "the photo
> is smaller" (3). Words picked for B: "calm" 5 of 8, "plain" 4 of 8,
> "cluttered" 0; for A: "busy" 5 of 8, "appetizing" 4 of 8. Counts, not
> percentages. Reported next to the task results: two of the six who
> preferred B had failed the "add to plan" task on B, so preference is
> reported as preference, not as "B works better".

## Pitfalls

- Reporting preference as which version works better.
- Versions too alike to tell apart.
- Asking which one they like before they've tried to use it.
- A word list that's long, unshuffled or all positive.

## Template

Inside a usability test, add the questions after the tasks in
`templates-usability-test-script.md`. On its own at scale, use
`templates-survey.md`.

## Basis

S77 (preference testing with two or three versions that vary in a few
things, order shuffled; noticeable differences or people invent a
preference; ask why only when moderated; ask about looks after usability
tasks, because choosing a favorite first hides its problems; word-choice
methods; ratings need more people than qualitative methods). S76 (the
desirability toolkit, first published by Benedek and Miner at Microsoft as
described there: people pick about five words; adapt the list to what you
measure; about 25 words or fewer in surveys; shuffle; mix negative,
positive and neutral words; a screenshot is enough; rank by share; compare
groups and versions; count people who chose a brand word). S11
(desirability studies as a method). Asking about each chosen word, the
five to eight per group, and counts instead of percentages for small
samples: practitioner judgment. The width of a small-sample range and
the four-times rule: S100 (pp. 19–25).

---

Part of Magpie version 2026-11-12, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: methods-stakeholder-interviews.md -->

# Method: stakeholder interviews

One-to-one conversations with the people who have a stake in the work or
whose cooperation it needs: product, engineering, design, support, sales,
leadership, a partner team. Not user research. They tell you what the
project is for, what it has to deliver, what has been tried, and who
needs to be on board.

## Use it when

- A project is starting and the brief is thin, contested, or written by
  one person.
- A new stakeholder has joined, or the project needs a reset.
- Stage 3 keeps stalling because the decision, the success measure or the
  constraints aren't agreed.
- The team is about to run research and nobody has asked what the
  stakeholders would do with each possible answer.

## Don't use it when

- You need to know what users do or want. Stakeholders can tell you what
  they believe about users; that's an [assumption] until users confirm
  it.
- A single agreed brief exists and the stakeholders wrote it together. A
  workshop to align on the problem (`workshops-stakeholder-workshops.md`)
  may fit better when the group needs to decide something together.

## Who, and when

Anyone who has an interest in the outcome or whose help the project
needs, inside the organization or outside it. Ask each one at the end,
"Who else should I talk to?", and follow the chain until the names
repeat. Early is best: at kickoff, before the research is planned, so
what you hear shapes the plan.

## Session shape (30 to 45 minutes)

One at a time, not in a group; people say in private what they won't say
in front of their peers or their manager. An informal setting ("a coffee
about the project") helps.

1. **Open (3 min).** Who you are, what the project is, why you're asking,
   what will happen to what they say (summarized, not attributed, unless
   they agree).
2. **Success (10 min).** "What would make this project a success for
   you?" "How will you know?" "What number would you look at?" Push for
   something that could be measured, and note when there isn't one.
3. **Priorities (10 min).** "If we could only fix one thing, what?"
   "What's not worth doing?" "What's the decision this research feeds,
   and what are the options on the table?"
4. **History and expertise (10 min).** "What's been tried?" "What do you
   already know about these users, and how do you know it?" "What went
   wrong last time?" Their knowledge of the domain is often deep; their
   knowledge of users is often secondhand. Ask which it is.
5. **Process (5 min).** "Who decides?" "When?" "What's in the way?" "What
   do you need from research, and in what form?"
6. **Close (2 min).** "Who else should I talk to?" "Anything I should
   have asked?" Thanks, and when they'll hear back.

Stay neutral. Don't argue with a wrong belief about users; note it as
something the research can check. Ask open follow-ups ("Say more about
that") and let them finish.

## What makes it good

- A goal for each interview, written before it: what this person can
  tell you that nobody else can.
- A short guide, used loosely. The four topics (success, priorities,
  history, process) and a few probes.
- Beliefs about users written down as beliefs, with who holds them.
  These become hypotheses for the study, and some become the most useful
  findings when the research contradicts them.
- A thank-you afterwards that says what you heard and what happens next.
  It keeps the channel open for the readout.

## Analysis

With five or fewer stakeholders, summarize informally: the success
measures each named, where they agree and disagree, the beliefs about
users to check, the constraints. With more, code the notes as for
interviews (stage 7) and report the themes. Then feed stage 3: the
decision, the success measure, the audience, the hypotheses, the
constraints and the "what would you do with each answer" lines come
from here, each attributed to the stakeholders who said it.

Disagreement between stakeholders is a finding. Put it in the study
record and raise it before the research is planned, because the research
can't settle a disagreement nobody has named.

## Worked example

> **Project.** A research round on BrightPay's (payroll) onboarding,
> asked for by the product lead with a two-line brief.
>
> **Interviews.** Six, one-to-one, 30 minutes each: the product lead,
> the design lead, the support manager, the sales lead, an engineer who
> built the current onboarding, and, named by three of them, the finance
> partnerships manager.
>
> **What they said.** Success: "fewer onboarding support tickets"
> (support), "more accounts live within a week" (product, sales), "no
> number" (design). Beliefs about users: "small firms give up at the
> HMRC step" (sales, from calls), "accountants don't read the setup
> guide" (support, from tickets). History: a guided setup was tried in
> 2024 and dropped, nobody could say why; the engineer found the
> retrospective.
>
> **Into stage 3.** Decision: whether to rebuild guided setup, product
> lead, end of quarter. Success measure: accounts live in seven days
> (two stakeholders), with support tickets as a second measure.
> Hypotheses H1 and H2 from the beliefs above, each with who holds it.
> Disagreement logged: sales wants small firms first, support wants
> accountants; raised before the plan was written.

## Pitfalls

- Treating a stakeholder's belief about users as a finding.
- Interviewing only the sponsor.
- Letting the interview become a pitch for the research, or a complaint
  session about another team.
- Attributing something said in confidence.
- Writing the plan before the stakeholder with veto power has been heard.

## Template

Adapt `templates-interview-guide.md`: the four topic blocks above with
two or three probes each, and a closing "who else" question. Record the
answers in the study record under context, with the stakeholder named
as the source.

## Basis

S92 (who to interview: anyone with an interest in the project or whose
cooperation it needs, internal or external; when: kickoff, a new
stakeholder, a reset; a concrete goal and a semistructured guide; one on
one, framed informally; neutral, active listening, open follow-ups; the
four topics success metrics, priorities, history and expertise, process
and workflow; closing with "who else should I speak to?"; a thank-you
afterwards; informal summary for five or fewer, thematic analysis for
more). Session timings, the belief-as-hypothesis rule, feeding stage 3,
and the pitfalls: practitioner judgment.

---

Part of Magpie version 2026-11-12, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: methods-surveys.md -->

# Method: surveys

Ask many people the same questions to measure how common an attitude,
behavior or need is.

## Use it when

- The question is *how many*, *how often*, or *which groups differ*.
- You already understand the problem well enough to write good closed
  questions. (If you don't, interview first.)
- You can reach enough of the right people to say something about them.

## Don't use it when

- The question is *why*. Surveys get thin answers to why.
- You'd be surveying whoever's easiest to reach and calling it "users".
- A number already exists in analytics.
- You can't get enough answers to analyze. Check this first; see "Can it
  get enough answers?" below.

## Can it get enough answers?

Before writing a single item, do this sum. It's the first question in
survey planning, and it can be done on a phone calculator.

1. **Responses needed.** How many answers the analysis needs. For an
   overall picture of one group, a few hundred. To compare groups, enough
   in each group that a difference would show; the smaller the difference
   you need to see, the more you need. Stage 7 has the sample size rules.
2. **Response rate.** What share of invited people answer. Use the rate
   from a past survey to a similar group; otherwise guess low, and say
   it's a guess.
3. **Invites needed** = responses needed ÷ response rate.
4. **Invites available.** How many of the right people the tool can reach,
   after removing anyone who can't be contacted or was surveyed recently.
5. **Viability** = invites available ÷ invites needed.

Above 1, the survey can get what it needs (at exactly 1 it uses every
invite, leaving none for other surveys). A little below 1 means weaker
results the team may accept. Well below 1, the survey isn't viable as
planned. To raise the number: shorten the survey, add an incentive or a
reminder, target better, cut the number of groups to compare, or widen who
is eligible. Don't lower the bar for how sure you need to be.

Example: a team wants 390 answers, past surveys to this group got 1.5%,
so they need 26,000 invites. They can reach 100,000 people. Viability is
about 3.9. Go ahead.

## Sample

- Who answers matters more than how many. A self-selected sample describes
  the people who chose to answer. Engaged users answer more than others,
  so the answers lean their way.
- Rough guide: a few hundred responses for an overall picture; enough in
  each group you want to compare that the comparison means something. Plan
  the cross-tabs before you send.
- Where the team knows the make-up of the whole user base (from logs:
  tenure, plan, usage, country), the answers can be weighted so each
  group counts in proportion to its real size. This needs an analyst and
  a larger sample; say in the readout whether it was done. Don't weight
  an experiment where people were assigned at random; that already
  handles it.
- The margin of error shrinks with the square root of the sample, not
  the sample: halving it takes about four times the responses (a margin
  of about 20 points from 20 answers needs about 80 answers to reach 10
  points). Decide the precision the decision needs, then the sample.
- Say the response rate and who answered in the readout.

## Question types

- **Closed, one answer.** The workhorse. Keep lists short, four or five
  options where you can; more only for factual items such as role or
  country. Lists must cover every real answer and not overlap; add "other"
  and "don't know" where they're honestly possible.
- **Closed, pick all that apply.** People pick fewer than they would if
  asked one by one. Where the list is short, ask each as its own yes/no
  (forced choice); answers are more accurate, especially on sensitive
  topics.
- **Rating scale.** Five or seven points, words on every point or at least
  both ends, as many positive as negative points, and the same scale
  throughout. Keep the order of the scale fixed; its order carries
  meaning. If you worry the first option draws answers, show half the
  people the scale reversed.
- **Agree/disagree.** Use sparingly. People lean toward agreeing, more so
  with less schooling and with an interviewer present. Ask the thing
  directly instead ("How often do you…", "How would you rate…"), or offer
  a choice between two statements.
- **Open-ended.** One or two, where a story helps, never required. An open
  item early in a survey can find the answers a closed list should offer
  later; run a small open pilot, then build the closed list from what
  people said.
- **Validated questionnaires.** For common things (perceived usability, task
  ease), use a published scale as written (`methods-usability-testing.md`,
  "Follow-up questions"). The wording has already been tested, and the
  score can be compared with published figures. Beyond the SUS: the
  CSUQ (16 items, seven points, free) for any system; the SUPR-Q (eight
  items) for websites, with paid norms; the WAMMI (20 items, licensed)
  for websites; the UEQ or AttrakDiff when the question is how a
  product feels rather than how usable it is; the TAM's two six-item
  scales for perceived usefulness and ease of use. Use one as
  published; small wording swaps ("website" for "system") don't change
  what it measures. When space allows only two items, the UMUX-LITE
  stands in for the SUS (`methods-usability-testing.md`, "Debrief").
  If the survey carries a Net Promoter question, keep the 0 to 10
  answers and report their mean with a range, not only the net score
  (`methods-benchmarking.md`).

## Wording

Small changes move answers a lot, so every item goes through
`checks-survey-wording.md`. The rules that matter most:

- One idea per item. No double-barreled questions.
- Plain words for the audience. No jargon, internal names or double
  negatives.
- Behavior over a specific period: "In the last 30 days…" beats "usually".
  The past, not the future: "Would you use…?" gets kind answers, not true
  ones.
- Watch loaded words. The same policy gets different support under two
  names.
- People under-report what looks bad and over-report what looks good.
  Soften the frame ("Some people don't get round to X; in the last month,
  did you…?") and make the less flattering answer easy to give.
- Trend surveys keep wording, order and channel the same every wave.
  Change any of them and the trend breaks.
- Not sure between two wordings? Give each to half the sample at random.
  If the answers differ, the wording did it.

## Order

Earlier questions change later answers.

- General before specific. A specific question first ("How is the export
  feature?") pulls the general one ("How is the product?") toward it.
- Open-ended questions about problems or priorities go early, before
  closed items plant ideas.
- Start with easy, interesting items. Don't stack hard ones. Demographics
  last, unless needed to route people.
- Rotate the order of options in lists with no natural order (brands,
  features). It doesn't remove the order effect; it spreads it evenly.
  Don't rotate a scale.

## Survey shape (under ten minutes)

1. Intro: what it's for, how long, what's done with answers.
2. Screener: behavior-based.
3. Main sections, general to specific, one topic each.
4. One or two optional open-ends where a story helps.
5. Demographics last, each with "prefer not to say".
6. Thanks, and what happens next.

The survey is part of the product experience. People don't separate "the
survey" from the company that sent it. Too long, too often, broken
branching, an image that doesn't load, or a question that makes no sense
all cost goodwill, and a mistake reaches thousands of people at once.
Match length to what people are motivated to give, watch how often the
same people are invited, and test the built survey, not only the
question list.

## Test it before sending

Every new survey gets a cognitive test: a few people answer it while
thinking aloud, then say what each question meant to them, why they chose
their answer, and where the words or the options were unclear. It
catches four kinds of failure: the question isn't understood, the event
can't be recalled, the answer is shaped by an earlier item or by what
looks good, or the options don't fit.

- **Fast way (one to two days).** Put the survey link in an unmoderated
  testing tool with instructions to flag unclear words, missing options
  and confusing questions. Four or five people from one group find most
  of the problems; with several groups, two or three from each. Save the
  test as a template and rerun it after changes.
- **Moderated way.** Worth it for a complex survey, a tracking survey
  (bad wording compounds every wave and can't be changed later without
  breaking the trend), a survey in more than one language (test each
  language, or at least have a native speaker who didn't translate it
  read it), or a decision too big to get wrong.
- **Skip or shorten it** only for items taken from a published, validated
  questionnaire.

Have colleagues click through the built survey too. Branching that leads
nowhere and text that fails to fill in show up only in the real thing.

## Analysis

Descriptives first: counts and percentages with the base shown. Cross-tabs
only where groups are big enough. Open-ends coded like interview data
(`methods-customer-feedback-coding.md` covers coding at volume). Say what
the numbers can and can't support; don't claim significance without a
test, and even with one explain it in plain words. Stage 7 covers this,
including how to state a test result, a margin of error or a sample size.

Report differences in their own units: "9 percentage points more
completed", "17 seconds faster", "0.4 points higher on a 7-point scale",
with the range the true difference probably sits in. A standardized
effect size on its own ("d = 0.3") means nothing to the team. Whether a
difference is big enough to act on is a separate question from whether it
is real; agree the bar before the data arrives, not after.

## Worked example

> **Decision.** Whether Larder (meal planning) builds a shared household
> plan, or keeps plans personal. Decision in eight weeks.
>
> **Research question.** How many Larder users plan meals with someone
> else in their household, and does that differ by household size?
>
> **Viability.** Needed: 400 responses to see a 10-point difference
> between one-adult and two-adult households. Past response rate to this
> list: 2%. Invites needed: 20,000. Reachable, excluding anyone surveyed
> in the last 90 days: 64,000. Viability 3.2. Go.
>
> **Items.** Behavior over a period ("In the last 30 days, how many times
> did someone else in your household change your meal plan?"), one
> rating with labels on every point, demographics last. Cognitive test
> with five users in an unmoderated tool: "change your meal plan" read
> three ways; reworded to "add, remove or swap a meal".
>
> **Result, as reported.** 441 responses (2.2% of 20,000 invited;
> respondents skewed to weekly users). 38% of two-adult households
> (112 of 295) said someone else changed the plan in the last 30 days,
> against 9% of one-adult households (13 of 146); a difference of 29
> points, likely between 21 and 37. Agreed bar before fielding: 15 points.

## Pitfalls

- "Would you use…?" items. Ask about the past, not the future.
- Agree/disagree batteries that people agree their way through.
- A 25-item survey that gets ten honest answers and fifteen fast ones.
- Reporting percentages from forty responses as if they were the market.
- Sending without a cognitive test, then finding out from the open-ends
  that a question was read three ways.
- A viability sum done after the survey is written, when the team has
  already promised the result.

## Template

`templates-survey.md`

## Basis

Viability: S79 (invites needed = target responses ÷ response rate;
viability = invites available ÷ invites needed; above 1 proceed, at 1 no
invites left for other surveys, well below 1 not viable; ways to raise it;
don't lower alpha or power; the worked example). Weighting: S83
(respondents rarely mirror the user base; engaged users respond more;
in-house teams can weight on log variables such as tenure and usage;
don't weight a randomized experiment; weighting needs a larger sample and
expert tools). Question types, wording and order: S88 (closed lists of
four or five options; forced choice over select-all; agree/disagree
invites acquiescence, stronger among less-educated respondents and with
an interviewer; loaded words; social desirability and softening the
frame; identical wording and mode for trends; split-sample wording tests;
contrast and assimilation effects; open before closed on the same topic;
engaging items first, demographics late; ordinal scales kept in order,
sometimes reversed for half the sample; nominal lists rotated; open pilot
to build closed lists; pretesting with cognitive interviews). Also S6
(ask only what the research questions need; neutral wording); S8 (past
behavior over future intentions); S40 (word-labeled scales; acquiescence
and social desirability bias). The survey as part of the product
experience: S82 (people don't separate a survey from the brand; length,
frequency, broken branching and media; test the built instrument; a
colleague click-through). Cognitive testing: S80 (the four stages
comprehension, retrieval, judgment, response; when it's needed most:
tracking surveys, high-stakes decisions, multiple languages; validated
scales need less); S81 (the unmoderated fast way, one to two days; four
or five from one group, two or three per segment; save as a template).
Reporting differences: S84 (raw, unstandardized differences with
intervals; standardized effects hide the unit and distort near a scale
ceiling); S85 (set the "big enough" bar before collecting data; make
effects concrete). The other standardized questionnaires: S100 (pp. 226–237: WAMMI,
SUPR-Q and their norms databases and licensing; CSUQ as a PSSUQ
variant with the same scoring; USE; hedonic quality, AttrakDiff and
the UEQ; the TAM's two scales; minor wording changes don't change the
factor structure; pp. 211–214: the UMUX-LITE as a two-item stand-in
where survey space is short; p. 235: the NPS and its lost sensitivity).
The four-times rule for halving a margin of error: S100 (pp. 19–24:
a confidence interval is set by the confidence level, the variability
and the sample size; to cut the margin in half you need about four
times the sample). Sample size rule of thumb ("a few hundred"), the
ten-minute limit and the survey shape: practitioner judgment.

---

Part of Magpie version 2026-11-12, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: methods-usability-testing.md -->

# Method: usability testing

Watch people try to do real tasks with a design, and learn where and why
they struggle. Moderated (you're there) or unmoderated (a tool records them).

## Use it when

- You have something to test: a prototype, a live product, a competitor's.
- The question is *does this work for the people it's for*, and *where does
  it break*.
- You need to know why people fail, not just that they do (moderated), or
  task success at a larger scale (unmoderated).

## Don't use it when

- You don't yet know what problem the design is solving. Interview first.
- The question is about desirability or value, not usability. Test the
  concept instead.

## Sample

- Moderated: five people from one user group find most of the problems.
  With two distinct groups, three or four from each; with three or more,
  three from each. Run another small round after fixes rather than one big
  first round.
- Why five: across many studies the average chance that one person hits
  any given problem in one round is about 0.31, so five people reveal
  about 85% of the problems that round can show. It was never 85% of
  the product's problems. Nielsen's own account is fishing in ponds: a
  round empties the easy problems from one pond, and the next round,
  with the fixes and often new tasks or a new group, fishes a new one.
  Five only works as part of that loop. A mature website with the easy
  problems already removed, or loosely structured tasks, can have a
  per-person chance near 0.03, where five people show about 14% and
  85% takes about 65. If late participants keep finding new problems,
  the round isn't done.
- How often a problem appears says nothing about how severe it is;
  plan as if the two are unrelated, and expect serious problems from
  late participants too.
- Rates from a small test (completion, time) follow stage 7's "Numbers
  from small samples": an adjusted-Wald interval, the geometric mean for
  times.
- Unmoderated, for rates (task success, time on task): more than thirty
  people, and forty or more if you want ranges narrow enough to compare.
  Five people can show problems but can't give you a rate.
- Recruit people who would actually do these tasks.

## Session shape (moderated, 30 to 60 minutes)

1. Opening: we're testing the design, not you. Think aloud. There are no
   wrong answers. What's recorded.
2. Brief context questions about how they do this today.
3. Tasks, one at a time, as scenarios: "You want to…", never "Click the…".
4. After each task: a rating of how easy or hard it was, then "why that
   rating?", then what they expected to happen. See "Follow-up questions"
   below.
5. Debrief: go back to the moments that mattered, then overall
   impressions, anything missing, thanks.

## Remote, moderated

The same session over a video call with screen sharing. It's often
cheaper and quicker than meeting in person, easier for participants, and
reaches people who can't travel. It takes more preparation.

- Pick a call tool that participants, observers and the moderator can all
  use. Check it works on the participant's device and browser while
  screening.
- Decide how tasks reach the participant: a document with one task per
  page that they don't read ahead in, or one task at a time in the chat,
  read aloud by the participant. Reading tasks aloud yourself is the
  weakest choice.
- Hold a short tech check the day before (about 15 minutes), using
  something other than the design you're testing: install the tool,
  check sound and screen sharing, and do the consent form.
- Remind participants the day before: charged device, headset, a strong
  connection, somewhere quiet and private.
- Keep observers muted, keep team chat where the participant can't see
  it, and give observers the task list and what to watch for.
- Recruit a few extra people, leave spare time in each session for tech
  trouble, and have a backup plan.
- Run a pilot first. It tests the test, not the design, so a colleague
  can do it.
- At the start, ask permission to record and confirm the end time.

## Testing with assistive technology

Some sessions, in most studies, should be with people who use a screen
reader, magnification, speech input, switch access or the keyboard
alone. `lenses-accessibility.md` covers recruiting and running them; the
points that change the test itself:

- **Clear the obvious first.** Have someone who knows accessibility check
  the design against a standard (WCAG) before the sessions, and fix what
  that finds. Then the sessions find what only users can show.
- **Match the participant to the audience.** An expert screen-reader user
  suits a tool for specialists; a public service needs people who are
  new to their assistive technology too. Recruit a range; one person's
  experience doesn't stand for everyone with that disability.
- **Their own setup.** Their device, their software, their settings.
  Check in the tech check that the prototype works with it at all; if it
  doesn't, that's a finding, not a session.
- **Think-aloud, with more help from the moderator.** Ask what they hear
  and what they're trying to do, and point tasks at the parts of the
  design the team is unsure about.
- **Analyze the cause, not only the failure.** An error can come from the
  content, the browser, the assistive technology, the person's
  familiarity with it, or plain bad design. Record which, with the
  technology and settings next to each issue, and report what blocked
  people ahead of time on task.
- **Don't generalize from a few.** Say in the report who took part, with
  what technology, and that the sessions were not a conformance check.
  The team needs both.

## What makes it good

- Tasks have a written success criterion before the session.
- Tasks are realistic and in a realistic order.
- The moderator doesn't help. "What would you do if I weren't here?"
- Observers take notes against the tasks, not freeform.
- Severity is rated per issue on three things: how many hit it (frequency),
  how hard it was to get past (impact), and whether it would keep bothering
  people or only the first time (persistence).

## Follow-up questions

Watching shows where people struggle; follow-up questions show why. Ask
them after the task, not during it, so you don't change what happens.

**After each task**

- One ease rating, in the style of the Single Ease Question (SEQ): how
  easy or difficult the task was, on seven points from very difficult to
  very easy. Ask it while the task is fresh, and word it the same way
  every time.
- "Why that rating?" Then probe the reason: "You paused on the payment
  screen. What were you thinking there?"
- "What did you expect to happen?" and, if they didn't finish, "What would
  you have tried next?"

**Debrief at the end (five to ten minutes)**

- Go back to one or two moments you saw: "When you went back to the menu
  the second time, what were you looking for?" Name what they did, not
  what you think it meant.
- "What was the hardest part?" and "Was anything different from what you
  expected?"
- If you're tracking perceived usability across releases, a standard
  questionnaire such as the System Usability Scale (SUS: ten fixed items,
  a score from 0 to 100) goes here, with the wording and order unchanged.
  It needs twenty to thirty or more people per round to mean much; with
  five, use it as a conversation starter, not a score.
- SUS details: ten items on a five-point agree scale, odd items worded
  positively and even items negatively; people answer all ten right
  after using the product and before any debrief, picking the middle
  point if they can't answer one. Score each odd item as its position
  minus 1, each even item as 5 minus its position, add the ten and
  multiply by 2.5. Swapping "system" for "website" or "product", or
  "awkward" for the original "cumbersome", doesn't change the result.
  It measures perceived usability as one number; it says nothing about
  which part of the product caused it. The alternating positive and
  negative items don't measurably reduce agreement bias, and they
  cause mistakes: about one SUS dataset in ten has been found miscoded
  because someone forgot to reverse the even items. A team starting
  fresh can use the all-positive version (same odd items; even items
  reworded positive; every item scored as position minus 1, summed,
  times 2.5), and scores come out the same. A team already using the
  standard version keeps it and checks the coding every time. Either
  way, in a moderated session check the form for a reversed answer
  before the participant leaves.
- Among post-study questionnaires compared head to head, the SUS
  settled on the right answer fastest: with twelve people it agreed
  with the full-sample result every time, where other instruments were
  still wrong a quarter of the time at fourteen. That is the case for
  the SUS over home-made satisfaction items. Where there's room for
  only two items (a survey with many measures), the UMUX-LITE ("this
  system's capabilities meet my requirements", "this system is easy to
  use", seven points) tracks the SUS closely once rescaled; the book
  doesn't recommend it on its own yet, so collect both the first time.

A participant's rating and what they did can disagree. Someone who failed
the task may still rate it easy. Report both; what they did comes first.

## Analysis

Issue list: each issue with the task, how many participants hit it, severity,
and a short description of what happened. Stage 7 covers this. For
unmoderated studies: success rate, time on task, and clips of the failures.

Ease ratings from a moderated study go next to each participant's result
and reason ("P2: failed, rated 5 of 7, 'I assumed it saved'"). Don't
average five ratings or report them as a percentage; the reasons are the
finding. With more than thirty unmoderated participants, ratings can be
summarized, following stage 7's survey data rules.

## Worked example

> **Decision.** Whether Tally (expense tracking) ships the redesigned
> receipt capture flow next month or holds it for another round.
>
> **Research question.** Can people photograph a receipt and file it to
> the right expense claim without help, and where do they get stuck?
>
> **Sample.** Five people who filed an expense claim in the last month,
> moderated, remote, 45 minutes.
>
> **Tasks.** "You've just paid for a client lunch and have the receipt.
> Add it to this month's claim." Success: receipt attached to the March
> claim with the amount matching. Then the ease rating and "why that
> number?"
>
> **Issue, as reported.** 4 of 5 attached the receipt to a new claim
> instead of the existing one (P1, P2, P4, P5), because the "Add to
> claim" sheet opens on "New claim". Severity: high (frequent, blocked
> the task, would happen every time). Ease ratings 3, 4, 6, 2, 5 of 7,
> each next to its reason; no average reported.

## Pitfalls

- Leading tasks that name the feature or the button.
- Fixing a prototype between sessions without noting it.
- Counting "they found it eventually" as success.
- Reporting five participants as a percentage.
- Asking the rating, then not asking why.
- Probing during the task, so the question changes what they do next.

## Template

`templates-usability-test-script.md`

## Basis

What a test is: S47 (a facilitator, realistic tasks, a realistic
participant, thinking aloud; moderated and unmoderated, in person and
remote; the facilitator must avoid influencing behavior). Sample: S45
(five users find most problems; small rounds over one big one; three or
four per group for two groups, three per group for three or more); S46
(more than thirty for quantitative studies, forty or more for useful
ranges; five can't give rates). Tasks: S3. Severity: S48 (frequency,
impact, persistence). Follow-up questions: S38 (a post-task ease rating on
seven points while the task is fresh; SUS after the session, wording and
order unchanged, ten items, a 0 to 100 score that isn't a percentage; 20
to 30 or more users for questionnaire numbers; pair a rating with "why");
S12 (numbers from small qualitative studies carry large error). S100
(pp. 162–166: average problem-occurrence rate of 0.31 and the
1 − (1 − p)^n arithmetic behind "five users find 85%"; the guideline
misread as 85% of a product's problems; Nielsen's fishing analogy, five
being contingent on iteration with changed tasks or groups; the Spool
and Schroeder "eight is not enough" study reconciled as p near 0.029,
where five users find about 14% and 85% takes 65; serious problems found
at the same rate as others; Sauro's review of 24 tests giving p of about
0.37 for business applications, 0.23 for consumer software and 0.04 for
websites; p. 162: no reliable link between problem frequency and
severity. pp. 198–199: the SUS items, response rules, scoring and the
wording substitutions that make no difference; a single-number measure
that doesn't locate the cause. pp. 206–210: the all-positive SUS, its
scoring, no difference in scores, agreement bias or extreme responses
from the standard version; 3 of 27 SUS datasets miscoded, most likely
about 10%; researchers on the standard version should verify coding and
include a debrief step to catch reversed answers. pp. 214–215: Tullis
and Stetson's comparison of five questionnaires, the SUS reaching 100%
agreement with the full-sample conclusion at n = 12 and the CSUQ 90%,
the others in the low to mid 70s at n = 14. pp. 211–214: UMUX and
UMUX-LITE, the two items, the regression adjustment, and the authors'
advice not to use the UMUX-LITE independently of the SUS until validated
more widely).
Remote, moderated: S78 (advantages and the
extra preparation; choosing a call tool; how tasks reach the participant,
with the moderator reading them as the weakest choice; a tech check the
day before on something else; reminders; observers; recruiting extra and
spare time; a pilot that tests the test; recording consent at the start).
Background: S7. Testing with assistive technology: S98 (an expert
review for obvious barriers first; match assistive technology experience
to the audience; a range of participants, since one person doesn't stand
for all; think-aloud with high facilitator interaction and tasks aimed at
areas of concern; errors can come from content, browser, assistive
technology, unfamiliarity or poor design; focus on barriers over time on
task; combine with a conformance evaluation; don't generalize from a few;
report scope, methods and participants). Session timings, probing after
rather than during the task, the debrief, and the pitfalls: practitioner
judgment.

---

Part of Magpie version 2026-11-12, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.
