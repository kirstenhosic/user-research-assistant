<!-- Magpie, combined for Copilot. Holds `templates-journey-map.md`, `templates-notes-sheet.md`, `templates-opportunity-brief.md`, `templates-persona.md`, `templates-readout.md`, `templates-report.md`, `templates-research-plan.md`, `templates-researcher-debrief.md`, `templates-study-record.md`, `templates-survey.md`, `templates-usability-test-script.md`, `templates-workshop-agenda.md`, `templates-workshop-summary.md`. -->

<!-- file: templates-journey-map.md -->

# Journey map: [actor] [doing the goal]

| Document details | |
| --- | --- |
| Team | [team that owns the journey] |
| Date | [date of this version] |
| Built from | [study name(s), N sessions, method, dates] |
| Author(s) | [names] |
| Reviewers | [names; participants who checked it] |
| Status | Draft |

Status is Draft, Under review or Final (`operating.md`, "Files for the
team").

## Who and what

| | |
| --- | --- |
| Actor | [one persona or user group; link to the persona] |
| Scenario | [what they're trying to do, in their words] |
| What they expect | [from the baseline questions] |
| Covered by the research | [which phases the sessions actually showed] |
| Not covered | [phases filled from other sources or left blank] |

## The journey

One column per phase. Every cell carries the participants behind it.

| | Phase 1: [name] | Phase 2: [name] | Phase 3: [name] | Phase 4: [name] |
| --- | --- | --- | --- | --- |
| **What they do** | [action] (P1, P3, P5) | | | |
| **What they think** | "[quote]" (P3 14) | | | |
| **How it feels** | [from what they said and did] (P1, P5) | | | |
| **Tools and people** | [what they use, who they ask] | | | |
| **Where it breaks** | [breakdown] (N of M) | | | |
| **Finding** | [F2] | | | |

*Team only: a cell with one participant behind it says so. A phase the
research didn't cover is marked [not covered] or [assumption], not filled
in.*

## Opportunities

| Where | What goes wrong | How many | Finding | What it points to |
| --- | --- | --- | --- | --- |
| Phase 2 | [breakdown] | [N of M] | [F2] | [recommendation or question] |

## How it was built

- Sessions laid side by side: [method, N sessions, dates].
- Phases named from the steps most participants had; steps only some had:
  [listed as branches or notes].
- Checked with [N participants / against N held-back sessions] on [date].
- Differs from the team's existing journey in: [what changed, and the
  library entry that records it].

## Limits

- [Who wasn't in the sample; which phases rest on one or two people;
  what's inferred.]

---

Part of Magpie version 2026-11-05, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: templates-notes-sheet.md -->

# Note-taking sheet: [study name]

An Excel workbook that goes out with every interview guide, usability test
script and diary study, so note-takers write down what they hear under the
research question it answers. Made with `scripts/make_sheet.py`
(`operating.md`, "Files for the team").

## Sheet 1: Notes

Above the table: the study name as the title, the document details
block (below), then one line: "One row per participant. Write what you
heard under the research question it answers, with the time or question
number. Quotes in quotation marks, word for word." Note rows are tall
(about 120 points) so there's room to type.

| Participant | Session date | Who they are | Note-taker | RQ1: [question] | RQ2: [question] | Also noticed | Quotes worth keeping | Top takeaway |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| P1 | | [role, segment] | | | | | | |
| P2 | | | | | | | | |
| **Summary across participants** | | | | [what we're hearing so far] | [what we're hearing so far] | | | |

- One row per planned participant, with their code and a short
  descriptor filled in from the plan for every row, not just the first.
  No names.
- One column per research question, headed with its number and the
  question in plain words, in the order of the record.
- "Also noticed" is for things outside the research questions.
- The summary row is for the team's running read after each session or
  at the end. Every research question column gets the same placeholder. It's a note, not a finding: findings come from analysis at
  stage 7.

## Sheet 2: Research questions

| # | Research question | Priority | Decision it serves | Guide questions that cover it |
| --- | --- | --- | --- | --- |
| RQ1 | [question] | [Priority or blank] | [decision] | [question numbers from the guide] |

Priority has its own column, never folded into the number.

## Document details

A small two-column block under the title on every sheet: Team, Date,
Author(s), Reviewers and Status, as on the guide. In the JSON for
`scripts/make_sheet.py` it's the sheet's `"details"` list.

---

Part of Magpie version 2026-11-05, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: templates-opportunity-brief.md -->

# Research opportunity: [name]

One page the researcher takes to a PM or a leadership team to propose a
study. Plain words. Every claim labeled by where it came from.

**Proposed by:** [researcher] · **Date:** [date] · **Would inform:**
[decision and the team likely to make it]

## The gap

[Two or three sentences. What users are trying to do, where they struggle
or go without, and what the team doesn't know about it.]

## Why it matters to users

[One or two lines. The job, the journey step, the persona or group, in the
team's names.] [their data / partner data / assumption]

## Why it matters to the company

[One or two lines. The goal or metric it touches, in the company's own
names. What it costs to keep not knowing.] [team profile / assumption]

## What the market is saying

[One or two lines. Market research, competitor moves, win/loss, buyer
surveys. Dated and labeled; these are indirect evidence about users.]
[partner data]

## What we already know

[Library entries, past studies, support themes, analytics. Or "nothing
yet".]

## Where we'd want users to get to

[Optional. Leave this section out unless the team writes hills. One draft
hill in the team's own words: who it's for, what they'd be able to do, and
how we'd know it made a difference. The team agrees the wording.]

## The decision this would inform

[The team or group] could decide [what] by [when], choosing between [options].

## What a study would look like

- **Question:** [primary research question]
- **Approach:** [method, rough sample, why]
- **Cost:** [weeks of researcher time, participant incentives, partner
  time]
- **Return:** [what the team could do differently once it's answered]

## What happens if we don't

[One or two lines.]

---

Part of Magpie version 2026-11-05, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: templates-persona.md -->

# Persona: [name], [one-line description]

| Document details | |
| --- | --- |
| Team | [team that uses it] |
| Date | [date of this version] |
| Kind | [qualitative, from research / statistical, from a survey / proto persona, from assumptions] |
| Built from | [study name(s), method, dates; participant codes P1, P4, P6, P8] |
| Author(s) | [names] |
| Status | Draft |

Status is Draft, Under review or Final (`operating.md`, "Files for the
team"). A proto persona is labeled [assumption] throughout.

## In a sentence

[Who they are by what they're trying to do, not by job title or
demographics.]

> "[A real quote from a participant in this group]" (P4 22)

## What they're trying to do

- [Goal, in their words] (P1, P4, P8)
- [What they're measured on, or what success looks like to them]

## How they do it now

- [Steps, tools, the workarounds] (P4, P6)
- [How often, in what setting]

## What gets in the way

- [Pain point, with the breakdown it causes] (3 of 4: P1, P4, P6)
- [Pain point]

## What they'd never do

- [The thing the team assumed they'd do and they don't] (P1, P8)

## How they differ from [other persona]

[The dividing line: the goal, frequency, setting or constraint that made
the findings different. If the two would make the same decision in every
scenario the team cares about, merge them.]

## Where they appear in the journey

[Link to the journey map; the phases where this persona's breakdowns
cluster.]

## What this persona can't say

- How many users are like this. [The study was N people; sizing needs a
  survey.]
- [Whether the group holds outside the sample: who wasn't included.]

## Keep it current

| Study | Date | What changed |
| --- | --- | --- |
| [study] | [date] | [built / confirmed / changed: what] |

---

Part of Magpie version 2026-11-05, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: templates-readout.md -->

# Readout: [study name]

Slide-by-slide outline. Each heading is one slide unless it says otherwise.
Formatting follows the team's template if there is one, and
`templates-house-style.md` for anything it leaves open.
No more than 20 slides by default; many teams want fewer. Before drafting,
Magpie asks who's in the room and how long the slot is, and sizes the deck
to that.

The deck tells one story: why we asked, what we did, what we found, what it
means, what to do. Each slide should follow from the one before it. If a
slide doesn't move the story, it goes to the appendix.

## 1. Title

[Study name] · [date] · [researcher] · [the team or group it's for]

## 2. Why we did this

The foundation. One slide, sometimes two.

- **The product:** [optional: what it is, what it does, who uses it, in one line]
- **The decision:** By [when], the team will decide [what]
- **The business need:** [goal or metric at stake, in the team's own words]
- **What we already knew:** [prior research, partner data, or "no prior
  evidence"]
- **The question:** [primary research question in plain words]
- **Where it sits:** [job, journey step, persona, in the team's names]

## 3. What we did

Brief and factual: [method], [N] participants, [who they were], [dates].
One slide. Keep it to the structure of the study. Weaknesses and gaps are
not on this slide; see "Limits" below.

## 4. Top findings

Never more than five: the highest-priority findings for this decision,
in priority order. At least one answers the primary research question;
if the data didn't answer it, one line says so and why. One line
each, with the question it answers, priority, confidence and whether it's
enough for this decision. This is the slide people photograph. An
unexpected finding belongs here when its priority puts it there.
Priority and confidence sit side by side; neither changes the other
(`lenses-confidence-and-priority.md`).

1. [Finding, one line] · Priority: [high / medium / low] ([impact], [reach]) · Confidence: [strong / moderate / weak] ([why, a few words]) · [enough / enough if [caveat] / not enough] [· check next]
2. …

## 5 to [n]. Findings in detail

One finding per slide, in the same order as the top findings. Pitched for a
PM and engineering audience: enough to believe it and act on it, no more.

**Finding [n]: [claim in plain words]**

- **Priority:** [high / medium / low]. [Impact: what happens to people who hit it, and what it means for the decision.] [Reach: how many target users, how often; "how common it is across all users isn't known" without outside data.]
- **Confidence:** [strong / moderate / weak]. [Count and segments; who they are against the target users; seen, past time or opinion; other sources agree, disagree, or "first study on this, no other sources".]
- [Evidence with numbers: "6 of 8 participants…"]
- [Receipts: at least two participant codes with locations, or "single case"]
- [One quote with a participant code and descriptor, "— P3, finance manager, SMB"; two at most]
- **What cuts against it:** [who didn't fit, in one line]
- **What it means:** [one line]

Anything deeper (coding, more quotes, per-participant detail) goes in the
appendix.

## [n+1]. Other findings

One slide. Every finding that met the evidence bar but isn't in the top
five, one line each with strength. Tag the ones that fell outside the
research questions "unexpected". Nothing that passed the evidence bar is
dropped; a finding whose evidence didn't hold goes in the appendix with
the reason.

- [Finding, one line] · [strength] · [unexpected, if so]
- …

## [n+2]. Summary

The story in three or four lines, drawn from this study's focus, goals
and findings. Things to look for: what we asked, what we found, what it
means for the product or the business, how confident we are. Use the
ones this study speaks to. For an audience that wants the answer first,
this slide can come second, right after the title.

## [n+3]. Recommendations

Detailed. Each one is an action, the teams it touches, the finding it
rests on, and the goal or metric it moves. The "moves" column is where
business value becomes visible: use the names the team already tracks.
Name the teams each action touches, not a person. Who takes each action
is often for the teams to agree together; name a person only when the
researcher asks for it.

| Action | Teams involved | Rests on | Moves |
| --- | --- | --- | --- |
| [action] | [teams] | Finding [n] | [goal or metric] |

If it helps the audience, split into "for design", "for engineering", "for
product".

## [n+4]. Next steps

Same four parts as the report's next steps. Magpie drafts them from the
findings and the record's context; they stay "draft" until the researcher
has reviewed and edited them. Name teams, not one person, unless the
researcher asks for a name.

- **What happens now:** [step, the teams involved, by when]
- **Open questions:** [question → more research / a decision / nothing yet]
- **Researcher's next steps:** [what the researcher will do next]
- **How we'll know it worked:** [when the team looks back, and the sign that would show it worked]

## [n+5]. Limits (researcher's call)

Magpie always drafts this slide and always writes the limits into the study
record and the report. Whether it appears in the readout is the researcher's
decision, made with the audience in mind. Magpie shows the draft to the
researcher first and asks.

- [Sample gaps]
- [What the method can't tell us]
- [Challenges skipped during the study, from the record's risks]

## Appendix

For anyone who wants the deeper dive. Not counted against the 20.

- Participant profile
- Full findings with evidence, counter-evidence and coding frame
- Instruments
- Independent review summary
- How AI was used: the same lines as the report's (`templates-report.md`, "How AI was used")
- Links: study record, report, raw material (access-controlled)

---

## Option: decision-first order

For a senior audience with ten minutes, or a team that already knows the
study. Magpie offers it when the audience is named as senior or the slot is
under fifteen minutes; otherwise the default above applies.

1. The decision and the answer (decision, what the evidence supports, how
   sure we are, what we recommend)
2. Recommendations, with the teams involved
3. What we did, in one slide
4. Top findings, then detail only where needed
5. Other findings, one slide
6. Next steps
7. Appendix

## Sizing to the audience

| Slot | Slides | What to cut first |
| --- | --- | --- |
| 10 minutes, senior | 6 to 8 | Detailed findings beyond the top three; partner sections. The other-findings slide stays, even if it's the last one |
| 30 minutes, product trio | 12 to 16 | Second quotes, appendix material on main slides |
| 60 minutes, wider team | up to 20 | Nothing on the main deck; put discussion time in the agenda |

---

Part of Magpie version 2026-11-05, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: templates-report.md -->

# Research report: [study name]

**Author:** [researcher] · **Date:** [date] · **For:** [the team or group] ·
**Study record:** [link]

A report is read by people who weren't in the readout and by people who come
back to it months later. It can go deeper than the readout, but it's still
written for a PM, designer or engineer, not for another researcher. Ten
pages or fewer, not counting images and the appendix. Less is better as long
as the background, the findings with their evidence, and the recommendations
are clear.

Formatting follows the team's template if there is one, and
`templates-house-style.md` for anything it leaves open. The headings below
are the ones Magpie uses. Where the document tool
supports it, the contents list links to each section; Magpie writes it as
Markdown links to the headings so it works in most tools.

## Contents

- [Summary](#summary)
- [Why we did this](#why-we-did-this)
- [What we did](#what-we-did)
- [Top findings](#top-findings)
- [Findings in detail](#findings-in-detail)
- [Other findings](#other-findings)
- [Recommendations](#recommendations)
- [Next steps](#next-steps)
- [Limits](#limits)
- [Glossary](#glossary)
- [Appendix](#appendix)

## Summary

Five to eight sentences, drawn from this study: its focus, its goals and
what it found. Things to look for, where the study speaks to them: the
answer the evidence supports, how confident we are, what it means for the
product, what it means for the business, and the main recommendation. Not
every summary needs all of them. Someone with two minutes reads only this.

## Why we did this

- **The product:** [optional: what it is, what it does, the part studied, and who
  uses it; who buys or sets it up, if different]
- **The decision:** By [when], the team will decide [what], choosing
  between [options].
- **The business need:** [goal or metric at stake; cost of getting it
  wrong]
- **What we already knew:** [two or three lines; link to prior research or
  the evidence log]
- **The questions:** [primary, then secondary, each in plain words]
- **Where it sits:** [the job, the journey step, the persona or group, in
  the team's names]

## What we did

One short paragraph: [method] with [N] [who], recruited by [how], [dates],
and why this method for these questions. Link to the plan and instruments
in the appendix. No timeline, no recruiting mechanics, no consent detail
here; those live in the study record and the appendix.

## Top findings

Never more than five, the highest-priority findings for this decision, in
priority order. At least one answers the primary research question; if
the data didn't answer it, one line says so and why. One or two lines
each, with the question it answers, priority, confidence and whether it's
enough for this decision. A not-enough finding says what would
make us surer and roughly what that costs; a high-priority finding with
weak confidence is marked "check next".

1. **[Finding]** · Priority: [high / medium / low] ([impact], [reach]) · Confidence: [strong / moderate / weak] ([why]) · [enough / enough if [caveat] / not enough: [what would make us surer]]
2. …

## Findings in detail

One section per top finding, same order. More depth than the readout:
the evidence, the counter-evidence, what it means, and where to look for
more. Images where they help: a screenshot of the moment people stalled, a
chart of task success, a photo of the workaround. Each image has a one-line
caption saying what to see in it.

### Finding 1: [claim in plain words]

**Priority:** [high / medium / low]. Impact: [what happens to people who hit it, and what it means for the decision]. Reach: [how many target users, how often; say if it isn't known outside the study].
**Confidence:** [strong / moderate / weak], because [count and segments; fit to the target users; seen, past time or opinion; other sources agree, disagree, or this is the first study on it].
**Answers:** [question].

[Evidence with numbers and participant codes. Two or three quotes at most,
each with its code and descriptor: "— P3, finance manager, SMB".]

[Image with caption, if it helps.]

**What cuts against it:** [participants who didn't fit, what they did or
said.]

**What would change this:** [what would prove it wrong, and the other
explanations: each ruled out, with the evidence, or still open, with what
would settle it.]

**What it means:** [for the decision, two or three sentences.]

**More:** [link to the appendix section, clips, or the study record.]

### Finding 2: …

## Other findings

Every finding that met the evidence bar but isn't in the top five, in
priority order, one line each with priority and confidence, tagged "unexpected" where it fell outside the
research questions. Nothing that passed the evidence bar is left out; a
finding whose evidence didn't hold is in the appendix with the reason.

## Recommendations

Detailed. Each is an action, the teams it touches, the finding it rests
on, the goal or metric it moves, and how confident we are. Number the
actions in the priority order of the findings they rest on, unless the
researcher orders them differently. Add a sentence or two under the table where an
action needs explaining.
Name the teams each action touches, not a person. Who takes each action
is often for the teams to agree together; name a person only when the
researcher asks for it.

| Action | Teams involved | Rests on | Moves | Confidence |
| --- | --- | --- | --- | --- |
| 1. [action] | [teams] | Finding [n] | [goal or metric] | |

[Notes on any recommendation that needs them.]

## Next steps

Magpie drafts all four from the findings and any relevant context in the
record (the decision and its date, partners, open risks), and labels them
"draft" until the researcher has reviewed and edited them. Name the teams
involved, not one person, unless the researcher asks for a name.

- **What happens now:** [step, the teams involved, by when]
- **Open questions:** [question → what would answer it: more research, a
  decision, or nothing yet]
- **Researcher's next steps:** [follow-up research, check-ins with
  partners, what the researcher will do next]
- **How we'll know it worked:** [when the team looks back, who looks with
  the researcher, and the sign that would show the change worked]

## Limits

Always in the report, briefly: sample gaps, what the method can't say,
challenges skipped during the study (from the record's risks). Two to five
lines. This is the durable record, so it stays even if the readout left it
out.

## Glossary

Only if the report uses terms the reader may not know. One line each.
Skip the section if there's nothing to define.

## Appendix

Linked from the contents and from the findings. Not counted in the ten
pages.

- Participant profile
- Research plan, instruments (guide, script, survey)
- Full findings with coding frame and all supporting quotes
- Partner data used, with source and date
- Consent, data handling and retention
- Independent review: what it found and what changed
- How AI was used (below)
- Library entries written from this study
- Links to recordings, clips and raw material (access-controlled)

### How AI was used

Five or six lines, written from the study record, so a stakeholder can
see which parts an AI drafted and which a person did or checked. Plain
facts, no reassurance.

- **Assistant:** Magpie, running in [the assistant, if known].
- **What it drafted:** [outputs from the record's Outputs table, such as
  the plan, the guide, the findings, this report]
- **What the researcher did:** [the your-turn steps they took, from the
  record; the theme decisions; each output's review date, or "not yet
  reviewed"]
- **Checks:** quotes and counts checked [by code / by hand]; independent
  review by a separate AI pass, [what it found and what changed]. The
  reviewer is a model too and can be wrong.
- **Other AI tools in the study:** [an AI moderator, transcription or
  summary tool, if the record names one; otherwise leave the line out]
- **Before acting on it:** AI can make mistakes. Check quotes and
  findings against the raw material before acting on them.

---

Part of Magpie version 2026-11-05, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: templates-research-plan.md -->

# Research plan: [study name]

Two minutes to read. Everything here comes from the study record.

**Owner:** [researcher] · **Who decides:** [team or group] · **Decision due:** [date]
· **Readout:** [date]

## The product

[Optional; leave this section out if the record doesn't have it. What it is, what it does, the part this study covers, and who its end
users are. Who buys or sets it up, if different.]

## The decision

[The team or group] will decide [what] by [when], choosing between [options].

**Why it matters:** [goal or metric it moves; cost of getting it wrong]

**Decision risk:** [low / medium / high, and why]

## What we already know

[Two or three lines from the evidence log and gap summary. "No prior
evidence found" is fine.]

## Research questions

1. **Primary:** [question] → serves the decision by [how]
2. [secondary]
3. [secondary]

## Hypotheses

What the team believes now, and what we'd need to see to change our minds.

- [hypothesis] · held by [who] · would change if [what we'd see]

## Approach

- **Method:** [method]
- **Why:** [two sentences]
- **What we will have at the end:** [one line, in words anyone could repeat]
- **What it won't tell us:** [trade-offs]
- **Why this is enough for the risk:** [one line; any cut made for time or budget and what it costs]
- **Partner data:** [team, what, status]

## Participants

- **Who:** [criteria, based on behavior]
- **How many:** [number and why]
- **Who's excluded and why:** [criteria]
- **Known gaps in the sample:** [groups missing, and whether it matters]
- **Recruiting:** [source, screener, incentive]
- **Participant quality:** [fraud risk for this source; what disqualifies a participant; how they're replaced]

## Timeline

| Step | Dates | Owner |
| --- | --- | --- |
| Recruiting | | |
| Pilot | | |
| Sessions or fielding | | |
| Analysis | | |
| Readout | | |
| Decision | | |

## Consent and data

- **What participants are told:** [purpose, recording, who sees it, can stop]
- **AI tools that touch the sessions:** [none / which tools moderate, transcribe, summarize or analyze, and what participants are told about each before the session; for an AI moderator, how they stop or reach a person]
- **What's recorded and where it's stored:** [ ]
- **Who can see raw data:** [ ]
- **Deletion date:** [ ]
- **Extra care needed:** [none / describe]

## Risks

Includes every skipped challenge from the study record.

| Risk | If it happens | What we'll do |
| --- | --- | --- |
| | | |

## What the team gets

- [Readout on [date]: findings, confidence, recommendations]
- [Report, library entries, partner summaries]

---

Part of Magpie version 2026-11-05, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: templates-researcher-debrief.md -->

# Debrief: [study name]

A short private note for the researcher at the end of a study: what to keep,
what to change next time, and when to follow up. It isn't shared with the
team and isn't part of the study record or the report.

**For:** the researcher only · **Date:** [date] · **Status:** draft until
the researcher edits it

Magpie offers this once, at the end of stage 8, and the researcher can skip
it. Keep it to one screen: two or three lines per part, and leave out a
part with nothing in it. Draft it from the study record and the
conversation. Anything Magpie guessed, such as how the readout landed, is
marked [assumption] until the researcher fills it in. If the readout hasn't
happened yet, leave that part as a prompt to fill in afterwards.

## What worked

- [A choice in the plan, guide or sessions that paid off, and why]

## What I'd change next time

- [A step skipped or done late, from the record's risks and skipped
  challenges, and what it cost]
- [A question, task or recruiting choice that didn't work, and the better
  version]

## Follow-up dates

- [Date: what to check, and which team to check with. Include the "How
  we'll know it worked" date from the report's next steps. On that date,
  fill in the influence and evidence in the impact log row, if there is one]

## How the readout landed

- [Pushback or questions to expect again, and the finding that answers
  them]
- [Anything left unsaid in the room, and when to raise it]

## One skill to practice

- [One skill this study showed is worth working on, with one small step
  for next time]

---

Part of Magpie version 2026-11-05, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: templates-study-record.md -->

# Study record: [study name]

One file for the whole study. Every stage reads it and adds to it. Save it
somewhere your team can find it, and paste or upload it to pick up where you
left off in any assistant.

Last updated: [date]

## Questions for you to answer

What Magpie needs from the researcher right now, and nothing else. When a
question is answered, it comes off this list and the answer goes in its
section. When nothing is open, write "Nothing right now."

1. [the question, in a line; required ones first, then "(optional)" ones, then the review ask last: "Reply yes once you've reviewed [output]."]

## Where we are

Read this first when the record is pasted into a new conversation. Magpie
updates it whenever the stage changes or something here is settled.

- **Stage:** [1–8, as a plain phrase too: "3, framing the problem"]
- **Next step:** [what happens next, and who does it]
- **Waiting for the researcher's yes:** [outputs, or "nothing"]
- **Settings:** challenge level [standard / push me / light] · personality [on / off] · your-turn steps [offered / stopped at the researcher's request] · readout and report template [the team's: name or link / none: house style / not asked yet] · spelling and dates [American English / the researcher's variety, such as British English] · note before the first transcript [given / not yet]

**Your-turn steps and challenges.** Each is offered once per study.

| Step | Status |
| --- | --- |
| Stage 3 your turn: decision, primary question, team's questions, assumptions | not yet / done by the researcher / handed back |
| Stage 7 your turn: the researcher's patterns | not yet / done / handed back / not needed |
| Stage 8 your turn: what each partner should do | not yet / done / handed back / already in the material |
| Stage 8 impact log row | not yet / offered and made / offered and skipped |
| Stage 8 researcher debrief | not yet / offered and made / offered and skipped |
| Challenges given | [stage: the challenge in a few words, and answered / skipped / handled] |

## Product

Optional. What's being studied, so every stage works from the same
picture. Offered early, filled from the team profile, product docs or the
researcher, with guesses marked [assumption]. If the researcher leaves it
out, write "not added" and delete the lines below.

- **Product:** [name, and what it is in one plain sentence]
- **What it does:** [the main things people do with it, in their terms]
- **Part under study:** [the feature, flow or screen; "the whole product" is fine]
- **End users:** [who uses it day to day, by what they do and where; people who stopped using it, if they matter]
- **Buyers or admins, if different:** [who chooses, pays for or sets it up]
- **Where it stands:** [idea, prototype, beta or live; which platforms]
- **Recent changes:** [releases or redesigns that could date earlier evidence]
- **Source:** [team profile, product docs, the researcher, or [assumption]]

## Decision

- **Decision:** [What will be decided, in one sentence]
- **Who decides:** [the team or group that makes the call]
- **Deadline:** [When it has to be made]
- **Options on the table:** [The choices being weighed]

## Business context

- **Goal or metric this moves:** [The company goal or metric at stake]
- **Where it starts:** [the metric's value now, and when it was measured; or "[unknown: ask the team that owns it]"]
- **Who can tell us later:** [the team or role that owns the number, not a person's name]
- **Cost of getting it wrong:** [What happens if the decision goes the wrong way]
- **Decision risk:** [low / medium / high, because [can it be undone, how quickly, who and what it touches]; or [assumption]]
- **Who else cares:** [Stakeholders beyond the team that decides]
- **Job:** [what the user is trying to get done, in their terms]
- **Journey and step:** [which CUJ or journey, which step; "none tracked" is fine]
- **Persona or group:** [the team's name, with the behavior that defines them]
- **Upstream and downstream:** [what feeds this piece, what depends on it, who else touches it]

## Hypotheses

What the team believes going in. The study tests these; it doesn't set out
to prove them.

| Hypothesis | Whose belief | What would change it | Status |
| --- | --- | --- | --- |
| | | | open / supported / contradicted / no evidence |

## Evidence log

What we already know. "No prior evidence found" is a valid entry.

| Source | Date | Method | What it says | Confidence | Still valid? |
| --- | --- | --- | --- | --- | --- |
| | | | | | |

Confidence: **direct** (from users, by a sound method), **indirect** (secondhand,
such as a field rep's summary), or **anecdotal** (one-off, unverified).

## Research questions

Each question names the decision it serves.

1. **Primary:** [The question that most changes the decision]
2. **Secondary:** [Questions that sharpen the answer]

## Assumptions and risks

Known assumptions, plus every challenge that was skipped and why.

| Assumption or risk | Source | If wrong | Status |
| --- | --- | --- | --- |
| | | | open / handled / accepted |

## Approach

- **Method:** [Method chosen]
- **Why this method:** [One or two sentences]
- **What the team will get:** [One line, in words they could repeat]
- **Sample:** [Who, how many, how recruited]
- **Rigor for this risk:** [why this study is enough for the decision risk; any floor problem and the smaller question offered]
- **Trade-offs accepted:** [What this approach won't tell us]
- **Partner data requested:** [Team, what, status]

## Participants

Who the findings should speak for, and how well each participant fits.

**Target users:** [who the study is meant to speak for]

| Code | Role | Segment | Fit to target users |
| --- | --- | --- | --- |
| P1 | | | matches / partly: [how] / stand-in: [for whom] / not known |

## Instruments

- [Guide, script or survey: link or file name]

## Themes

**Researcher's patterns** (what they saw before coding, in their words):

-

**Theme review.** Riskiest first. The researcher's decision on each theme
before findings are written.

| Theme | Count and participants | Risk | Decision |
| --- | --- | --- | --- |
| | | | keep / change / split / drop |

Merged and dropped codes, and why:

-

## Findings

Each finding is a claim with its evidence, including what cuts against it.
Every count lists the participants and lines behind it: "3 of 8 (P1 06,
P5 06, P7 06)".

| Finding | Supporting evidence | Contradicting evidence | Strength and confidence line | Enough for the decision? |
| --- | --- | --- | --- | --- |
| | [codes, each tagged seen / past time / opinion] | | strong / moderate / weak: [count and segments; fit; seen or said; other sources agree / disagree / none yet] | yes / with a caveat: [what] / no: [what would make it enough] |

Strength: **strong** (consistent across most participants or statistically
reliable), **moderate** (clear pattern with exceptions), **weak** (few
participants or mixed signals). Behavior that rests only on opinions, or
a finding that rests only on stand-ins, is moderate at most. "No other
sources yet" lowers nothing (`lenses-confidence-and-priority.md`).

Each theme's finding includes one "what explains it" sentence from
participants' own reasons, with receipts, or says none were given.

### Single voices worth noting

Points one participant made that are specific and add something no theme
covers. One person's view each, not a theme.

- [P# line]: [the point]

### Coded but not reported

Codes no finding, single voice or "also noticed" line uses.

- [code]: [count] ([participants])

### Connections checked

Every background and warm-up code laid against each participant attribute
(`stages-07-analyze.md`, step 5a). List each pair checked, even with
nothing found.

| Background code | Attribute | What was found |
| --- | --- | --- |
| | | [pattern with count and participants] / nothing |

## Key findings: what would prove them wrong

For the findings the decision rests on, three at most. The researcher
goes first at the theme review (`stages-07-analyze.md`, steps 8 and
11a).

| Finding | Would be wrong if | Seen in the material? | Other explanations | Ruled out or still open |
| --- | --- | --- | --- | --- |
| | | no / yes: [codes and lines] | | ruled out: [codes and lines] / still open: [what would settle it] |

**Written by:** [the researcher, with Magpie's additions marked / Magpie, at the researcher's "you do it"]

## Priority

How much each finding matters, kept apart from how sure we are. Listed in
priority order.

| Finding | Impact and why | Reach and why | Priority | Check next? |
| --- | --- | --- | --- | --- |
| | high / medium / low: [on users; on the decision] | wide / some / narrow: [in the study; outside it, or "not known"] | high / medium / low | yes: [what would make us surer] / no |

**Order:** [agreed with the researcher on [date] / Magpie's draft, not yet
reviewed]

## Recommendations

| Action | Teams involved | Answers question | Serves decision | Confidence |
| --- | --- | --- | --- | --- |
| | | | | |

## Outputs

Everything Magpie drafted for this study, and whether the researcher has
reviewed it. An output stays "not yet" until the researcher says yes.

| Output | Version or date | Reviewed |
| --- | --- | --- |
| | | yes, [date] / not yet |

## Change log

| Date | What changed | Why |
| --- | --- | --- |
| | | |

---

Part of Magpie version 2026-11-05, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: templates-survey.md -->

# Survey: [study name]

| Document details | |
| --- | --- |
| Team | [team running the study] |
| Date | [date of this version] |
| Author(s) | [names] |
| Reviewers | [names] |
| Status | Draft |

Status is Draft, Under review or Final (`operating.md`, "Files for the
team").

## About this survey

| | |
| --- | --- |
| Length | [under 10] minutes |
| Who gets it | [who, and how it reaches them] |
| Analysis plan | [which groups to compare, and which must be big enough] |

### Research questions

1. [RQ1, in plain words]
2. [RQ2]

### How to read it

Everything from the intro to the thanks is what respondents see, written
in a plain, friendly voice, as if to one person. Notes for the team
(hypotheses, what to fix before fielding, assumptions) are at the end, so
the survey reads as respondents will meet it.

Items are numbered Q1, Q2 and so on (S for the screener, D for the
optional questions about the person), and each section names the
research question it serves. ☐ means pick all that apply, ○ means pick
one. Shaded lines in italics are routing for whoever builds the survey,
never shown to respondents. Run `checks-survey-wording.md` and the
question review (`review-question-review.md`) before fielding.

## Intro

This survey is about [topic in plain words]. It takes about [N] minutes.
Your answers are [anonymous / confidential] and used to [purpose]. You can
skip any question.

## Screener

S1. In the last 30 days, have you [behavior]?
- ( ) Yes
- ( ) No (end the survey)

## Section 1: [topic] → RQ1

First, a few questions about [topic, in their words].

Q1. In the last 30 days, how many times did you [behavior]?
- ( ) 0
- ( ) 1–2
- ( ) 3–5
- ( ) 6–10
- ( ) More than 10

Q2. The last time you [did it], which of these did you use? Select all
    that apply.
- [ ] [option]
- [ ] [option]
- [ ] Other (please say):

Q3. Have you ever [behavior]?
- ( ) Yes
- ( ) No (go to Q5)

Q4. How would you rate [thing] overall?
- ( ) Very poor
- ( ) Poor
- ( ) Fair
- ( ) Good
- ( ) Very good

*After Q4, go to Q6.*

## Section 2: [topic] → RQ2

Thanks. Next, we'd like to ask about [topic, in their words].

Q5. [item]

*If [answer], go to Q7. Otherwise, go to Q6.*

Q6. [item]

## Open-end (optional)

Q7. Is there anything about [topic] you'd want us to know?

## About you (optional)

D1. Which best describes your role?
- ( ) [option]
- ( ) Prefer not to say

## Thanks

Thank you. [What happens next, incentive if any.]

## Notes for the team

Not shown to respondents.

### Hypotheses it can speak to

- [H1, in a line, and the items that speak to it]

### Fix before fielding

- [Anything that has to change before it goes live.]

### Assumptions in this draft

- [assumption] [Each guess, and where it shows up. Respondent-facing text
  carries a short "[to confirm]" blank at most, never the explanation.]

### Fielding notes

- [Where and when it's shown, accessibility checks, what comes from logs
  rather than questions.]

### Question map

| Item | Serves | Why it sits here |
| --- | --- | --- |
| Q1 | RQ1 | [reason] |

### Waiting on

- [Pilot with five people first, and what to watch for.]

---

Part of Magpie version 2026-11-05, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: templates-usability-test-script.md -->

# Usability test script: [study name]

| Document details | |
| --- | --- |
| Team | [team running the study] |
| Date | [date of this version] |
| Author(s) | [names] |
| Reviewers | [names] |
| Status | Draft |

Status is Draft, Under review or Final (`operating.md`, "Files for the
team").

## About this script

| | |
| --- | --- |
| Length | [30–60] minutes |
| What's being tested | [prototype / live product, version] |
| Who we're testing with | [participants, in a line] |

### Research questions

1. [RQ1, in plain words]
2. [RQ2]

### How to use it

Read the quoted lines (with a bar beside them in Word) aloud as written;
they carry you from one task to the next. Tasks are scenarios, not
instructions, and each has a success criterion written before the session.
Shaded notes in italics are for the moderator and are never read aloud.
Run `checks-guide-wording.md` and the question review
(`review-question-review.md`) before using.

## Opening (3 min)

> Thanks for coming. We're testing [the design], not you. If something's
> confusing, that's useful for us to see.
>
> Please think out loud as you go. I won't be able to help much, because I
> want to see what you'd do on your own.
>
> I'd like to record the screen and audio. Only [who] will see it, and
> we'll delete it by [date]. You can stop at any time. Is it OK to start?

## Context (5 min)

> Before we start, I'd love to hear a little about how you do this today.

1. How do you do [the task area] today?
2. When did you last do it?

## Tasks

*Moderator only: for each task, record completed / completed with
difficulty / failed, time, ease rating and why, what happened, and what
they said. Ask follow-ups after the task, not during it.*

### Task 1 → RQ[n]

> Thanks, that's helpful. Now I'm going to ask you to try a few things.
> There's no rush, and remember to think out loud.

> You want to [goal, in the participant's terms, no feature names]. Show
> me how you'd do that.

*Success: [what done looks like]. Watch for: [the thing we're worried
about].*

3. Overall, how easy or difficult was that task, from 1, very difficult,
   to 7, very easy?
   a. Why that rating?
   b. What did you expect to happen?

### Task 2 → RQ[n]

> Great, thank you. Let's move on to the next one. [Scenario.]

*Success: [ ]. Watch for: [ ].*

4. Overall, how easy or difficult was that task, from 1 to 7?
   a. Why that rating?
   b. What did you expect to happen?

### Task 3 → RQ[n]

> Thanks. Here's the next one. [Scenario.]

*Success: [ ]. Watch for: [ ].*

5. Overall, how easy or difficult was that task, from 1 to 7?
   a. Why that rating?
   b. What did you expect to happen?

## Debrief and close (5–10 min)

> That's all the tasks, thank you. I've just got a few questions about how
> that went overall.

6. When you [something they did, described neutrally], what were you
   looking for?
7. What was the hardest part?
8. Was anything different from what you expected?
9. Overall, how was that compared to how you do it now?
10. Anything you expected to find and didn't?

> Thank you. Here's what happens next: [incentive, findings].

## Moderator notes

### If things get hard

- If they ask for help: "What would you do if I weren't here?"
- If they're stuck for more than [2] minutes: note it, then move them on.
- If the prototype breaks: note it, describe what would have happened, move
  on.
- Don't change the prototype between sessions without noting it in the
  record.

Take notes in the note-taking sheet (`templates-notes-sheet.md`), or the
observer sheet below for task results.

## Observer sheet

| Task | P# | Result | Time | Ease (1–7) and why | What happened | Quote |
| --- | --- | --- | --- | --- | --- | --- |
| | | | | | | |

---

Part of Magpie version 2026-11-05, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: templates-workshop-agenda.md -->

# Workshop agenda: [study name]

| Document details | |
| --- | --- |
| Team | [team running the workshop] |
| Date | [date of this version] |
| Author(s) | [names] |
| Reviewers | [names] |
| Status | Draft |

Status is Draft, Under review or Final. It changes only when the
researcher says so.

## About this workshop

| | |
| --- | --- |
| Type | [Align on the problem / understand the users / ideas from findings / prioritization / set the direction / critique, or a mix; and why] |
| Outcome | [One sentence: what the room leaves with] |
| How we'll decide | [For example: private vote, top three go ahead] |
| When | [Day, date with the month in words, time, length] |
| Where | [Room, link, or both; remote if anyone joins remotely] |
| Facilitator and note-taker | [Researcher] and [teammate] |
| Attendees | [Roles and teams; the people who will act on the output] |

## Before the day

- The pre-read goes out on [date] and will be assumed read. It's one page:
  [the decision, and the findings or the ask].
- The invite asks each attendee whether they need anything to take part
  fully.
- The board is set up and tested: everyone can open and edit it.

## Agenda

1. **Frame ([time], 10 min).** The outcome, the agenda, and how we'll
   decide. Output: everyone knows what we're here to leave with.
2. **[Step] ([time], [length]).** [Silent writing, then cluster.] Output:
   [cards on the board].
3. **[Step] ([time], [length]).** [What happens.] Output: [what exists
   afterwards].
4. **[Step] ([time], [length]).** [What happens.] Output: [what exists
   afterwards].
5. **Close ([time], 10 to 15 min).** Read back the decisions, the actions,
   the teams involved and the next steps. Output: the action list.

## Materials

- [Shared board, or cards and pens, plus a typed alternative]
- [The findings, one per slide]
- [The draft decision statement]

## Ground rules (said at the start)

- Silent writing comes before discussion.
- Everything goes on the board, not in someone's memory.
- Votes are cast privately and shown together.
- Nobody leaves until the actions and the teams involved have been read
  back.

---

Part of Magpie version 2026-11-05, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: templates-workshop-summary.md -->

# Workshop summary: [study name]

| Document details | |
| --- | --- |
| Team | [team that ran the workshop] |
| Date | [date of this version] |
| Author(s) | [names] |
| Reviewers | [names] |
| Status | Draft |

Status is Draft, Under review or Final. It changes only when the
researcher says so.

[One or two sentences that lead with the result: what the room decided or
agreed to do. Name the workshop, its date with the month in words, and who
took part by role or team.]

## What we decided

[What the room decided, in the terms of the workshop type: the decision
statement as rewritten, the picture of users it agreed, the direction it
chose, the short list, or what the next version of the design changes.
Add the deadline and the teams involved.]

[If the team writes hills: the hill the room agreed, in its own words.
Leave this out otherwise.]

## Actions

| Action | Teams involved | Rests on | Moves |
| --- | --- | --- | --- |
| [Specific action] | [Teams] | [Finding number] | [Goal or metric, in the team's names] |

Teams agree among themselves who takes each action.

## What we're still unsure of

[The believed and disputed assumptions and the research questions they
became, the gaps in the empathy map, or the "How might we" questions the
room didn't get to.]

## Ideas we didn't choose

[Each idea in a full sentence, with one line on why it wasn't picked, so
nobody has to rerun the session to find it.]

## Next steps

[The next steps the room agreed, with the teams involved and dates. When
the room meets again to check progress.]

---

Part of Magpie version 2026-11-05, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.
