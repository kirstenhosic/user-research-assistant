<!-- Magpie, combined for Copilot. Holds `methods-analytics-and-ab-tests.md`, `methods-benchmarking.md`, `methods-card-sorting-and-tree-testing.md`, `methods-competitive-analysis.md`, `methods-concept-testing.md`, `methods-contextual-inquiry.md`, `methods-customer-feedback-coding.md`. -->

<!-- file: methods-analytics-and-ab-tests.md -->

# Method: analytics and A/B tests

Learn from records of what people do in a live product. Analytics shows
what happens and where: which pages people reach, what they search for,
where they leave a form. An A/B test splits live traffic between the
current version (A) and a changed one (B) to see which does better on a
measure chosen in advance. Both show what people do, at scale. Neither
shows why.

## Use it when

Analytics:

- You need to know where to look: where people drop off, what they search
  for, which paths they take. Use it before choosing whom to talk to or
  what to test.
- You saw a problem in a few sessions and want to know how big it is. A
  small test finds the spot; analytics on that spot gives thousands of
  data points.
- You want to check whether something heard in interviews or seen in
  tests shows up in real use.

A/B tests:

- The team is choosing between two versions of a live page or flow, the
  versions differ in one thing, and the result can be judged on a measure
  the business already tracks (sign-ups, completed orders, people still
  using it after a month).
- The page gets enough traffic. A reliable answer often takes thousands
  of people.

## Don't use it when

- The question is why. Pair it with interviews or usability sessions.
- Nothing is live yet. There's no data.
- For an A/B test: the page gets little traffic; the versions differ in
  many things at once, so you couldn't tell which change mattered
  (testing several changes together needs even more traffic); or there's
  no idea from research about why B should do better.
- For analytics: there's no question yet. Without one, it's easy to spend
  days in interesting numbers that lead nowhere.

## Before you start

**Analytics**

- Write the question, and which numbers would answer it.
- Check that the step you care about is tracked. Some need setting up
  first.
- Read numbers as clues, in context. Long time on a page could mean
  interest or confusion; it isn't good or bad on its own.
- Remember who the logs can't see. A funnel starts counting when
  someone enters it. People who wanted to do the task and never found
  the way in aren't in the data, so an 80% completion rate inside the
  flow can hide a 40% success rate for everyone who tried. When the
  question includes "can people find it", pair analytics with a
  benchmark or a first-click test that starts from the top
  (`methods-benchmarking.md`,
  `methods-card-sorting-and-tree-testing.md`).
- If the team has a metrics framework (`methods-benchmarking.md`, "What
  to measure"), ask which goal and signal each number serves. A number
  with no goal behind it is a chart, not an answer.

**A/B tests**

- One hypothesis, based on research: "Showing the delivery date on the
  basket page will mean fewer people leave at shipping, because in
  sessions people left to look for it."
- One main measure, plus a few guardrail measures: things that mustn't
  get worse, such as returns or people coming back.
- Set how long it runs before it starts, from how often the thing happens
  now, the smallest change worth detecting, and how sure you need to be
  (usually 95%). Run at least one to two full weeks so weekday and weekend
  behavior are both in. Don't stop early because B looks ahead.
- With a new testing tool, run both groups on the same version first. If
  the tool shows a winner, the tool is wrong.

## Who does it

Usually a partner team (analytics, growth or engineering) owns the tools
and the data. Magpie drafts the question and the request (stage 4,
partner data) and helps read the results. It doesn't run the test.

## Analysis

- **Analytics:** each number with its time period, what it counts and
  what it doesn't track. Say what it suggests and what it can't tell you.
- **A/B tests:** the result on the main measure and the guardrails, and
  whether the difference passed the test set in advance. Then whether
  it's big enough to matter to the business, which is a separate
  question, answered against a bar agreed before the test. "No clear
  winner" is a result: keep the current version.
- **Report the difference in its own unit,** with the range it probably
  sits in: "2.1 percentage points more sign-ups (likely between 0.8 and
  3.4)", not a standardized effect size. Say what it means at volume:
  2.1 points on 50,000 visitors a month is about 1,050 sign-ups. Small
  differences add up when the thing happens often; a 17-second saving
  on a task done a hundred times a day is weeks a year.
- **The range and the p value usually agree.** When one says
  "different" and the other doesn't, both are sitting near the cutoff.
  Treat a result at 94% confidence like one at 95% unless the setting
  demands a guarantee; a rigid cutoff is for publication, not product
  decisions. For two conversion rates, the test is the N−1
  two-proportion test and the range is the adjusted-Wald interval
  around the difference (stage 7, "Numbers from small samples"). Read
  the low end of the range at volume too: a small lower limit can still
  be a lot of orders.

## Worked example

> **Decision.** Whether Harbor (team task board) shows the "invite your
> team" step during setup or after the first board is built. Growth
> decides in a month.
>
> **Analytics first.** Question: where in setup do new admins stop? The
> funnel showed 61% of admins who started setup invited someone within a
> week (data for September, 2,140 admins); it can't see admins who
> wanted to invite and never found the button. Interviews earlier found
> most admins build a board before inviting.
>
> **A/B test.** Hypothesis from research: moving the invite step to
> after the first board is built will raise invites within a week,
> because admins want something to show. Main measure: admins who
> invited within seven days. Guardrails: boards created in the first
> week; admins active at day 30. Run for two full weeks, size set from
> September's rate and a smallest change worth detecting of 4 points.
>
> **Result, as reported.** 66.2% against 61.1%: 5.1 points more, likely
> between 2.0 and 8.2; guardrails unchanged; at about 2,000 admins a
> month, about 100 more teams invited a month. The agreed bar (4 points)
> was met. Why it worked is from the interviews, not the test.

## Pitfalls

- Reading why from what. The numbers show people left; sessions show why.
- Stopping an A/B test the day it looks like a win.
- Judging on one measure and missing harm somewhere else.
- Calling a statistically significant difference an important one.
- Treating a test with no winner as a failure. Many tests end that way,
  which is why the hypothesis should come from research.

## Template

No template. Draft the request in the study record under partner data:
the question, the numbers, the time period and when they're needed.

## Basis

S75 (three uses of analytics: spotting issues, investigating them, and
checking findings from qualitative research; numbers as clues read in
context; a small test finds the spot and analytics sizes it; the risk of
data with no question). S74 (what an A/B test is; live product and
enough traffic, often thousands of users; one change at a time; a
hypothesis from research; main and guardrail measures; duration set in
advance, at least one to two weeks; an A/A test of a new tool; don't stop
early; statistically significant is not the same as important; many tests
find no winner; it shows
how behavior changes, not why; pair it with qualitative research). S11
(analytics, clickstream and A/B testing as measuring methods for a live
product). S13 (combine methods so one covers another's limits). S87
(analytics can't see users who never found the task's entry point; the
80% inside the flow against 40% of those who tried; pair with
benchmarking or a first-click test for navigation). S97 (goals, signals,
metrics). S84 and S85 (raw differences with intervals over standardized
effects; make them concrete at volume; small effects add up with
repeated exposure; set the action threshold before collecting data).
S100 (pp. 73–93: the N−1 two-proportion test for two groups of
different users, recommended when every expected cell count is above 1,
Fisher exact otherwise; the adjusted-Wald interval around the difference
between two proportions, adding one success and one failure to each
group; an A/B example at 90% confidence where even the low end of the
range meant a lot of revenue at volume; p values fluctuate by a few
points with the method chosen; a confidence interval and a p value usually point the
same way, and 94% against 95% confidence shouldn't change an applied
decision; a rigid 0.05 cutoff for publication). Who does the work:
practitioner judgment.

---

Part of Magpie version 2026-11-08, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: methods-benchmarking.md -->

# Method: benchmarking

Measure how well a product works with a few set numbers, then compare
them with something: an earlier version, a competitor, a published figure
or a goal the team set. Repeat it to see whether the experience is getting
better.

## Use it when

- A version of the product is finished or live, and the question is "is
  it better than before?", "did the redesign work?" or "how do we compare
  with X?".
- The team wants a few numbers to track from release to release, or to
  show what design work changed.
- A redesign is about to start. Measure now, so there is a starting point
  (a baseline) to compare against later.

## Don't use it when

- You need to know why something is hard. A benchmark says how much, not
  why. Pair it with moderated usability testing, before or after.
- The design is still changing every week. A benchmark is a snapshot of
  one version; measure a version that will hold still.
- You can only get five or six people. That's a usability test, not a
  benchmark; numbers from it carry too much error to compare.

## What to measure

- A few numbers tied to what the product is for. Common ones: task
  success rate, time on task, an ease rating after each task (the Single
  Ease Question), a questionnaire score after the session (the System
  Usability Scale), or something analytics records, such as how many
  people finish a form or come back after eight weeks. Support contacts
  about a task can count too.
- If the team has a metrics framework, pick from it. One common one
  names five kinds of measure: happiness (attitudes: satisfaction, ease),
  engagement (how often and how deeply people use it), adoption (new
  users in a period), retention (who's still there later) and task
  success (completion, time, errors). Not every project needs all five;
  a tool people must use at work may care about task success and
  happiness and not engagement. For each goal the team names, decide
  what people would do or say if it were met (the signal), then how to
  count it as a rate or a per-user figure, not a raw count that grows
  with the user base (the metric).
- Start tasks from the home screen, not inside the flow. Analytics only
  sees people who got into a flow; it can't count the ones who wanted to
  and never found the way in. A benchmark that starts each task from
  the top catches them, and failing to find the start is often the
  biggest problem.
- Choose what you'll compare against before you measure. A number on its
  own means nothing. In the first round there is no earlier version, so
  compare with a competitor, a published figure or a goal the team agrees
  on.

## How to collect

Quantitative usability testing (fixed tasks, many people, usually
unmoderated), analytics, or a survey. Analytics is quick to repeat;
testing rounds take longer and cost more.

## Sample

- Twenty or more people per user group for task numbers or questionnaire
  scores, and the same kind of people each round.
- Every score gets its range: a t-interval around the mean for SUS and
  SEQ, the geometric mean with its interval for task times below about
  25 people, the adjusted-Wald interval for completion rates (stage 7,
  "Numbers from small samples"). Halving a range takes four times the
  people, so plan the sample from the precision the decision needs.
- Comparing two rounds: the same people on both is a paired comparison;
  different people is a two-sample one. Say which.
- Recruit people who would really do these tasks.

## Keep it comparable

Use the same tasks, wording, order, success criteria, kind of participant
and way of collecting every round. Write them in the study record so the
next round can repeat them exactly. If one has to change, say so in the
report; the comparison is weaker for it.

## How often

The team decides. Testing rounds might run once a year or after a major
release; analytics can be checked after every change.

## Analysis

Each number with its sample size and margin of error, next to what it's
compared with. Test the difference before calling it a change (stage 7).
Say what else changed between rounds besides the design (a new kind of
customer, a price change, a season).

Report a change in its own unit ("12 points higher completion", "20
seconds faster"), with the range it probably sits in, and say what it
means at the product's volume ("about 400 more completed orders a
month"). Agree before the round what size of change would count as
worth acting on; deciding afterwards makes any result look like the
one the team wanted.

A SUS score is not a percentage. Across about 500 studies the average
is 68; above 68 is better than average, and a 74 is only a little
above it. Report it against that average, or as a percentile, so the
team doesn't read 68 as "a D". Two large published sets of SUS scores
had means near 70 and near 62 with a typical spread of about 22 points
either way, so single-study differences of a few points sit inside the
noise; give the interval. SUS also tracks the likelihood-to-recommend
question: a rough rule is recommend score ≈ SUS ÷ 10, and in one large
set people who would recommend averaged a SUS of about 81 against
about 52 for those who wouldn't, so a SUS above 80 is a fair "people
would recommend it" bar. If the team wants a letter, use the curved
grading scale built on those percentiles rather than a school scale:
68 is a C (about the 50th percentile), roughly 72.6 to 74 is a B−,
78.9 to 84 is an A, 84.1 and above is an A+, and below 51.7 is an F.
Averages also differ by kind of product: in the same data, enterprise
software averaged about 68, public consumer software about 74,
websites about 67 and phone-and-speech systems about 60, so compare
against the closest kind where one exists, and say which was used.

Net Promoter Score (NPS) is a single likelihood-to-recommend item on
0 to 10, promoters (9 or 10) minus detractors (0 to 6) as percentages.
Collapsing eleven points to three loses sensitivity, and there is no
agreed interval for it. If the team tracks it, keep the raw 0 to 10
answers, report their mean with a t-interval, and when a range on the
NPS itself is needed, recode each answer to −1, 0 or +1 and compute a
t-interval on that; the book calls this an untested but reasonable
approach. Ask why alongside it; the number alone says nothing about
what to change.

## Worked example

> **Decision.** Whether the BrightPay (payroll) pay-run redesign, live
> since March, is better than the old one, and whether to roll it out to
> the remaining accounts.
>
> **Measures, chosen before March.** Task success and time for "run this
> month's payroll for 12 employees with one new starter", from the home
> screen; an ease rating after the task; SUS after the session; from
> analytics, pay runs completed in one sitting. Comparison: the same
> study run on the old version in January.
>
> **Sample.** 42 payroll admins per round, unmoderated, same screener,
> same tasks and wording.
>
> **Result, as reported.** Success 31 of 42 (74%) against 22 of 40 (55%)
> in January: 19 points higher, likely between 1 and 36. Median time 11
> minutes against 16. SUS 71 against 62 (both reported against the
> 68 average, not as percentages). What else changed: a pricing change
> in February. The agreed bar was 10 points on success; met, with a wide
> range, so the readout says "better, by how much is uncertain".

## Pitfalls

- A number with nothing to compare it to.
- Changing the tasks or their wording between rounds.
- Calling a difference an improvement when it sits inside the margin of
  error.
- Measuring, then never finding out why the number moved.

## Template

Adapt `templates-usability-test-script.md`: fixed tasks with written
success criteria, the ease rating after each task, the questionnaire at
the end, and no probing during tasks.

## Basis

S73 (what benchmarking is; a summative snapshot of one version, run at
the end of a design cycle; example measures, including support data;
comparison with an earlier version, a competitor, an industry figure or a
stakeholder goal; analytics, surveys and quantitative usability testing
as the usual ways to collect; how often is the team's call). S11
(benchmarking as tightly scripted and summative, at the launch and assess
phase). S38 (the Single Ease Question, the System Usability Scale, twenty
or more people for questionnaire numbers). S12 (report the interval;
test before claiming a difference). S97 (the HEART
categories happiness, engagement, adoption, retention and task success;
goals, signals and metrics; not every category fits every project;
normalize counts into rates or per-user figures; define terms before
tracking). S87 (log data misses people who wanted to start a task and
never found it; a behavioral benchmark that starts from the home page
captures intent and shows navigation failures). S96 (the average SUS
score across about 500 studies is 68; a score isn't a percentage; report
it as a percentile against that average). S84 and S85 (report raw
differences in their own units with intervals; make them concrete at
the product's volume; set the "big enough" bar before the data arrives).
S100 (pp. 19–31: a confidence interval's width depends on confidence
level, variability and sample size, and halving the margin of error
takes about four times the sample; t-interval for rating-scale means;
geometric mean for task times below 25; adjusted-Wald for rates. p. 93:
two-sample t for different users, paired for the same users. pp.
200–201: the Bangor et al. set of 2,324 SUS questionnaires with a mean
of 70.14 and standard deviation 21.71, and the Lewis and Sauro set of 324
with a mean of 62.10 and standard deviation 22.24; p. 236: SUS against
likelihood to recommend across 2,201 users, correlation 0.623, LTR ≈
SUS/10, promoters averaging 81 and detractors 52.5; pp. 203–205: raw SUS
scores converted to percentile ranks, the curved grading scale (C at
68, A from 78.9, A+ from 84.1, F below 51.7), and Table 8.6 means by
interface type (global 68.0, business-to-business 67.6,
business-to-consumer 74.0, web 67.0, cell phone 64.7, internal software
76.7, voice response 79.9, web plus voice 59.2); p. 235: NPS defined
as promoters minus detractors, loss of sensitivity from collapsing the
scale, no well-defined interval, the −1/0/+1 recoding as an untested
way to get one).
Keeping every round the same and naming what else changed: practitioner
judgment.

---

Part of Magpie version 2026-11-08, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: methods-card-sorting-and-tree-testing.md -->

# Method: card sorting, tree testing and first-click testing

Three methods for information architecture. Card sorting shows how people
group and name things. Tree testing shows whether people can find things in
a proposed structure. First-click testing shows where people go first on
a real page or design, and whether that first move is the right one.

## Use them when

- The question is about structure: navigation, categories, menu labels, how
  a settings area or a help center should be organized.
- Card sorting: you're designing or rethinking a structure.
- Tree testing: you have a structure (or two) and want to know if it
  works, before building any screens.
- First-click testing: there's a page or a design (a wireframe, a mockup,
  a live site) and the question is whether people start in the right
  place for a task.

## Don't use them when

- The structure isn't the problem. If people can find things but the thing
  they find doesn't work, test usability instead.
- There are fewer than about fifteen items to organize. Just ask.

## Sample

- Card sorting: at least fifteen participants. Thirty adds a little
  stability for twice the cost; it's worth it on large projects.
- Tree testing: thirty to fifty per structure for findability rates you can
  compare.
- Recruit people who'd actually use the structure.

## Card sorting shape

- **Open sort:** participants group cards and name the groups. Use it to
  discover the mental model.
- **Closed sort:** you give the group names; participants place cards. A
  tree test usually checks a proposed structure better.
- Avoid hybrid sorts (some groups given, some made); the given groups steer
  people.
- Thirty to fifty cards, written in the users' words, not internal names.
  More than fifty and people tire, and the "miscellaneous" pile grows.
  Don't repeat the same word across cards; people group on the word.
- Usually remote and unmoderated with a sorting tool; a few moderated
  sessions add the "why".

## Tree testing shape

- The structure as a plain text tree, no visual design.
- Eight to twelve tasks: "Where would you go to change your password?"
- Record success, directness (did they go straight there), time, and
  where they went first.
- Test two structures with different people to compare (each person sees
  only one).
- Run it before any layouts or content exist.

## First-click testing shape

- Show a page (a screenshot, a wireframe or the live site) and give one
  task at a time: "Where would you click to find out how much a
  subscription costs?" Start every task from the same home or base
  screen.
- Write the correct first click (or clicks) for each task before the
  test, so observers compare against it.
- Record where each person clicked first and how long they took to click.
  A long pause before the first click is a finding too.
- After each task, ask how confident they are that they went the right
  way, and how easy it was (`methods-usability-testing.md`, "Follow-up
  questions").
- Usually unmoderated, in a tool that collects clicks and draws a heat
  map; a few moderated sessions add the why. Don't tell people it's a
  first-click test.
- Thirty or more per design for rates you can compare, as for tree
  testing. Pilot it first.

The first click predicts the rest: people whose first click was right
finished the task far more often (about 87% against 46% in the figures
the source cites). Analyze it as success per task, plus where the wrong
clicks went; a cluster of wrong first clicks on one element names the
label or layout to fix.

## What makes it good

- Cards and tasks in participants' language.
- Tasks that don't contain the label you're testing.
- Comparing structures with the same tasks.

## Analysis

Card sorting: a similarity matrix (which cards are grouped together how
often), the group names people chose, and the cards that went everywhere
(the ambiguous ones). Tree testing: success and directness per task, the
first-click paths, and the tasks that failed. First-click testing: right
first click per task, time to first click, where the wrong clicks went,
and the confidence ratings next to the result (confident and wrong is the
worst case). Stage 7 covers this.

## Worked example

> **Decision.** How BrightPay (payroll) organizes a settings area that
> has grown to 42 pages. Design decides the structure in a month.
>
> **Research questions.** How do payroll admins group these settings?
> Can they find the eight most-visited ones in the proposed structure?
>
> **Card sort.** 38 cards in admins' words ("who gets paid on which
> day", not "pay schedule config"), open sort, unmoderated, 22
> participants, plus three moderated sessions for the why.
>
> **Result.** Three stable groups (people, money, the company) in 18 of
> 22 sorts; "approvals" went everywhere (placed in five different
> groups). The moderated sessions said why: approvals are about people
> *and* money.
>
> **Tree test.** Two trees (approvals under People; approvals as its own
> top-level item), 40 participants each, ten tasks. "Where would you go
> to let a manager sign off overtime?" Tree B: 34 of 40 succeeded, 29
> directly. Tree A: 21 of 40. Reported as counts with the difference and
> its range; Tree B recommended, with approvals' own section.

## Pitfalls

- Cards that are internal feature names.
- Reading one open sort as "the" structure; it's a map of mental models,
  often several.
- Tree tasks that give away the answer.
- Building screens before tree-testing the structure.
- A first-click task that starts mid-flow, so the navigation never gets
  tested.

## Template

`templates-card-sort-and-tree-test.md`: the card list, the structure and
task list for a tree test, the task list and correct clicks for a
first-click test, and the analysis sheets.

## Basis

Card sorting: S49 (at least fifteen participants, from correlations of
0.75 at five, 0.90 at fifteen and 0.95 at thirty); S50 (open, closed and
hybrid sorts and when to use each; thirty to fifty cards; repeated words;
moderated for the why, unmoderated for numbers; similarity matrix; limits
of the method). Tree testing: S51 (a text-only tree before layouts or
content; tasks that don't give away the answer; success, directness and
first click; one tree per participant when comparing). Definitions: S52.
First-click testing: S91 (what it is; works on a live site, prototype or
wireframe; tasks written as problems; document the correct path; record
the click and the time to it; don't tell people it's a first-click test;
pilot; start each task from the base screen; confidence and ease ratings
after each task; the 87% against 46% figures, credited there to Jeff
Sauro). The tree-testing sample (thirty to fifty) follows S46's
thirty-plus for rates, applied to first-click tests too; the
eight-to-twelve task range and the moderated-for-why line are
practitioner judgment.

---

Part of Magpie version 2026-11-08, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: methods-competitive-analysis.md -->

# Method: competitive analysis

Look at how other tools solve the same problem your users have, and work
out what would fit your users and what wouldn't. The unit of comparison is
the user's job, not the feature list.

## Use it when

- The team is deciding whether or how to build something others already
  offer.
- You want to know what users will expect because they've seen it
  elsewhere.
- You need a quick, cheap source of design options before a concept test.
- Sales or marketing keep citing a competitor and nobody has looked
  properly.

## Don't use it when

- You want to know what *your* users do or need. Competitors can show you
  options; only your users can tell you what fits.
- The decision is "copy them or not". That's not a research question.
- Nobody can name the user problem the comparison is about.

## Sample

- Two to four products that your users could plausibly use instead,
  including at least one that isn't a direct competitor but solves the
  same job another way (a spreadsheet, a manual process, an adjacent
  tool).
- Three to five user jobs or journey steps to compare across them, taken
  from the study record, not from a feature list.

## Access: hands-on or public sources only

Find out early which of two routes this is. Ask once if it isn't clear.

- **Hands-on.** Someone can use each tool: an account, a free tier, a
  trial the team has set up. The researcher walks the job, or Magpie does
  where the setup lets it open the tool.
- **Public sources only.** Nobody on the team can get into the tools.
  This is common and still worth doing. Build the comparison from what's
  public, best first:
  1. Help docs, tutorials and onboarding guides. They often show the real
     screens step by step.
  2. The product's own demo videos, webinars and walkthroughs.
  3. Public pages of the product itself (a sign-up flow, a public
     template gallery, a pricing and plans page).
  4. Release notes and changelogs, for what changed and when.
  5. Public reviews, community forums and app store listings, for what
     users say goes wrong. These are other people's users, not yours.
  6. Marketing pages and analyst summaries, for positioning and claims.

  Help docs and demos show how a task is meant to go, not how it goes for
  a user. Errors, dead ends and slow steps rarely show up in them, so the
  fit assessment leans harder on "check with our users", and "What this
  can't tell us" says so.

Either way, mark each tool and each cell with how it was seen:

- **walked:** someone did the task in the tool.
- **shown:** material that shows the real screens: screenshots, a screen
  recording, help docs with screen images, a demo video.
- **described:** someone's words about the tool: marketing copy, a review,
  an analyst note, a sales deck.

A cell that is only **described** is a claim, not an observation. Never
call a marketing page an observation.

## What Magpie can take in

What Magpie can read depends on the tool it's running in. It says which
of these it can use in this setup, in one line, and never pretends to
have read something it couldn't.

- **Screenshots and photos.** Magpie reads what's on screen: the step, the
  words the tool uses, the choices offered. It asks which step each image
  shows if that isn't clear, and doesn't guess what happens off screen.
- **Screen recordings and demo videos.** Where Magpie can take video, it
  works through it and cites the moment (timestamp) for each step. Where
  it can't, it says so and asks for a still of each step, a transcript,
  or a short written walk-through. It never describes a video it hasn't
  seen.
- **Web pages and links.** Where Magpie has web access, it reads public
  pages and logs each one with its URL and the date read. Where it
  doesn't, it says so and asks for the page text or a screenshot. It
  doesn't sign up for accounts or trials, enter anyone's details, or get
  around a login or paywall; that's the researcher's call and the
  researcher's account.
- **Notes.** A researcher's written walk-through of a tool counts as
  **walked** for the steps they did.

## Shape

1. **Start from the job.** Name the user, the job and the journey step
   from the study record. Write the question: "How do people get [job]
   done in [tool], and what would fit our [persona]?"
2. **Pick the set.** Two to four tools, with one that solves the job
   differently. Say why each is in.
3. **Walk the job in each tool, or trace it from public sources.** Do the
   task as the user would. Record what happens at each step: screenshots,
   the words the tool uses, where it asks for effort, where it decides for
   the user. Note what it assumes about the user. With public sources
   only, trace each step through help docs and demos, and leave a step
   blank, marked "not shown publicly", rather than guess.
4. **Compare on fit, not on count.** For each job step and each tool: how
   the tool handles it, what it assumes about the user, and whether that
   assumption holds for your persona. "Has feature X" is not a row.
5. **Separate what you saw from what you infer.** What the tool does is
   [their data] about the tool when it was walked or shown, with the
   source. Why it does it, and
   whether their users like it, is [assumption] unless you have evidence
   (public reviews, support forums, a user who's used both).
6. **Draft the fit assessment.** For each pattern worth considering: what
   it would solve for your users, what it would cost them, which persona it
   suits, and what you'd need to check with real users before adopting it.

## What makes it good

- Doing the task in each tool where you can. Where you can't, using
  material that shows the real screens over marketing claims, and saying
  which cells rest on which.
- A tool from outside the category in the set.
- Every "they do X" paired with "and that fits or doesn't fit our users
  because".
- Honest about what you can't see: their data, their users' satisfaction,
  why they made a choice.
- Dated. Competitors change; the analysis has a shelf life. Say when it
  was done.

## Analysis

A fit matrix: job steps down the side, tools across, each cell saying how
the tool handles it and what it assumes. Then the patterns: what everyone
does (users will expect it), what nobody does (a gap or a dead end), what
one tool does well that would suit your persona. Then the fit assessment
per pattern. Stage 7 covers the write-up; `templates-competitive-analysis.md`
has the shape.

## What it feeds

- **Stage 3:** a sharper sense of what users may already expect.
- **Stage 4:** design options for a concept test.
- **Stage 8:** "here's how others handle it and why it would or wouldn't
  fit us", as context for a recommendation, never as the recommendation's
  evidence on its own.

## Worked example

> **Decision.** Whether Tally (expense tracking) builds mileage claims,
> which two competitors offer. Product decides next quarter.
>
> **Set.** Two direct competitors, plus the spreadsheet template the
> finance team already emails people. Public sources only: nobody on
> the team can get into the competitors' tools.
>
> **Job.** "Claim the miles from a client visit." Five steps, from the
> study record.
>
> **Matrix, as recorded.** Competitor A: steps 1 to 4 **shown** (help
> docs with screenshots, dated 2026-09), step 5 (approval) "not shown
> publicly". Competitor B: steps 1 to 3 **described** (marketing page),
> rest blank. The spreadsheet: all five **walked** by the researcher.
>
> **Fit assessment.** A's "start and end postcode" pattern would suit
> Tally's field-sales persona (it removes typing); what it assumes (a
> UK address format) doesn't hold for the US half of users. Labeled
> [assumption] until checked in sessions. "Both competitors do it" is
> recorded as a reason to test, not to build.

## Pitfalls

- A feature checklist with checkmarks. It tells you what exists, not what fits.
- Calling a marketing page or a demo video an observation of how the tool
  works for users. A demo shows the happy path.
- Filling a cell from memory of how a tool used to work.
- Assuming a competitor's choice is good because they're big.
- Treating public reviews as your users' views.
- Only looking at direct competitors, and missing the spreadsheet everyone
  actually uses.
- Letting the analysis become the recommendation. "Competitor X does it"
  is a reason to test, not a reason to build.

## Template

`templates-competitive-analysis.md`

## Basis

S24 (compare on the key tasks users need to complete; look at tangentially
related businesses for perspective; the aim is to beat the competition,
not copy it; observe what users actually do). Separating what was observed
from what is inferred, the fit matrix and the shelf-life note: practitioner
judgment.

---

Part of Magpie version 2026-11-08, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: methods-concept-testing.md -->

# Method: concept and value testing

Show people an idea before it's built and learn whether it solves a problem
they have, how they'd fit it into their work, and what would stop them.

## Use it when

- The decision is whether to build something, or which of several
  directions to take.
- You have a concept to show: a sketch, a storyboard, a one-page
  description, a clickable mock.
- You want direction, not usability.

## Don't use it when

- You want to know whether people can use it. That's a usability test.
- You want to know how many would buy or adopt. Reactions in a session
  don't predict that; combine with behavioral data or a pricing method,
  or run a fake-door test (below).
- The concept is so vague participants would be reacting to the drawing,
  not the idea.

## What to show

Pick the lightest form that carries the idea, and show every concept at
the same level of polish so polish isn't the variable.

| Form | Shows | Good for |
| --- | --- | --- |
| One-paragraph description | The promise in words | Early, many ideas, cheap to change |
| Storyboard (four to six frames) | A person, a situation, the idea in use, the outcome | Ideas that only make sense in a situation |
| Sketch or wireframe | What it might look like | Ideas where the shape matters |
| Clickable mock | A few screens that respond | Ideas people need to try to understand |
| Fake landing page | The promise as the market would meet it | Measuring interest at scale (see fake-door tests) |

Words first where you can. A polished screen makes people react to the
screen. Leave out the brand, prices and a name unless they're part of
what's being tested.

## Sample

- Six to ten per target group. If comparing concepts, show each person all
  of them, in rotated order.

## Session shape (30 to 45 minutes)

1. Context first: how they handle the problem today, before they see
   anything. Ask for the last time, not the usual: "Tell me about the last
   time you [did the thing]. What did you do? What did it cost you?" This
   is the baseline.
2. Show the concept. Let them read or explore it. Ask what they think it
   is and who it's for, before you explain.
3. Value: "Where in your week would this fit?", "What would you stop doing?",
   "What would make you not bother?"
4. If several concepts: the same questions for each, then "If you could
   only have one…" and why.
5. Close: what's missing, what they'd want to know before using it.

## Ask about the past, not the future

"Would you use this?" gets a kind yes from almost everyone. Replace it
with questions that have a true answer:

- **Have they tried to solve it?** "What have you tried?" "What do you do
  now instead?" Someone who has never tried to solve the problem doesn't
  have it badly enough to change.
- **What has it cost them?** Time, money, workarounds, a tool they bought
  and dropped. Past spend is a better signal than stated interest.
- **What would they give up?** "What would this replace?" A concept that
  replaces nothing fits nowhere.
- **A small commitment.** "Can I show you the next version?" "Would you
  join a pilot?" "Who else here should see this?" A yes that costs
  something means more than a compliment.

Write down the compliments and set them aside. A session full of "that's
great" and no stories is a polite no.

## Fake-door and smoke tests

The behavioral check. Put the promise of the feature in front of real
users before it exists (a button, a menu entry, a landing page with a
sign-up) and count who acts on it. Those who click see a short, honest
message: it isn't ready, thanks for telling us you're interested, and an
optional "tell us why". Pair it with a few interviews of the people who
clicked.

- Use it when sessions show interest and the team needs to know how wide
  the interest is before building.
- Write the question and the bar first: how many clicks, out of how many
  who saw it, would make the feature worth building? Agree the bar before
  the number arrives.
- Keep it short and small. A dead-end button costs trust, and people who
  meet unavailable features more than once, such as beta testers, get
  frustrated; run it for a short, fixed time, to a slice of users, never
  twice on the same people, and never for something they urgently need.
- Count clicks on the call to action out of everyone who saw it, and
  time on the page. In a remote test, a short survey after the message
  adds the why; in a moderated session, agree beforehand how the
  moderator handles the moment the door turns out to be fake.
- Say what the number can't tell you. A click is curiosity; it isn't use.
  People who clicked once may not have the problem the way the team
  thinks. It isn't a method on its own; it sits next to the sessions.
- The analytics or growth team usually runs it. Magpie drafts the question,
  the bar and the message (`methods-analytics-and-ab-tests.md`, "Who does
  it") and logs the result as [their data].

## What makes it good

- Baseline before exposure.
- Asking what they'd give up for it, not whether they like it.
- Concepts shown at the same level of polish, so polish isn't the
  variable.
- Noting the questions participants ask; they reveal the gaps.

## Analysis

For each concept: how participants understood it, where they saw value and
for what, what would block adoption, and how it compares to how they cope
today. Reaction patterns, not votes. Stage 7 covers this. Keep the
baseline stories next to the reactions: someone who described a painful
workaround and then shrugged at the concept is a finding.

## Worked example

> **Decision.** Which of two directions Sparrow (team messaging) takes
> for "catch up after time away": a digest, or a per-channel summary.
>
> **Research question.** When people come back after a day or more away,
> what do they do now, and which direction fits that?
>
> **Sample.** Eight people who were away from work for two or more days
> in the last month, 40 minutes each, both concepts as four-frame
> storyboards at the same polish, order rotated.
>
> **Baseline.** "Tell me about the last time you came back after a few
> days." 6 of 8 described scrolling each channel from the top (P1, P2,
> P4, P5, P7, P8); two asked a colleague what they'd missed.
>
> **Reactions, as reported.** All eight said both ideas were "great".
> Asked what each would replace: 5 of 8 said the digest would replace
> the scroll (P1, P2, P4, P5, P8); 2 of 8 said the per-channel summary
> would replace anything. 3 of 8 asked to see the next version of the
> digest unprompted. Reported as patterns in reasons, not a vote;
> recommendation: a fake-door digest entry for two weeks to size
> interest before building.

## Pitfalls

- "Would you use this?" Everyone says yes to be kind.
- Selling the concept instead of testing it.
- Reading politeness as enthusiasm.
- Treating a preference between two mock-ups as a market signal.
- A fake door left up for weeks, or on something people need now.

## Template

`templates-concept-test.md`

## Basis

Definition: S52 (an attitudinal method that collects people's thoughts
and attitudes about a product idea). Why "would you use it?" misleads and
reactions don't predict adoption: S8 (self-reported future intentions are
unreliable; observe behavior where you can); S27 (research should not stop
at a yes or no); S5 (past experience over hypotheticals). Pairing reactions
with behavioral data: S13. The forms to show, the past-not-future
questions, the small-commitment test, sample sizes, the session shape and the
baseline-first rule: practitioner judgment. Fake-door tests: S99 (a
landing page or mockup with a call to action for a feature that doesn't
exist; judge interest by what people do; clicks and time on page; a
survey after the message in remote tests, agreed moderator guidance in
person; repeated exposure frustrates people; not a standalone method).
The honest message after the click, the fixed short run and the agreed
bar: practitioner judgment; S99 does not cover them.

---

Part of Magpie version 2026-11-08, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: methods-contextual-inquiry.md -->

# Method: contextual inquiry

Watch people do their real work in their real setting, and ask about it as
it happens.

This is one kind of field study. `methods-field-studies.md` covers the
others (direct observation, site visits, ethnography, remote sessions) and
how to choose between them.

## Use it when

- The question is about how work actually gets done, including the
  workarounds nobody mentions in an interview.
- The work is complex, physical, or spread across tools and people.
- Users can't easily describe what they do because it's habit.

## Don't use it when

- Access to the setting is impossible or intrusive (hospitals, secure
  sites) and a remote screen-share won't do.
- The question is about attitudes or future needs rather than current
  practice.
- The decision is due in days. This takes time to arrange and to digest.

## Sample

- Four to eight sessions for one role. Each session is rich; fewer is often
  enough.
- Pick people across the variation that matters: experience, site, team
  size.

## Session shape (60 to 120 minutes)

1. **Primer.** Arrive, build rapport, explain the goal, and confirm
   consent, including for photos or screen recordings and for anyone else
   who may appear.
2. **Transition.** Say out loud that you're switching from talking to
   watching: "From now on, please work as you normally would. I'll stop
   you now and then to ask about something." Don't skip this; without it,
   people keep explaining instead of working.
3. **Watch and ask.** Let them work. Take notes on what they do, what they
   touch, who they talk to, what they wait for. Stop to ask when something
   is unclear: "What just happened?", "Why that way?" Keep your
   interpretations mostly for the end, since checking them mid-task can
   change what they do next.
4. **Wrap-up.** Walk back through what you saw, say your reading of it, and
   let them correct you. Their corrections are often the best data of the
   session.

## Remote contextual inquiry

When you can't be there, the participant shares their screen and, where
the work leaves the screen, points a phone camera at it. The session shape
holds. Ask for what the camera misses: "What's on the desk?", "Who else is
in the room?", "What did you just look at?" Expect to see the happy path
more than you would on site, because the participant chooses what to
show; say so in the findings. `methods-field-studies.md` covers remote
sessions and their limits.

## After each session: the team interpretation

Within a day, the people who were in the session (and one or two who
weren't) go through the notes together, in order, and build three
things:

- **The sequence.** The steps as they actually ran, with the triggers,
  the waits and the handoffs between people and tools.
- **The artifacts.** Everything the person used or made: the sticky
  note, the spreadsheet on the side, the printed list. What each one is
  for, and what in the product it stands in for.
- **The breakdowns.** Each moment where the work stalled or the person
  improvised, with what caused it as far as you saw.

Keep what you saw apart from what you think it means. Questions that
come up go on a list for the next session. After the last session, lay
the sequences side by side and look for the steps everyone has, the
steps only some have, and the breakdowns that repeat (stage 7).

## What makes it good

- You're an apprentice, not an interviewer. They're the expert, and either
  of you can steer the session.
- You know what you're there to learn, so you know what to watch.
- Note what's in the environment: sticky notes, spreadsheets on the side,
  printed cheat sheets. Those are findings.
- Capture breakdowns: the moments where the work stalled or the person
  improvised.

## Analysis

Map the workflow as it actually runs, with the tools and people involved
and the breakdowns marked. Then themes across sessions. Stage 7 covers this.

## Worked example

> **Decision.** Whether Dockside (warehouse returns) replaces the paper
> returns log with in-app steps. Operations decides this quarter.
>
> **Research question.** How do returns clerks process a return today,
> and where does the work leave the system?
>
> **Sample.** Five clerks at five sites, 90 minutes each, on a normal
> shift.
>
> **Session.** Primer and consent for screen photos; the transition said
> aloud; watched ten returns; asked "what's the notepad for?" when it
> appeared; wrap-up where the researcher's reading ("you don't trust the
> screen") was corrected by the participant ("only the refund bit, it
> resets").
>
> **Interpretation, same day.** Sequence: scan, search, refund, confirm.
> Artifacts: a sticky-note SKU list on the drawer (3 of 5 sites), a
> notepad for refund amounts (P3). Breakdowns: search times out on
> unlabelled items (P1, P3, P5); refund screen resets (P3, P5). Finding,
> as reported: the paper exists because of two system failures, not a
> preference for paper; removing it without fixing them removes the
> workaround.

## Pitfalls

- Turning it into an interview at a desk, or letting the participant
  summarize their work instead of doing it.
- A session that becomes a list of complaints about the current system.
  Bring it back to the work.
- Reacting to what they do, so they start doing what you seem to want.
- Observing only the "happy path" because the participant tidied up for
  you.
- Recording people who didn't consent (colleagues in the background).

## Template

Use `templates-interview-guide.md` for the question prompts and a blank
observation sheet with columns for time, what happened, tools, people,
breakdown.

## Basis

S43 (the apprentice model; context, partnership, interpretation and focus;
the primer, transition, contextual interview and wrap-up; holding most
interpretations for the end and letting the participant correct them;
pitfalls of interview mode, complaint sessions and researcher reactions;
a small sample of people qualified in the work); S52 (definition); S33
(contextual inquiry as one kind of field study). The sample range, the
session length, the remote section, the team interpretation and the
observation-sheet columns: practitioner judgment.

---

Part of Magpie version 2026-11-08, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: methods-customer-feedback-coding.md -->

# Method: coding customer feedback

Turn the feedback the organization already collects (support tickets,
app store reviews, survey open-ends, chat logs, sales and success notes,
community posts) into counted themes the team can act on. It's evidence
review's biggest raw source, and the same coding rules as stage 7, applied
at volume.

## Use it when

- The question is what people complain about, ask for, or praise, and
  how that is changing.
- A score has moved (satisfaction, NPS, ratings) and the team wants to
  know why. The score is the smoke alarm; the comments behind it are the
  diagnosis.
- Something seen in a few sessions needs sizing, and the feedback archive
  is large enough to size it.
- The team wants to check whether a finding from interviews or tests
  shows up in what customers write unprompted.

## Don't use it when

- The question is about people who don't write in. Feedback comes from
  the people who chose to send it: the angriest, the most engaged, the
  ones with time. It describes them, not the user base.
- The question is why something happens at the level of a single
  workflow. A ticket says "export failed"; it rarely says what the person
  was trying to do. Interview or watch.
- There's no question. A pile of feedback with no question produces
  interesting charts and no decision.

## Where it comes from

Gather it into one place with its context: the date, the channel, the
product area, the customer's plan or segment where you can, and the
whole comment. "Pricing" on its own can be praise or a complaint; the
sentence around it says which. Keep the link back to the original so a
quote can be checked.

Channels differ in who writes and why. Support tickets are problems;
reviews are extremes; survey open-ends follow a question that shaped
them; sales notes are secondhand. Say in the readout which channels were
used and what each leaves out.

## How to code it

1. **Write the question first.** "What stops people finishing setup?"
   gets a different code frame from "What do people praise?"
2. **Read a sample before coding anything.** A hundred comments, or
   enough to see the shape. Build the code frame from what's there
   (inductive), not from the team's list of features. Add codes as they
   appear; merge them as the frame settles.
3. **Keep the frame small at the top and specific underneath.** Fewer
   than about twenty top-level themes ("getting data in", "billing"), each
   with specific, actionable codes under it ("import fails on files over
   10 MB"). The specific codes are what the team can fix.
4. **A comment can carry several codes.** Don't force each comment into
   one bucket; most say more than one thing, and the second thing is
   often the useful one.
5. **Note the feeling as well as the theme.** The same theme can be
   praise or a complaint. Record which, per code, not per comment.
6. **Two spreadsheets or one tool.** By hand: one sheet for the code
   frame (code, definition, an example comment), one for the comments
   with a column per code. Tools that suggest themes do the first pass
   faster; the frame still needs a person to merge and name it.
7. **Check it.** Have a colleague code a sample blind and compare. Where
   you disagree, tighten the definition. For an automated pass, compare
   its top themes with a hand-coded sample before trusting it.

## Counting and reading

- Report each theme as a count out of the base ("412 of 3,100 tickets in
  Q3 mention import"), with the period and the channels. Per comment,
  not per customer, unless you can de-duplicate; one customer can write
  ten tickets.
- Trend over time, per theme, is often the finding: a theme that doubled
  since a release matters more than the biggest theme.
- Cross by segment where the data allows (plan, platform, tenure). A
  theme that is small overall and large in one segment is a finding.
- Where a score exists (satisfaction, NPS), look at which themes the low
  scorers mention most. That's "why the score moved", as far as feedback
  can say it.
- A theme's size says how often people wrote about it, not how often it
  happens or how much it matters. Weight it with what else is known
  (analytics, sessions) before it becomes a priority.

## At scale

Pick the way that fits the volume and the stakes.

| Volume | Way | Watch for |
| --- | --- | --- |
| Hundreds | Code by hand, as above | Drift: coders apply the frame differently over time; recheck a sample monthly |
| Thousands, a few channels | A tool for the first pass (keyword or topic extraction), a person to merge and name the themes | The tool finds what it was set to look for; new themes arrive late |
| Tens of thousands, many channels | A tool that builds and updates the frame from the feedback itself | Themes nobody can define; check a sample against the raw comments each round |

Whatever the volume, the readout quotes real comments, with the channel
and date, and `checks-claim-strength.md` applies: a count of mentions is
a count of mentions.

## Worked example

> **Decision.** Why Sparrow's (team messaging) app store rating fell
> from 4.4 to 3.9 over the summer, and what to fix first.
>
> **Question and frame.** "What do people complain about since June, and
> what's new?" Read 150 reviews first; built a frame of 14 top-level
> themes with specific codes under them; coded 1,210 reviews from June
> to September by hand with a tool's suggestions for the first pass; a
> colleague coded 60 blind, agreement checked, two definitions
> tightened.
>
> **Result, as reported.** "Notifications arrive late" rose from 4% of
> reviews in June (9 of 220) to 31% in September (104 of 335), nearly
> all on Android (97 of 104), and 1-star reviews mention it most (71 of
> 118). Per review, not per customer. Reported with what it can't say:
> how many users are affected (reviews come from people who chose to
> write), and why it happens (engineering's logs and three sessions
> with affected users were the next step).

## Pitfalls

- Treating the writers as the users. Say who writes in and who doesn't.
- A code frame made from the feature list, so the data can only confirm
  the team's map of the product.
- One code per comment.
- A percentage of comments reported as a percentage of customers.
- A theme that is really the channel: "can't reach support" from support
  tickets.
- Quoting a comment without the original to check it against.
- Letting a tool's themes stand without reading a sample of what's inside
  each.

## Template

The code frame and the comment sheet above, kept with the study record.
Report counts with `templates-analysis-sheet.md`.

## Basis

S89 (gather feedback in one place with its context; a single word's
meaning depends on the comment around it; inductive coding; several
themes per comment, each with its own sentiment; a hierarchy from broad
themes to specific, actionable ones, under about twenty at the top; the
two-spreadsheet method; keyword extraction produces phrases that still
need merging; have a colleague check a coded sample and compare
automated themes with a hand-coded sample; quantify and visualize by
theme; explain the approach so stakeholders trust it). S90 (methods
ranked by volume: manual coding is flexible but drifts; scores show the
trend but not the cause, "a smoke alarm, not a diagnosis"; sentiment and
topic tools find what they were set to look for; adaptive tools for the
largest volumes. The source is a vendor's guide; its claims about its own
kind of tool were not checked). S1b (coding and themes as in stage 7).
Who writes in and who doesn't, per-customer de-duplication, trend and
segment reading, and the pitfalls: practitioner judgment.

---

Part of Magpie version 2026-11-08, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.
