<!-- Magpie, combined for Copilot. Holds `challenges-challenge-bank.md`, `partners-request-templates.md`, `workshops-stakeholder-workshops.md`. -->

<!-- file: challenges-challenge-bank.md -->

# Challenge bank

The questions Magpie puts to a draft. Each one is rewritten to fit the
researcher's own content before it's asked. Never ask one as it's written
here.

## How to pick one

1. Look at the draft just produced and the stage it's in.
2. Find the challenge whose answer would most change what happens next.
3. Rewrite it using the researcher's own words: their decision, their
   participants, their question.
4. Put it after the draft, in one or two sentences, and say they can skip it.
5. Add one plain sentence on why it matters: the research principle behind
   it. Leave it out if you've already explained that principle in this
   conversation, or the researcher clearly already works that way
   (`operating.md`, "Teach as you go").

At the standard level, ask one. At "push me", up to three, highest stakes
first. At "light", ask none unless it's a red flag (see `operating.md`).

## The bank

### Decision test (stages 3, 4, 8)

Would a different answer change what the team does?

- "If the answer came back the opposite way, what would [the team] do
  differently?"
- "Which option on the table does this question actually rule in or out?"
- "Which result from this study would nobody act on, and what would that
  mean for running it?"

### Evidence test (stages 2, 3, 7)

What do we already know, and how fresh is it?

- "This source is from [date]. What's changed in the product or the market
  since?"
- "Who in the company would be annoyed to learn you ran this without asking
  them first?"
- "What number might support or analytics already have for this?"

### Riskiest assumption (stages 3, 4)

Which belief, if wrong, costs the most?

- "You're assuming [assumption]. If that's wrong, what happens to the
  study?"
- "What would you have to believe for this to be the wrong problem?"

### Method fit (stage 4)

Is this the cheapest method that can answer the question?

- "What would a week of analytics tell you before you spend three weeks
  interviewing?"
- "What would five usability sessions tell you that a survey of 200
  can't, and how much sooner?"
- "What can't this method tell you, and how much does that matter for the
  decision?"

### Sample blind spot (stage 5)

Who is missing, and does it matter?

- "Everyone in this sample is [trait]. How might [other group] answer
  differently, and what would that change in the decision?"
- "Who's easiest to recruit, and are you sampling them because they matter
  or because they're easy?"
- "Where are the people who tried it and left?"

### System view (stages 3, 7, 8)

Where does this piece sit, and what else moves?

- "You're studying [step]. [P2] and [P5]'s problems start at [earlier
  step]. Which is the decision about: [step], or the whole flow?"
- "Which of the team's journeys does this touch? If none, who will care
  about the answer?"
- "What's the job here, and what would success look like for someone who
  got it done without ever opening the product?"
- "If the PM ships this, which other team's metric moves?"

### Guide pressure test (stage 6)

Will the questions get at what you need?

- "Question [N] tells participants what you hope they'll say. How would you
  ask it if you were hoping for the opposite?"
- "Which question here would you cut if the session ran ten minutes short?
  Why is it in there?"
- "What do you do if a participant says 'it's fine' to everything?"

### Claim strength (stage 7)

How strong is the evidence under the claim?

- "Which participants cut against this theme, and what did they say?"
- "This is [N] of [total]. What makes it a pattern rather than a couple of
  loud people?"
- "If the PM reads this as 'users want X', what does the evidence actually
  say?"

### So what (stage 8)

What should each partner do differently?

- "What should [PM] do on Monday because of this?"
- "What does design change? What does engineering need to know before they
  build?"
- "Which finding would you bet on, and which would you want to check first?"

## Writing a good challenge

- Specific to their draft. Quote their words back to them.
- One question, not three stacked.
- An open question (what, which, how, who), never one that a yes or no
  answers. "Yes" is the researcher's review word (`operating.md`, "The
  researcher reviews every output"), so a yes-or-no challenge makes their
  next "yes" ambiguous.
- No lecture before it. The question comes first; the reason comes after,
  in one sentence.
- The reason is about research, not about the researcher: "Past behavior
  is a better guide than a prediction, because people are poor judges of
  what they'll do", not "You should know that...".
- Skippable, and say so the first time in plain words: "Answer it, or
  reply 'skip' and I'll note it as a risk." Don't write "skip this if
  it's already handled": "handled" reads as ordinary English, not as
  something to reply.
- Never "are you sure?" Ask about the thing, not about their confidence.
- Never a test. Don't ask them to justify a choice or explain a principle
  back before moving on.

## Example, with its reason

> Question 4 asks "Would you use a faster export?" How would you ask about
> the last time they exported instead? People are poor judges of what
> they'll do, so a past instance tells you more than a prediction.
> Answer it, or reply "skip" and I'll note it as a risk.

## Vague words to push on

Not challenges from the bank: one-line questions that can come in any reply
(`operating.md`, "Push on vague words"). Rewrite each to fit.

| The word | The one-line push |
| --- | --- |
| "users struggled" | "Which users, on which task, and what did they do?" |
| "confused" | "What did they do that showed it? And was it the product, or something else?" |
| "frustrated" | "What did they say or do? How did that differ across the people you saw?" |
| "intuitive", "easy" | "What did people do that made it look easy? How many?" |
| "most", "many", "everyone" | "How many, out of how many?" |
| "users want" | "Who said it, how many, and who didn't?" |

---

Part of Magpie version 2026-11-01, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: partners-request-templates.md -->

# Partner request templates

Short messages the researcher can send to another team to ask for data or
context. Magpie fills them from the study record. Each one says what the
decision is, what's needed, by when, and what the partner gets back.

Everything a partner provides goes in the evidence log as **[partner data]**
with a confidence label. A field rep's summary of what customers say is
indirect evidence; a telemetry export is direct evidence about behavior but
says nothing about why.

## Product analytics or data science

> Hi [name]. I'm running a study to help [team] decide [decision] by
> [date]. Before I talk to users I want to size the problem. Could you pull:
> [what, e.g. "how many accounts reach step 3 of setup and how many finish
> it, last 90 days, split by plan"]? A rough number by [date] is enough. I'll
> share what the study finds so you can see whether it matches what you're
> seeing at scale.

Good asks: funnel drop-off, feature usage by segment, who to recruit (a list
of accounts matching a behavior), whether a qualitative finding shows up in
the numbers.

## Support

> Hi [name]. I'm looking into [topic] for a decision due [date]. Do you have
> the top ticket themes about [area] from the last [period], roughly how many
> of each, and two or three example tickets I could read (with customer
> details removed)? I'll send back what the study finds.

Good asks: ticket themes and counts, example tickets, which customers keep
hitting the same thing.

## Sales or field representatives

> Hi [name]. We're deciding [decision] by [date] and I want to understand what
> you hear from prospects about [area]. Could I have 20 minutes to ask about
> the last few deals where it came up, or could you point me to call notes or
> recordings? I'll treat it as context, not as the research itself, and I'll
> share the findings.

Good asks: deal blockers, competitor losses, buyer objections, which
accounts to recruit. Remember: buyers and users are often different people.

## Customer success or account teams

> Hi [name]. I'm studying [topic] ahead of [decision]. Which accounts are
> most affected, and is there anyone you'd suggest I talk to (or avoid
> contacting right now)? Any renewal risk or escalation context would help me
> frame it.

Good asks: who to recruit, who not to contact, renewal and escalation
context, enterprise constraints.

## Marketing or market research

> Hi [name]. Before I run a survey on [topic] I want to check whether you've
> asked anything similar recently, and whether you have segment definitions I
> should reuse so our numbers line up.

Good asks: existing surveys, segment definitions, brand or market studies,
analyst reports, win/loss analysis, competitor moves, avoiding duplicate
outreach to the same customers. Market research is logged as indirect
evidence about users: it describes buyers and markets, not what users do.

## What to send back

Every template promises findings in return. Keep the promise: a short note
with the two or three findings most relevant to that team, when the study is
done.

---

Part of Magpie version 2026-11-01, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: workshops-stakeholder-workshops.md -->

# Stakeholder workshops

A working session with PMs, designers and engineers. Most often it agrees
the problem before a study is designed (after stage 3) or turns findings
into ideas and decisions (after stage 8), but the type depends on what the
room needs. Not a readout; people make things.

## Use one when

- The team can't agree on what the decision is, or who makes it.
- Stakeholders hold different beliefs about users and nobody's written them
  down.
- Findings are in and the team needs to decide what to do, together.
- The research needs buy-in that a slide deck won't earn.

Stages 3 and 8 offer a workshop in one line when they see one of these.
The researcher can also start one at any time by typing "workshop".

## Don't use one when

- You want the people the decision is about to shape the design. That's
  research with users: `methods-participatory-design.md`.
- The team that decides has already decided. Run a readout and move on.
- The point is to inform, not to make something. A workshop that could have
  been a document wastes the room's time.
- You can't get the people who'll act on the output into the room.

## Before the workshop

Settle these with the researcher before drafting the agenda. Ask for what
the record doesn't already hold, with the other questions in one message.

- **The outcome and the type.** One sentence: what the room leaves with.
  This is the ideal end state, written first (S17). It decides the type
  (see "Choose the type from what the room needs").
- **How the room will decide.** For example: the room votes and the top
  three go ahead; or the room shortlists and the product team decides
  within a week. Write it on the agenda and say it at the start, so the
  room knows the rule before it starts choosing (S53).
- **In person, remote or hybrid.** See "Remote or hybrid" below.
- **Access needs.** The invite asks each attendee whether they need
  anything to take part fully. See "Access" below.
- **The pre-read.** One page: the decision, and the findings or the ask.
  Sent ahead and assumed read.

## Choose the type from what the room needs

Don't start from a format, even one the researcher names. Start from what
the room needs to leave with, then pick the type of workshop that produces
it. Each type is defined by its outcome (S30).

Work out three things first, from the record where it has them and by
asking where it doesn't:

- **What the room must leave with.** A decision, a shared picture of
  users, a set of ideas, a short list, a direction, or a verdict on a
  design.
- **What's already in hand.** A draft decision, findings, a design or
  concept, or a list of options.
- **Where the team is stuck.** Disagreeing about the problem, not knowing
  the users, jumping to one solution, too many options, or no agreed
  direction.

Then name the type in one line and say why: "This looks like a
prioritization workshop: you have 14 ideas and room for 3." Lay out the
activities you'd use. The researcher can change the type or swap any
activity, and Magpie builds on their choice. If the need spans two types,
run them in order and say so (ideas, then prioritization, is common). If
none fits, say that, build the session from the activities below, or
suggest a meeting or a document instead.

| The room needs to... | Type | Usually when | Core activities | Leaves with |
| --- | --- | --- | --- | --- |
| Agree on the problem and what nobody knows | Align on the problem (NN/g's discovery workshop) | After stage 3, before the study is designed | Assumption cards, system map, what would change our minds, the decision rewritten | A decision statement, the assumptions marked known, believed or disputed, and the research questions |
| Share one picture of the users | Understand the users (NN/g's empathy workshop) | After stage 7 or 8, when the team hasn't taken in the findings; before design starts | Findings in brief, empathy map, what this means for me | A written, shared picture of what users say, think, do and feel, and the gaps in it |
| Turn findings into ideas | Ideas from findings (NN/g's design workshop) | After stage 8 | How might we, silent ideas, cluster | Options, each tied to the finding it answers |
| Choose among options | Prioritization | When there are more options than the team can do | Rate on goal and cost, private vote, what else moves | A short list with the teams involved and the finding each rests on |
| Agree where we're headed | Set the direction | After ideas or prioritization; at stage 1 for a proposal | Hills, for teams that use them; plain outcome statements otherwise | One to three statements of the outcome for users |
| Check a design against what we learned | Critique (NN/g's critique workshop) | When a concept or design exists | Critique against the findings | Agreement on what the next version changes |

Signals that point to a type:

- "We can't agree who we're even designing for." Align on the problem.
- "The engineers have never met a customer." Understand the users.
- "The PM already wants a confirmation email." Ideas from findings, so
  the email becomes one option among several; or a critique of that idea
  against the findings.
- "We have 14 ideas and room for 3." Prioritization.
- "Leadership wants our goals as hills." Set the direction.
- "Design has mocks; does it fix what we found?" Critique.

Asked for a format by name, such as "a hills workshop", check it against
the need. If the need is different (the team still has 14 ideas to choose
from), say so in one line, suggest the type that fits, and keep the named
format where it helps (a hill for the 3 chosen ideas). The researcher
decides.

## Activities

Build each agenda from these. Every generative step starts with silent
writing.

- **Silent writing, then clustering.** Each person writes on their own
  first, one idea per note, so the loudest voice doesn't set the agenda.
  Then the room groups the notes and names each group (S15, S16, S56).
- **1-2-4-All.** Silent reflection, then pairs, then fours, then the room
  hears what stood out. Good for hearing everyone in a large group
  (S62).
- **Assumption cards.** Each person writes what they believe about users.
  The room marks each card known (evidence exists), believed (no evidence)
  or disputed.
- **System map.** One board: what comes before this in the user's flow,
  what comes after, which other teams and products touch it, and what else
  moves if it changes (`lenses-systems-and-journeys.md`, S61).
- **What would change our minds.** For each believed or disputed card,
  what evidence would settle it. The list becomes research questions.
- **Findings in brief.** Three to five findings, one slide each, with
  strength. Questions for clarity only. Fifteen minutes at most.
- **What this means for me.** Each person writes what they'd do
  differently because of each finding, then shares.
- **Empathy map.** Four areas around one user group: what they say
  (quotes from the study), think, do and feel. Each person fills in notes
  alone first, then the room clusters them. Built from the findings, not
  from guesses; an empty area is a gap in the research (S67).
- **How might we.** For the one or two findings with the most pull, each
  person writes "How might we..." questions, silently. The room picks two
  or three to work on (S55). A good one:
  - Grows out of a finding, not out of an idea someone already has.
  - Doesn't build in a solution: "How might we help managers trust that a
    swap went through?", not "How might we add a confirmation email?"
  - Is wide enough for many answers and narrow enough to start on.
  - Names the outcome people want, not the symptom the team wants gone.
- **Silent ideas.** For each chosen question, ideas written alone first,
  quantity before quality. Then share and group them.
- **Rate on goal and cost.** Each option rated on how much it moves the
  goal and how much it costs. For each option picked: what else moves if
  we do this, and who else is affected?
- **Private vote.** Everyone votes before seeing anyone else's votes, then
  the votes are shown together, so nobody follows the loudest or most
  senior person (S54). The room decides the way it agreed at the start
  (S53).
- **Hills.** See "Hills, for teams that use them" below.
- **Critique against the findings.** The findings are the objectives the
  design is judged against. Agree the scope first. Each person notes,
  silently, where the design meets or misses each finding; then a round
  robin, one point each. A comment of taste ("I don't like the blue") is
  reframed around a finding or set aside (S68).
- **Read-back.** Before anyone leaves: the decisions, the actions, the
  teams involved and the finding each rests on, and how progress gets
  checked.

Teams decide among themselves who takes each action. Magpie names one
person only when the researcher asks for names.

### Hills, for teams that use them

Some teams, especially those trained in IBM's Enterprise Design Thinking
framework, write their intended outcomes as hills. In IBM's framework a
hill is a statement of intent written as an outcome for users, in three
parts: who it's for, what they'll be able to do, and the "wow" that sets
it apart and shows it worked. It says where to go, not how to build it
(S58).

- Use hills only if the researcher or the team profile says the team uses
  them. Otherwise write plain outcome statements: who, what they'll be
  able to do, and how we'd know.
- Write the hill in the room's own words. Don't copy IBM's materials or
  templates; link to IBM's framework page
  (https://www.ibm.com/training/enterprise-design-thinking/framework) if
  the team wants the background.
- The room agrees the hill together. Don't name a single person as its
  owner.

## Two example agendas

Starting points, not fixed scripts. Change the activities to fit the type
chosen above.

### Align on the problem (80 to 90 minutes)

1. **Frame (10 min).** The ask as it arrived, the draft decision statement,
   and how the room will decide.
2. **Assumption cards (20 min).** Silent writing, then clustering, then
   known, believed or disputed.
3. **System map (10 min).** Anything the room isn't sure of becomes a
   believed or disputed card.
4. **What would change our minds (15 min).**
5. **The decision, again (15 min).** Rewrite the decision statement with
   the room. Say the deadline and the teams involved out loud.
6. **Close (10 min).** Read back the decision, the questions and the next
   steps the room agrees on.

### Ideas from findings, then prioritization (120 minutes)

1. **Findings in brief (15 min).**
2. **What this means for me (15 min),** shared with 1-2-4-All.
3. **How might we (15 min).**
4. **Silent ideas (20 min).**
5. **Break (10 min).**
6. **Rate on goal and cost, then a private vote (20 min).**
7. **Hills or outcome statements (10 min, optional).**
8. **Read-back (15 min).** Agree how progress gets checked and when the
   room looks at it again.

## Running it well

- Silent writing before discussion, so the loudest voice doesn't set the
  agenda (S15, S16).
- One facilitator, one note-taker. The researcher facilitates; a teammate
  takes notes.
- Everything written on cards or a shared board, so the output exists
  without anyone's memory.
- A break in anything longer than 90 minutes.
- Decisions, actions and the teams involved read back before anyone
  leaves.

## Remote or hybrid

Online, the same activities take longer, so leave more time, not less
(S57).

- If even one person joins remotely, consider running the whole session
  remotely, so everyone takes part the same way (S57).
- Use a board tool the team already knows. Test it beforehand: access,
  permissions, and how many people can edit at once (S57).
- Change activity every 15 to 20 minutes (S57).
- With more than 10 people, use breakout groups of three to five, with
  written instructions for each (S57).

## Access

- Ask about access needs in the invite, and plan for them before the day
  (`lenses-accessibility.md`).
- Every activity has another way to take part: typing into a shared
  document instead of placing sticky notes, saying a vote instead of
  dragging a dot, a screen-reader-friendly copy of the board.
- Read out what's on the board when the room moves on, for anyone who
  can't see it.
- Send the pre-read in a format people can read with their own tools.

## After

Magpie drafts the summary from the notes with
`templates-workshop-summary.md`: the decision or the actions with the
teams involved, the finding each rests on, the assumptions or the ideas
not chosen, and the next steps the room agreed. It goes in the study
record's change log and to everyone who attended, once the researcher has
reviewed it.

The agenda and the summary are documents the team shares, so give each as
a Word file (.docx) as well as Markdown, the same as a plan or report
(`operating.md`, "Files for the team"). Each
opens with a document details table (team, date, author(s), reviewers and
status). Status starts as Draft and changes only when the researcher says
so. The agenda steps are numbered in Word's own numbering, so people can
say "step 3". Both follow `templates-house-style.md`.

## Challenge

"What decision should the room leave with? If you can't say it in one
sentence, the workshop isn't ready."

## Pitfalls

- A workshop as a substitute for a decision the team should just make.
- Presenting for 40 minutes and calling the last 20 a workshop.
- Picking the format first ("let's do hills") and fitting the need to it.
- Going from findings straight to solutions, with no "How might we" step.
- Open dot voting, where people follow the first or most senior votes.
- Actions with no team, or one person named for everything.
- Output that lives only in photos of sticky notes.

## Templates

`templates-workshop-agenda.md`, `templates-workshop-summary.md`

## Basis

S17 and S30 (an outcome first; each workshop type has a defined outcome,
and the discovery, empathy, design, prioritization and critique types);
S15 and S16 (silent writing and brainwriting before discussion); S56
(individual notes, then clustering as a team); S62 (1-2-4-All, credit
Henri Lipmanowicz and Keith McCandless, Liberating Structures, CC BY-SA
4.0); S55 ("How might we" questions after discovery, before ideas); S53
(agree the decision rule); S54 (dot voting's choice overload, choice
imbalance and social bias); S57 (remote workshops); S58 (hills, IBM
Enterprise Design Thinking, described here in Magpie's own words); S67
(empathy maps, built alone first, then clustered); S68 (critique against
agreed objectives, round robin). The "set the direction" type, the signals,
assumption cards, the step timings, the private vote, the break and the
access steps: practitioner judgment.

---

Part of Magpie version 2026-11-01, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.
