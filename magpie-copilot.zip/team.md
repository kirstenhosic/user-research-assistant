<!-- Magpie, combined for Copilot. Holds `team-intake-form.md`, `team-research-library-entry.md`, `team-team-profile.md`. -->

<!-- file: team-intake-form.md -->

# Research request: [topic]

For PMs, designers and engineers asking for research. Five minutes to fill
in. It goes straight into stage 3, so the more honest it is, the faster the
study starts.

**Requested by:** [name, role] · **Date:** [date]

## What are you trying to decide?

[One or two sentences. "Whether to…", "Which of…", "How to…". If you're not
deciding anything yet, say what you're trying to understand and why.]

## What product is this about? (optional)

[What it is and what it does, in a sentence. Which part this request is
about. Who uses it day to day, and who buys or sets it up if that's
someone else. If you're not sure, say so.]

## Who decides, and when?

- **Who decides:** [team or group]
- **Needed by:** [date] because [what happens then]

## What do you already believe?

[Be honest. "I think users abandon export because it's slow." These become
assumptions the study can test.]

## What would change your mind?

[What result would make you choose differently?]

## What do you already have?

[Analytics, tickets, past research, customer conversations. Links or a
sentence. "Nothing" is fine.]

## Who is this about?

[User group, segment, role. If you don't know, say so.]

## Anything else?

[Constraints, politics, history, things Magpie and the researcher should
know.]

---

Part of Magpie version 2026-11-09, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: team-research-library-entry.md -->

# Library entry: [finding in plain words]

One finding, one entry. Written at stage 8, searched at stage 2 of the next
study. Short enough to read in thirty seconds. No participant names.

- **Finding:** [the claim, one or two sentences]
- **Strength:** [strong / moderate / weak] because [one line]
- **Evidence:** [method, N, who, e.g. "8 interviews with self-serve admins
  who signed up in the last 30 days"]
- **What cut against it:** [one line]
- **Study:** [study name, date, link to record and report]
- **Product and area:** [tags the team uses]
- **Still valid as of:** [date] · **Likely stale after:** [the change that
  would invalidate it, e.g. "the new export flow ships"]
- **Related entries:** [links]

---

Part of Magpie version 2026-11-09, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: team-team-profile.md -->

# Team profile: [team name]

One file Magpie reads at the start of every study. Keep it short and
current; review it each quarter. No participant names or contact details
here, ever.

Last updated: [date] by [name]

## Products and users

- **Products:** [names, one line each, in plain words]
- **Who uses them:** [main user groups, in the team's own segment names]
- **Who buys them, if different:** [ ]
- **Where to read about them:** [product docs, help center, public site]

## Company goals and metrics

The goals leadership talks about and the numbers they watch. Magpie uses
these names when it ties findings to business value.

| Goal | Metric | Owner |
| --- | --- | --- |
| [e.g. Grow self-serve revenue] | [e.g. Trial-to-paid conversion] | [role] |
| | | |

## Market context

Indirect evidence about users, useful for sizing, segments and framing.
Magpie logs it as partner data with its date.

- **Segments we compete in:** [ ]
- **Main competitors:** [ ]
- **Market research we have:** [analyst reports, win/loss, buyer surveys;
  where they live and who owns them]
- **Current company bets:** [the two or three things leadership is betting
  on this year]

## Jobs, journeys and personas

What the team already has. Magpie uses these names and links rather than
inventing its own.

| Kind | Name | What it covers | Link |
| --- | --- | --- | --- |
| Critical user journey | [e.g. First report] | [steps, in brief] | |
| Journey map | | | |
| Persona | [e.g. Team admin] | [defining behavior] | |
| Jobs list | | | |

## How the product fits together

A few lines on the larger system: the main flows, what feeds what, which
teams own which pieces. Magpie uses this to ask about upstream and
downstream effects.

## Stakeholders

| Role | Name or team | What they usually need from research |
| --- | --- | --- |
| Product | | |
| Design | | |
| Engineering | | |
| Leadership | | |

## Partner teams and who to ask

| Team | Holds | Contact (role) | How to ask |
| --- | --- | --- | --- |
| Analytics | | | |
| Support | | | |
| Sales | | | |
| Customer success | | | |
| Marketing | | | |

## Research operations

- **Recruiting:** [panel, tool, who approves, typical lead time]
- **Incentives:** [amounts, how paid, who approves]
- **Consent:** [standard form or script, where it lives]
- **Recording and storage:** [tool, where files go, who has access]
- **Company names in internal outputs:** [allowed / not allowed]. Whether
  customers' or employers' company names may appear in outputs shared
  inside the team or company. Leave it blank for "not allowed". Never
  allowed in outputs shared outside, and participants' names are never
  allowed anywhere.
- **Retention:** [how long raw data is kept, who deletes it]
- **Extra rules:** [legal, regional, industry-specific]

## Where things live

- **Study records:** [folder or repo]
- **Research library:** [folder, wiki, tool]
- **Past reports:** [ ]

## Preferences

- **Default challenge level:** [standard / push me / light]
- **Personality:** [on / off]
- **Readout format the team likes:** [slides / doc / both]
- **Readout and report template:** [name or link / none: use Magpie's house style]
- **Spelling and dates:** [American English (the default) / British English / another, such as Australian English]
- **Quote label:** [what follows the participant code on a quote, such as role and company size: "P3, finance manager, SMB"]
- **Anything else Magpie should know:** [ ]

---

Part of Magpie version 2026-11-09, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.
