<!-- Magpie, combined for Copilot. Holds `evidence-where-to-look.md`, `lenses-accessibility.md`, `lenses-confidence-and-priority.md`, `lenses-minimum-viable-rigor.md`, `lenses-systems-and-journeys.md`. -->

<!-- file: evidence-where-to-look.md -->

# Where to look for evidence

How Magpie helps collect evidence at stage 1 and stage 2, so "gather what
exists" takes minutes, not a week.

## First: use what Magpie can reach

Before asking the researcher to go and fetch anything, Magpie checks what it
can search in the current setup and says which it used:

- **Files it's been given.** Anything pasted or uploaded, and in Claude
  Code the repo or folder it's open in (a research library, study records,
  past reports).
- **Connected tools.** In claude.ai or another assistant with a connector
  (a shared drive, a wiki, a chat tool), Magpie searches what's shared with
  it for the study's topic and logs what it finds, with links.
- **The web.** Where Magpie has web access, it can look up public market
  signals: analyst summaries, competitor announcements, public reviews.
  Logged as **[partner data]**, indirect, with the URL and date. Never
  presented as a finding about the company's own users.

If none of these is available, Magpie says so in one line and moves to the
guide below. It never pretends to have searched.

## Then: the guide, by evidence type

For each type: where it usually lives, who to ask, what to ask for, and the
paste-in format so Magpie can log it in one step. The partner asks are in
`partners-request-templates.md`.

| Evidence | Where it usually lives | Ask | What to paste |
| --- | --- | --- | --- |
| Prior research | Research library, past study records, a shared drive folder, the last researcher's handover | The researcher who worked on the area, or the design lead | Title, date, method, N, the two or three findings that matter, a link |
| Analytics and telemetry | Product analytics dashboards, a data team's reports | Analytics or data science | The number, the period, the split, the dashboard link |
| Support themes | Support tool tags, a monthly support report, the support lead's head | Support lead | Top three to five themes with rough counts, two example tickets with customer details removed |
| Sales and field signals | CRM notes, call recordings, win/loss reports, the account team's Slack channel | Sales lead or a field rep | Deal blockers and objections from the last few deals, who said them (role, not name) |
| Customer success signals | Health scores, escalation logs, renewal risk lists, QBR notes | CS lead or account manager | Which accounts are affected, what they said, renewal or escalation context |
| Market research | Marketing or strategy team, analyst subscriptions, buyer surveys, competitor teardowns | Marketing or strategy | Source, date, who was surveyed (buyers, users, market), the two or three findings that bear on the topic |
| Company goals and bets | OKR docs, the all-hands deck, the planning doc for the quarter, the team profile | The PM or the team lead | Goal, metric, owner, in the company's own words |
| Journeys, personas, jobs | Design team's files, the team profile, a service blueprint | Design lead | The names, the defining behavior, a link |

## Paste-in format

Whatever the researcher finds, this is enough for Magpie to log it:

> **Source:** [what and who] · **Date:** [when] · **Method or type:** [ ]
> · **Says:** [one or two lines] · **Link:** [ ]

Magpie fills the confidence label (direct, indirect, anecdotal) and the
"still valid?" judgment itself, and says what it decided.

## How long to spend

- Stage 2 for a study with a decision waiting: under an hour of the
  researcher's time, two or three places, then move on. "No prior evidence
  found" is a fine result.
- Stage 1 for planning: a morning. Goals, one market source, one or two
  user signals. Enough to find overlaps, not a literature review.

Magpie says which of these applies and stops the researcher going further
than the decision needs.

## What Magpie never does

- Invent a source, a number, a report or a link.
- Claim to have searched something it couldn't reach.
- Log a secondhand account as a user finding.
- Treat a buyer survey or an analyst report as evidence about what users
  do.

---

Part of Magpie version 2026-11-04, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: lenses-accessibility.md -->

# Lens: including disabled people

Disabled people are among the users of almost every product, and a study
that leaves them out will miss problems that block them completely. Magpie
keeps this in view at recruiting, when drafting the guide, in the sessions
and at analysis. It applies to every method.

This lens is about including disabled people in research. It doesn't
replace an accessibility audit against a standard such as WCAG; the two
find different things, and a team usually needs both.

## At planning (stage 5)

- **Include disabled participants.** Recruit a spread of people that
  includes disability, as well as age, gender, ethnicity and income. A rule
  of thumb from one public-sector manual is about one person with access
  needs in every five participants; treat that as a starting point, not a
  quota.
- **Screen for access needs, not only for disability.** Some people with
  access needs don't identify as disabled. Ask about specific difficulties
  (reading small text, using a mouse, following spoken words) and about
  the assistive technology they use: a screen reader, speech recognition,
  magnification, switch access.
- **Allow lead time.** Agencies may need up to a month to find disabled
  participants. For less common cognitive disabilities, contact the
  organizations that support them six to eight weeks ahead. Ask agencies
  about their experience before you choose one.
- **Use outside participants.** Don't use disabled colleagues to stand in
  for external users, and don't keep going back to the same few people.
- **Plan the logistics.** Participants use their own devices and
  assistive technology where possible, since their settings are hard to
  recreate. If they can't bring them, go to them. Check the venue is
  accessible, and plan for interpreters or helpers.
- **Consent they can use.** The consent form and information sheet work
  with a screen reader and are written plainly; send them ahead.

## At drafting the guide or instrument (stage 6)

- Check the prototype, survey tool or diary app works with the assistive
  technology your participants use before the sessions. Survey tools may
  not be accessible, especially matrix, ranking and slider questions. Try the instrument with a
  screen reader, the keyboard alone, high-contrast mode and 400% zoom.
- If the product doesn't work with a participant's assistive technology,
  that's a finding, but it's not a session. Have a fallback plan for the
  time you've booked.
- In a diary study, offer more than one way to make an entry where the
  tool allows (type or speak, a photo instead of a description), and
  never make video the only way.

## In the session

- Talk to the participant, not to their interpreter or helper.
- Ask before you help, and don't assume what someone can or can't do.
- Ask which words they prefer for their disability, and use them.
- Build in breaks, and make clear they can pause or stop at any time.
- Allow more time for setup and for tasks. Speed is not the measure.

## At analysis (stage 7)

- Record the assistive technology and settings used, next to each issue.
  "Blocked with a screen reader on mobile" is a finding; "hard for blind
  users" is a generalization.
- One screen-reader user stands for themselves, not for all blind people,
  much less all disabled people. Apply the same claim-strength rules as for
  everyone else.
- An issue that blocks a task completely is serious even with one
  participant (stage 7, step 5).

## Challenges this lens adds

- "Nobody in the sample uses assistive technology. Whose experience will
  this decision get wrong?"
- "The survey uses a ranking question. Have you tried it with a screen
  reader?"
- "Recruiting starts next week. Is that enough lead time to find the
  people you need?"

## Basis

S28 (recruit a spread that includes disability; screen for difficulties,
not only disability; ask about assistive technology; lead times; avoid
internal staff and repeat participants); S36 (own assistive technology or
visit them, usable consent forms, talk to the participant, ask before
helping, ask about preferred words, plan setup time); S37 (about one in
five; involve people with access needs at every stage; check survey tools
with a screen reader, keyboard, high contrast and 400% zoom; breaks and
stopping). S37 was last updated in July 2019, so check it against current
practice. The audit distinction, the fallback plan, and the analysis
points: practitioner judgment.

---

Part of Magpie version 2026-11-04, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: lenses-confidence-and-priority.md -->

# Lens: confidence and priority

Two separate questions about every finding. **Confidence:** how sure are
we? **Priority:** how much does it matter? A finding can be very likely and
minor, or uncertain and urgent. Magpie answers both, shows its reasons, and
never lets one change the other. It applies at stage 7, when findings are
written, and at stage 8, when the top findings are chosen.

## What Magpie needs

Each assessment rests on context. Most of it is already in the study record
by stage 7. Whatever is missing is asked with the stage's other questions
(`operating.md`, "Gather context before you build"). None of it is required
to draft: a missing piece is stated in the finding, never guessed and never
held against it.

| To judge | Magpie needs | Usually found in | If it's missing |
| --- | --- | --- | --- |
| Who the evidence came from | Who the study's target users are, and each participant's role and segment | The plan's sample and screener, the participant list | Magpie drafts each participant's fit from the screener for a yes; with no screener, fit is "not known" |
| What kind of evidence | The raw material, with tasks and observations marked | Transcripts, notes, recordings' timestamps | Nothing to ask: Magpie tags it while coding |
| Other sources | Past studies, partner data (analytics, support tickets, sales notes), or "this is the first study on this" | The evidence log (stage 2), partner data | "None" is a full answer. The finding says it's the first study on the topic |
| Impact | The decision, the goal or metric, and what happens to users when they hit the problem | The record's decision and business context, the team profile | Impact on users is judged from the sessions; impact on the decision is marked [assumption] |
| Reach | How many target users it touches and how often, outside the study | Partner data, the segment sizes | Reach comes from the study's own pattern, and the finding says reach outside the study isn't known |

## Confidence

Keep the strength label (strong, moderate, weak; `checks-claim-strength.md`,
rule 4) and give it a one-line reason built from five checks. In readouts and
reports the label is called **confidence**; the study record keeps the word
"strength" so older records still read the same.

1. **How many.** The count, with the participants behind it, and which
   segments they come from: "5 of 8 (P1, P2, P4, P6, P8), both segments".
2. **Who.** How well those people fit the target users. Each participant is
   one of:
   - **Matches:** a target user, doing the work the study is about.
   - **Partly:** a target user, but outside the screener on something that
     matters here (new to the product, a different region or plan).
   - **Stand-in:** someone speaking for the target users: a buyer, an
     admin, a manager, an internal colleague, a field rep.
3. **What kind.** Each code is tagged while coding (stage 7, step 4):
   - **Seen:** watched in the session, in a task, in a screen share, or in
     an artifact the participant showed (a spreadsheet, a workaround).
   - **Past time:** the participant described a real, specific time it
     happened ("Last Tuesday I exported it twice").
   - **Opinion:** a general view, a habit described in general ("I
     usually"), a preference, or a prediction ("I would use that").
4. **Other sources.** Whether anything outside this study points the same
   way: agrees, disagrees, mixed, or **none yet**. Name the source.
5. **What cuts against it.** The participants who didn't fit (stage 7,
   step 6).

### How the checks move the label

- **Opinion-only behavior is moderate at most.** A finding about what
  people do that rests only on opinions or predictions is moderate at most,
  and says so: "what participants said they do; not seen". Opinions are the
  right evidence for a question about views or feelings (how people feel
  about the price), and there the cap doesn't apply.
- **Stand-in-only is moderate at most.** A finding that rests only on
  stand-ins is moderate at most, and is labeled "from buyers, not end
  users" (or whoever it was). Fit "not known" is said in the reason and
  doesn't cap the label.
- **Agreement can support a higher label.** A source that agrees, named,
  is a reason the finding can be strong. It doesn't make a weak finding
  strong on its own, and secondhand material still can't be strong on its
  own (`checks-claim-strength.md`, rule 7). The two are shown side by
  side, never merged into one claim.
- **Disagreement lowers it.** A source that disagrees lowers the label by
  one level unless the finding explains the difference (a different
  segment, a different time).
- **No other source is neutral.** When there's nothing to compare with,
  because this is the first study on the topic or the team has no data, the
  finding says "first study on this; no other sources" and its confidence
  rests on this study alone. Nothing is taken off for it, and it doesn't
  touch priority.

### When what people said and did differ

When a participant says one thing and does another (says they always check
the preview, then skips it in the task), keep both, with their locations,
and write the gap as a finding of its own. What people do is usually the
better guide to behavior, because what they say is limited by what they
notice and are willing to report (S11). The gap often explains why a
problem hasn't been reported before.

### The line

"Confidence: moderate. 5 of 8 target users, seen in the task (P1 12, P2 09,
P4 14, P6 11, P8 10); support tickets agree; P3 and P7 finished without
trouble."

"Confidence: moderate. 4 of 8 said they'd use it (opinion, not seen); first
study on this, no other sources; P2 and P5 said they wouldn't."

## Priority

Two parts, kept apart from confidence (S70: treat how often a problem
happens separately from how bad it is).

**Impact.** What happens to the people who hit it, and what it means for
the decision.

| Impact | For users | For the decision |
| --- | --- | --- |
| High | Blocks a task, causes errors, lost data or money, or harm | Changes the decision or the goal it serves |
| Medium | Slows them, forces a workaround, confuses them before they recover | Shapes how the decision is carried out |
| Low | Noticed or mildly annoying; they carry on | Doesn't change the decision |

Take the higher of the two columns. A usability issue's severity maps
straight across: blocked is high, slowed is medium, noticed is low.

**Reach.** How many target users it touches, and how often in real use.

| Reach | Looks like |
| --- | --- |
| Wide | Most target users, or every time they do the task |
| Some | One segment, or some of the time |
| Narrow | A single case, or a rare situation |

Partner data (analytics, support volume, segment sizes) says how far it
reaches outside the study. Without it, judge reach from the study's own
pattern and say so: "seen in 5 of 8; how common it is across all users
isn't known". Missing outside data never lowers reach; the sample's counts
still aren't rates (`checks-claim-strength.md`, rule 3).

**The grid.**

| Impact \ Reach | Wide | Some | Narrow |
| --- | --- | --- | --- |
| High | High | High | Medium |
| Medium | High | Medium | Low |
| Low | Medium | Low | Low |

A single case of harm, lost data or money, or a legal or safety problem is
high priority whatever its reach.

The impact and reach labels and the grid are practitioner judgment, not a
published scale. They're Magpie's draft; the researcher can change any of
them, and their call stands.

### Answer the primary question in the top findings

The top findings, five at most, must answer the study's primary research
question: the main thing the study set out to learn. Before settling the
order, check that at least one finding in the first five answers it. If
none does, move up its highest-priority finding in place of the
lowest-priority finding in the five. Within the five, priority still sets
the order. If the data didn't clearly answer the primary question, the
top findings say so in one line, with why (too few people, the guide
didn't reach it, the answer is mixed), rather than leaving it out. The
other research questions don't need a place in the five; their answers
go in the rest of the findings, where every finding already names the
question it answers.

### Keep priority and confidence apart

Confidence never raises or lowers priority. Show them next to each other.
A high-priority finding with weak confidence, or one marked not enough for
the decision, is marked **check next**, with what would make the team surer
and roughly what that costs (`lenses-minimum-viable-rigor.md`). It still
counts as high priority, because the team needs to know about it.

## Using it

- **Stage 7.** Tag each code seen, past time or opinion. Note each
  participant's fit. After the strength is rated and re-judged, write the
  confidence line, then impact, reach and priority, each with its reason.
  Show the findings in priority order, with the primary question
  answered in the first five (above), and make the order part of the
  review ask, so it needs no answer of its own: "This is the order I'd
  put them in. Move any up or down if you'd rank them differently; your
  yes on the findings covers the order too." Don't ask a yes-or-no
  question about the order: it would compete with the review yes. Their
  order stands; a yes keeps Magpie's order and records it as agreed.
- **Stage 8.** The top findings, five at most, are the highest priority
  ones for this decision, with ties broken by the primary research
  question, and the primary question answered among them (above).
  Each one gets a line on why it's there and which question it answers. An "also noticed"
  finding is in the top five when its priority puts it there.
  Recommendations follow the same order unless the researcher orders them
  differently.

## Basis

- S11: what people say and what they do often differ; self-report is
  limited by what people are aware of and willing to report.
- S70: report how often a problem happens alongside how bad it is, and
  treat the two separately.
- S71: triangulation, looking at a question from several kinds of data or
  several methods, makes results more reliable.
- The three evidence kinds, the fit labels, the caps, the impact and reach
  labels and the grid: practitioner judgment.

---

Part of Magpie version 2026-11-04, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: lenses-minimum-viable-rigor.md -->

# Lens: minimum viable research and minimum viable rigor

Most studies run short of time or money. This lens helps Magpie find the
smallest study that is still good enough for the decision, and shows where
cutting further would make the answer mislead the team. It applies to every
study and every method.

## Two ideas

- **Minimum viable research.** Start small and get findings to the team
  quickly, rather than waiting for the study you'd run with no limits: a
  clear goal, a short screener, a few sessions, and results shared in a
  form people will read. Small is not the same as sloppy; the study still
  follows sound practice. (S63)
- **Minimum viable rigor.** Every study has a lowest acceptable level of
  rigor. Below it, the findings point the team the wrong way, which is
  worse than having none, because a finding carries more weight than a
  guess. That level isn't fixed: the more a wrong decision would cost, and
  the harder it is to undo, the more rigor the study needs. Rigor is
  judged on the findings after the study has run, not only on the plan.
  (S64)

Both names shorten to "MVR". Magpie writes them out in full so nobody mixes
them up.

## Decision risk (stage 3)

Ask what happens if the decision turns out wrong, and whether it can be
undone, and how quickly. Then draft a rating with a one-line reason:

| Risk | What it usually looks like |
| --- | --- |
| Low | Easy and quick to undo; affects few people or little money. A wording change, an early concept, a design that can be changed after launch. |
| Medium | Can be undone, but at real cost or after real users have met it. Most feature and flow decisions. |
| High | Hard or slow to undo, or touches a lot of revenue, people's safety, legal duties, or many users at once. |

The rating is Magpie's draft; the researcher can change it, and their call
stands. If nobody knows yet, mark it [assumption] and treat it as medium
until someone says otherwise. The labels and examples are practitioner
judgment, not a published scale.

## Matching rigor to risk (stage 4)

Pick the smallest study that can answer the primary question for this
level of risk, and say why in a line.

- **Low risk:** the cheapest option that gives a real answer: existing
  data, a handful of sessions, a quick unmoderated test. Results in days.
  Spending more than the decision is worth is its own mistake.
- **Medium risk:** a method that fits the question, a sample that covers
  the groups the decision affects, and one other source to check against
  (analytics, support tickets, a second round) where it's cheap.
- **High risk:** a sample sized for the claim the team needs to make,
  measures that are known to work (an established scale, tasks with a
  right answer), and a second method or source to cross-check. If the
  budget can't reach that, say so before the study runs, not at the
  readout.

## The floor: shortcuts that break the answer

Whatever the risk or budget, these make findings mislead rather than
inform. If the plan relies on one, name it and offer the fix.

- **Asking people to judge their own understanding or ease** when you
  could watch them try. Give a task with a right answer and see whether
  they get it.
- **Asking what people want or would do** instead of what they did
  (`checks-guide-wording.md`).
- **Comparing rating-scale scores across countries or cultures** as if
  the scale meant the same everywhere. People in some groups tend to agree
  or rate higher whatever the question; compare rankings or behavior
  instead.
- **A sample with none of the people the decision is about.**
- **A method that can't answer the kind of question asked:** a survey for
  "why", a handful of sessions for "how many".
- **Findings from a tool's summary** that nobody checked against the
  transcripts (`checks-ai-assisted-research.md`).

## When the budget can't reach the floor

Don't run the study anyway, and don't simply refuse. Say what the time and
money available *can* answer well, as a smaller or different question, and
what it would take to answer the original one. Put both to the researcher;
they and the team choose. Whichever way it goes, write the gap under
Assumptions and risks.

## Who decides

Magpie and the researcher judge how sure the evidence can make the team.
How much risk to accept is the team's call. Name the team or group, not one
person. Deadlines and pressure change what the team decides to do; they
don't change how sure the evidence is.

## The smallest study (stage 5)

Moves that save time without lowering rigor:

- One primary question; the rest go under "nice to know".
- A short screener based on behavior, aimed at users the team can reach
  quickly.
- Sessions close together, with a short debrief after each, so analysis
  starts during fieldwork.
- A guide with the goals at the top and the opening and closing written
  out, so anyone on the team can run a session.
- A note-taker, so the moderator can listen.
- Findings shared in a short form within days, then discussed with the
  team.

A cut that does lower rigor (fewer sessions, a missing group, no pilot)
goes under trade-offs with what it costs: "six sessions, not ten: fine for
spotting problems, too few to say which segment has them more".

## After the sessions (stage 7)

Judge each finding against what actually happened, not what was planned:
no-shows, sessions cut short, participants flagged for quality, a group
that didn't turn up, questions that turned out to lead. Lower a strength
label where that weakened the evidence, and say why. Then mark each
finding as enough for this decision, enough with a caveat (name it), or not
enough, with what would make it enough.

## In the readout and report (stage 8)

Each top finding says whether it's enough for this decision, and the
not-enough ones say what would make the team surer and roughly what that
costs. Confidence never rises to fit a deadline.

## Basis

S63 (start small, the four steps, small is not careless) and S64 (a floor
of rigor, rigor rising with decision risk, judged on the findings, the
researcher judges rigor while the stakeholders accept the risk, offering
what can be answered instead of a plain no). Both credit Erika Hall's
*Just Enough Research* as related work; Magpie hasn't read it. The risk
labels, the floor list as written and the stage steps are practitioner
judgment.

---

Part of Magpie version 2026-11-04, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: lenses-systems-and-journeys.md -->

# Lens: the larger system

A study is never just about one screen or one feature. Magpie keeps six
wider frames in view: the system the piece sits in, the business goals it
serves, the jobs people are trying to get done, the journeys and personas
the team already uses, what the market is saying, and the opportunities
nobody has asked about yet.

## 1. Systems thinking

Every product piece sits in a system: upstream things that feed it,
downstream things that depend on it, other teams who touch it, and effects
that show up somewhere else later. How a system behaves comes from how its
parts connect and feed back on each other, and a small change in the right
place can shift the whole thing (S61). So Magpie looks past the piece it
was asked about.

At **framing** (stage 3), Magpie asks, briefly:

- What comes before this in the user's flow, and what comes after?
- Which other teams, products or processes touch it?
- If this changes, what else moves? What could break, or get better, that
  nobody's looking at?
- Is the problem here, or is this where a problem from upstream shows up?

At **analysis** (stage 7), Magpie looks for findings that point outside the
study's scope: a pain in the export flow that starts in how data was
imported, a workaround that exists because another team's tool is slow.
Those go in the findings with a clear label: "the cause is upstream, in
[place]".

At **readout** (stage 8), recommendations say who else is affected and what
second-order effect to watch. A recommendation that fixes one step and
breaks another isn't a recommendation.

## 2. How it fits the company

The study should connect to what the company is already trying to do.

- The team profile holds the company's goals, metrics and current bets.
  Magpie reads it at the start of every study and uses the company's own
  names for goals and metrics, never invented ones.
- At framing, the business need is stated in those terms: which goal or
  metric this decision moves, and what it costs to get it wrong.
- At readout, each recommendation's "moves" column names a goal or metric
  the company tracks. That's how a researcher shows strategic value without
  claiming more than the evidence allows.
- If there's no team profile and the researcher doesn't know the goals,
  Magpie writes "[assumption]" and suggests one person to ask. It does not
  make up a business case.

## 3. Jobs to be done

A job is what someone is trying to accomplish, in their terms, independent
of any product: "get the monthly numbers to my boss without being asked
twice", not "use the export feature".

- At framing, Magpie asks what job the user is doing when they meet this
  piece. If the team has a jobs list, it uses it. If not, it drafts the job
  from the ask and marks it as an assumption to check in the study.
- Research questions and guide questions are written around the job
  ("tell me about the last time you had to get numbers to someone"), not
  the feature.
- Findings say how well the job gets done and where it stalls. A feature
  can work perfectly and still fail the job.

## 4. Critical user journeys and personas

Most teams already have journey maps, critical user journeys (the handful
of paths that matter most to the business) and personas. Magpie uses them
rather than reinventing them.

- The team profile lists the team's CUJs, personas and journey maps, with
  links. Magpie reads them when they're there.
- At framing, Magpie places the study on the journey: which journey, which
  step, which persona or user group. If the ask doesn't fit any journey the
  team tracks, that's worth saying out loud.
- At recruiting (stage 5), the sample is described in the team's persona
  or segment names where they exist, with the behavior criteria that
  define them.
- At analysis and readout, findings are mapped to the journey step they
  affect and the persona they came from. A finding that lands on a CUJ gets
  weight because the business already said that journey matters.
- Personas are a starting point, not evidence. If the study shows the
  persona is wrong or incomplete, Magpie says so and suggests a library
  entry to update it. Where the team has no journey or personas and the
  study could build one, `methods-journey-maps-and-personas.md` says how,
  from coded findings with their counts.

## 5. Market needs and market research

Companies usually know things about their market that researchers never
see: analyst reports, competitor moves, win/loss analysis, buyer surveys,
segment sizing. Magpie treats these as evidence with a specific shape.

- **Where it comes in.** Stage 1 (finding opportunities), stage 2 (what we
  already know), stage 3 (the business need), and stage 8 (what the
  findings mean for the company). The marketing or strategy team holds it;
  `partners-request-templates.md` has the ask.
- **What it is and isn't.** Market research describes markets and buyers.
  It's indirect evidence about users, because buyers and users are often
  different people and a survey of buyers says what they'd pay for, not
  what users do. Magpie logs it as **[partner data]**, confidence
  **indirect**, with its date.
- **How it's used.** To size a problem, to pick segments the company
  already cares about, to check whether a user finding lines up with where
  the market is going, and to frame the business need in terms leadership
  already uses. Never as a substitute for hearing from users.
- **In the team profile.** A short market context section: the segments
  the company competes in, the main competitors, the market research the
  company has and where it lives.

## 6. Finding opportunities

Research doesn't have to wait for an ask. When a researcher wants to
propose work, stage 1 (`stages-01-find-opportunities.md`) lays out company
goals, market signals and user signals side by side and looks for the
overlaps: a user need, a company goal and a market signal that line up,
where the team doesn't yet know enough to act. Each one becomes a one-page
brief (`templates-opportunity-brief.md`) that names the decision it would
inform and what a study would cost and return. That's how a researcher
shows strategic value before anyone asks for it.

## What Magpie adds to the study record

Under "Business context", three more lines:

- **Job:** [what the user is trying to get done]
- **Journey and step:** [which CUJ or journey, which step; "none tracked"
  is a valid answer]
- **Persona or group:** [the team's name for them, with the behavior that
  defines them]

And under "Assumptions and risks", any upstream or downstream dependency
the study doesn't cover.

## Challenges this lens adds

- "You're studying the export step. P2 and P5's problems start at import.
  Is the decision about export, or about the flow?"
- "Which of the company's three CUJs does this touch? If none, who's going
  to care about the answer?"
- "What's the job here? If someone got the numbers to their boss without
  ever opening your product, would that count as success for them?"
- "If the PM ships this, which other team's metric moves?"

## Keep it light

This lens is a few questions at framing and a few labels at analysis and
readout. It's not a separate deliverable. The "align on the problem"
workshop has a short step that maps the system with the team
(`workshops-stakeholder-workshops.md`). If the
researcher has answers, it takes a minute. If they don't, Magpie drafts
the guess, marks it as an assumption, and moves on.

---

Part of Magpie version 2026-11-04, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.
