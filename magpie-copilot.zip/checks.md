<!-- Magpie, combined for Copilot. Holds `checks-ai-assisted-research.md`, `checks-claim-strength.md`, `checks-ethics-and-consent.md`, `checks-guide-wording.md`, `checks-hypotheses.md`, `checks-release.md`, `checks-research-questions.md`, `checks-survey-wording.md`. -->

<!-- file: checks-ai-assisted-research.md -->

# Check: when AI runs part of the study

What to do when an AI tool moderates sessions, summarizes transcripts,
recruits participants, or is Magpie itself drafting findings. These tools
are useful enough to create false confidence, which is the risk; the checks
below are what keep the work research rather than something that looks like
it.

## 1. An AI moderator shapes answers

An AI running interviews follows the guide but phrases follow-ups,
sequences questions and acknowledges answers in ways that can narrow what
participants say. Participants are blunter with an AI, and also more
responsive to each question's framing, because there's no person to push
back against. The data comes out tidier and more convergent, and the
tidiness is the problem: it reflects the prompts more than the people.

- The moderator's instructions get the same wording check as a human
  guide (`checks-guide-wording.md`), item by item, before launch.
- The instructions set boundaries (topics in and out of scope) and a
  fallback for unclear answers: ask the participant to say more; don't
  rephrase or interpret.
- Pilot the moderator with two or three internal participants first.
- **Audit the first three transcripts in full** before more sessions run.
  Read the moderator's actual follow-ups. Look for leading phrasing, for
  off-script probes, and for participants converging on the same words,
  which signals shaping. If any of it shows, stop the study and revise the
  instructions. This gate is what makes AI-moderated data credible.

## 2. An AI summary is a first draft

A summary of transcripts reads like findings: confident, structured prose.
It isn't. It compresses what was said by pattern and frequency, without
the judgment about which moments matter for this decision, without
weighing the people who disagreed, and without telling a strong opinion
from passive agreement. The common failure is smoothing: six positive
participants and two seriously confused ones become "generally positive,
some minor confusion", and the two who may represent a real problem
disappear.

- Treat every AI summary, Magpie's own drafts included, as a draft that
  tells you which transcripts to read in full, not as a substitute for
  reading them.
- A human synthesis step sits between any AI output and anything a
  stakeholder sees. The tool finds the candidates; the researcher decides
  which matter and why. Magpie asks the researcher to confirm they've read
  the passages behind each top finding before drafting the readout, and
  logs "not confirmed" as a risk if they haven't.
- Every claim traces to specific participant moments with quotes and
  context. If it can't be traced, it doesn't go in.

## 3. Receipts

Traditional studies build an evidence trail by default: recordings,
timestamped notes, coded transcripts, synthesis documents that link claims
to data. When tools handle moderation and summarizing, that trail thins out
unless the researcher keeps it on purpose.

- Raw transcripts are stored alongside any summaries.
- **No finding goes into a stakeholder-facing document without receipts:**
  at least two traceable participant references (code and location) per
  directional claim, or a single case labeled as one.
- Where the tool links summary claims to timestamped quotes, use that; the
  feature only helps if someone actually follows the links.

## 4. Participant quality

Tools that make recruiting faster also make fraud easier: bots, people who
speed through for the incentive, people who paste AI-written answers. The
risk is low when participants come from your own verified user base and
high with third-party panels, whose incentive economics reward fraud.

- Assume some of the sample is compromised and plan to catch it before
  synthesis, not after.
- Read early transcripts, not just summaries. Watch for answers that are
  too clean, too fast, or too perfectly structured.
- Set a disqualification threshold and a replacement protocol in the plan,
  so removing someone doesn't stall the study.
- Platform fraud detection is worth having and doesn't replace judgment.
  Fast recruiting and good recruiting are different things.

## Basis

S10 (see `sources.md`): the five failure modes and their
mitigations, including the first-three-transcript audit, the human
synthesis step, receipts, and the fraud signals, come from the passage
recorded there. The wording and the fit to Magpie's stages are this
project's.

---

Part of Magpie version 2026-11-05, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: checks-claim-strength.md -->

# Check: claim strength

Run this over every finding before it leaves stage 7, and again over every
slide or paragraph of the readout and report. The question each time is:
does the wording match the evidence?

## Rules

1. **Say the numbers.** "6 of 8 participants" not "most". "41 of 120, 34%"
   not "a third". Vague quantities read as bigger than they are.
2. **Name the counter-evidence.** Every finding says who didn't fit and
   what they did instead. "All participants" is almost never true; check.
3. **Qualitative counts aren't rates.** Eight interviews tell you what
   exists and how it works, not how common it is. Write "participants
   described…" not "users want…". Never a percentage from under about
   thirty people.
4. **Strength label matches the evidence.**
   - Strong: consistent across most participants, or a statistically
     reliable result with the test named.
   - Moderate: a clear pattern with exceptions you can name.
   - Weak: few participants, one segment, mixed signals, or secondhand.

   Mixed signals get a reason before the label: two groups that differ
   (write a finding for each), people really divided (give each side's reasons), not enough data yet (say what would settle
   it), or something about the sessions (`stages-07-analyze.md` step 6a).

   Each label carries a confidence line with its reasons: how many, who
   they are against the target users, whether it was seen or said, and
   whether other sources agree (`lenses-confidence-and-priority.md`).
5. **Causes need more than correlation.** "People who used feature X
   renewed more" is not "feature X causes renewal". Say what's known and
   what would be needed to know more. The same goes for what participants
   believe about cause and effect. Interviews and surveys show what people
   think causes something, or doesn't; only a design that tests cause and
   effect, such as an experiment, can show it. Report the belief as theirs
   ("9 of 13 said violent games don't make players violent"), never as a
   fact ("Violent games don't make players violent"), and that includes
   finding titles, summaries and top-findings lines, which readers quote
   on their own.
6. **Quotes carry a code, not a conclusion.** Each quote has a participant
   code and a location. One quote illustrates; it doesn't prove. In a
   readout or report, the code comes with a short descriptor from the
   participant list, so the reader knows who is speaking: "— P3, finance
   manager, SMB". Use the role and the team's own segment names (company
   size or type, plan, region, end user or buyer), the ones that matter
   for this decision, or the team profile's quote label if it sets one.
   Never a name or a company name. If a combination would point to one
   person (the only CTO in the study), use a broader label and say so
   once (`operating.md`, "Personal details in the material").
7. **Secondhand stays secondhand.** A finding that rests on partner data or
   a stakeholder's account is labeled that way and can't be "strong" on
   its own.
8. **Confidence doesn't drift.** The strength on the slide is the strength
   in the record. Check every finding against the record before the
   readout.
9. **Recommendations stay inside the findings.** A recommendation that
   needs a fact the study didn't establish says so and marks that fact as
   an assumption.
10. **Absence of evidence is labeled.** "No participant mentioned X" is a
    finding about the sessions, not proof that X doesn't matter.
11. **Every finding has receipts.** At least two participant references
    with locations per directional claim, or a single case labeled as
    one. No receipts, no slide. Each count carries its own: "3 of 8 (P1 06,
    P5 06, P7 06)", one code per person counted, so a script can confirm
    the count matches the list and every line exists. The record and the
    report keep the codes; a slide can move them to the speaker notes or
    the appendix.
12. **A summary is not a finding.** Anything a tool produced from the
    transcripts, Magpie's drafts included, is a draft until a person has
    read the passages it rests on. Smoothing is the tell: "generally
    positive, some minor confusion" where two of eight were seriously
    stuck. `checks-ai-assisted-research.md`.
13. **Said isn't seen.** A claim about what people do that rests only on
    what they said they do or would do is moderate at most and says so
    ("participants said they…"). Same for a claim that rests only on
    buyers, admins or colleagues speaking for the users. Where saying and
    doing differ, both are reported.
14. **No other source isn't a weakness.** "First study on this; no other
    sources" is stated plainly and lowers nothing. Only a source that
    disagrees lowers the label.
15. **Key findings say what would prove them wrong.** Each finding the
    decision rests on carries a "Would be wrong if" line and at least one
    other explanation for the same evidence, each marked ruled out (with
    the evidence) or still open (with what would settle it). An open
    explanation that fits the evidence as well as the finding does means
    the finding can't be strong (`stages-07-analyze.md`, step 11a).

## Wording to replace

| Instead of | Write |
| --- | --- |
| Users want | 5 of 8 participants asked for |
| Everyone struggled | 4 of 5 participants failed task 2; P3 completed it |
| Proves | Suggests, supports, is consistent with |
| Significant (without a test) | Large, clear, noticeable, or the number itself |
| Many, most, some, a few | The count |
| It's clear that | (delete) |
| Users check the preview (from interviews) | 5 of 8 said they check the preview; in the task, 2 of them did |

## Words to look for

Go through the draft for these words, outside quotes from participants.
Each one is a sentence to reread, not an automatic error: keep it if it
reports what someone said ("P3 said it was because of the deadline") or
a tested result, and reword it otherwise. Where Magpie can run code,
`python3 scripts/wording_check.py findings.md` finds them; where it
can't, search for them by hand and say so in the record. Running this as
code rather than by eye follows claim-stress-tester (S102).

| Kind | Words | Fine when | Otherwise |
| --- | --- | --- | --- |
| Every or none | all, always, never, every, everyone, everybody, nobody, no one, none, without exception | the sentence gives the count, and it's true for every person | give the count and name who didn't fit |
| Cause | causes, caused, drives, drove, driven by, leads to, led to, results in, because of, due to | a test showed the cause, or it's a reason someone gave | say what's known: a pattern, or what people said |
| Vague amount | most, many, some, a few, several, the majority, nearly all, almost all, almost everyone, users want, customers want, people want | the sentence gives the count | replace with the count |
| Overclaiming | proves, proven, clearly, obviously, definitely, undeniably, it's clear that | never | "suggests", "supports", "is consistent with", or delete |
| Significant | significant, significantly | the test is named (a p-value, t-test, chi-square, confidence interval) | "large", "clear", or the number |

## Basis

Practitioner judgment, consistent with widely published guidance on
reporting qualitative and survey research. Rule 15 and the word search
as code take their idea from claim-stress-tester (S102); the rules and
word lists as written are Magpie's own. Sources will be added to
`sources.md` as they are checked.

---

Part of Magpie version 2026-11-05, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: checks-ethics-and-consent.md -->

# Check: ethics and consent

Run this at stage 5 for every study that involves people. Anything missing
here is a red flag at every challenge level.

## Consent

- Participants are told, in plain words: what the study is for, what will be
  recorded, who will see it, how long it's kept, and that they can stop or
  skip any question without losing their incentive.
- If an AI tool will moderate, transcribe, summarize or analyze the
  sessions (Magpie included), participants are told before the session
  starts, in plain words: which of these it does, and, for an AI
  moderator, that they'll be talking with an AI, not a person, and how to
  stop or reach a person. People decide differently about what they share
  when they know a tool will process it. Write that line into the plan's
  consent section yourself; don't ask whether the team's form already
  has one, and don't add an opt-out from AI analysis the team's own form
  doesn't offer. Don't ask the researcher whether transcripts may go into
  an AI tool, or whether participants agreed to it, at this stage or
  later: their consent process covers it. If the record shows a
  participant opted out of something, follow it without asking.
- Consent is confirmed before recording starts, and the confirmation is
  recorded or written down.
- When participants make their own recordings (photos, screenshots,
  voice notes, video, as in a diary study), they're told what not to
  capture (other people, children, ID, bank details, other people's
  messages on screen) and how to delete an entry.
- For anything beyond ordinary use of the findings (quotes in a public deck,
  video clips shown outside the team) ask separately.

## Participants who need extra care

Say what extra care is taken if the study involves:

- Children or young people.
- People in crisis, in medical settings, or dealing with a sensitive topic
  (money trouble, health, grief, safety).
- People in a dependent relationship with the company (employees, contractors,
  customers whose service depends on a relationship manager).
- People who may not fully understand what they're agreeing to.

Extra care usually means: a plainer consent conversation, an easy way to
stop, a less intrusive method, a second person involved, or not running the
study at all.

## Data handling

- Recordings and transcripts are stored somewhere with access control, not in
  a personal download folder.
- Participant names are replaced with codes (P1, P2) in anything that leaves
  the researcher's own files. Other identifying details in a quote (an
  email, an employer, a colleague's name) become placeholders such as
  [name] (`operating.md`, "Personal details in the material").
- A deletion date is set and written in the plan.
- Nothing personal goes in the study record, the research library or the
  team profile.

## Incentives and fairness

- Incentives are proportionate to time asked and don't pressure people to
  take part.
- Recruiting doesn't exclude people for convenience when the decision
  affects them.

## Honesty with participants

- No deception about the purpose of the study unless there's a strong,
  written reason and a debrief.
- Don't let participants believe the study is a sales conversation, a job
  interview or a support call.

## Basis

Practitioner judgment, consistent with published research ethics codes.
Sources will be added to `sources.md` as they are checked. Local law
and company policy take precedence over anything here.

---

Part of Magpie version 2026-11-05, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: checks-guide-wording.md -->

# Check: guide wording

Run this over every interview guide, usability test script, focus group
guide, concept test and set of diary prompts before it goes out, the
researcher's own included. For each item that fails, say which rule it broke and offer a rewrite.

## Rules

1. **Leading.** The question suggests the answer. *"How much easier was
   the new version?"* → *"Walk me through the last time you did this."*
2. **Loaded.** The question carries a judgment. *"What frustrates you about
   the dashboard?"* assumes frustration. → *"Tell me about the last time you
   used the dashboard."*
3. **Double-barreled.** Two questions in one. *"Was it fast and easy to
   find?"* → split into two.
4. **Hypothetical.** Asks people to predict themselves. *"Would you use a
   weekly summary?"* → *"How do you keep track of this now?"* Past behavior
   is evidence; predictions mostly aren't.
5. **Closed when it should be open.** *"Do you use filters?"* gets a yes.
   *"How do you narrow things down when there's too much?"* gets a story.
6. **Jargon or internal names.** Participants don't know your feature names
   or your acronyms. Use their words, or describe the thing.
7. **Too abstract.** *"What do you value in a tool?"* → *"Tell me about a
   tool you'd be annoyed to lose. What would you miss?"*
8. **Stacked.** A question followed by three sub-questions before the
   participant can answer. Ask one, wait, probe.
9. **Why without a cushion.** A bare "why?" can sound like a challenge.
   *"What was behind that?"* or *"Say more about that"* lands softer.
10. **Missing probes.** Each main question should have one or two follow-ups
    ready: *"What happened next?"*, *"Can you show me?"*, *"What did you do
    instead?"*

## Conversation flow

- **It sounds like a person talking.** The opening, the warm-up, every
  question and every move between sections are written as the moderator
  will say them, in short sentences they can read aloud in one breath.
- **Each topic change has a spoken transition.** Thank them, say where
  you're going next: *"Thanks, that's really helpful. Now I'd like to shift
  our focus to how you share reports with your team."* A heading alone
  isn't a transition.
- **One topic at a time.** Finish a topic before starting the next, and
  don't come back to it later unless you say why.
- **What they did before what they think.** Ask for the story of the last
  time before asking for opinions or ratings.
- **General before specific.** Broad questions about their work come
  before questions about one screen or feature, so the specific doesn't
  narrow what they tell you about the general.
- **Nothing gives away what comes later.** A question or task that names
  a feature you'll ask about unprompted later goes after that question.

## Also check

- The opening explains what's recorded, who sees it, and that they can stop
  at any time, in plain words.
- Warm-up questions are easy and about them, not the product.
- The hardest or most sensitive questions come after rapport, not first.
- The guide is timed, and the items that matter most come before the
  halfway point.
- For usability tests: tasks are scenarios ("you want to…") not
  instructions ("click the…"), and each has a written success criterion.

## Basis

Practitioner judgment, consistent with widely published interviewing
guidance. Sources will be added to `sources.md` as they are checked.

---

Part of Magpie version 2026-11-05, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: checks-hypotheses.md -->

# Check: hypotheses

Run this over the team's hypotheses at stage 3, before they go in the
record, and again whenever one is added later. A hypothesis is what the
team believes now; the study tests it, it doesn't set out to prove it. A
vague hypothesis can't be tested, so it quietly survives any result.

Show a result only for a hypothesis that needs work. For each one, say
which rule it broke and offer a rewrite, using the before-and-after table
(`operating.md`, "Show what you changed"). A hypothesis that passes gets
no comment.

## Rules

1. **A belief about people, not a task.** "We should test the bank step"
   is a plan. → "Owners stop at the bank step because they don't trust a
   new tool with bank access yet."
2. **Specific.** Says who, what they do, and where or when. "Users find
   setup hard" → "Owners of businesses under 20 staff stop setup at the
   bank-connection step in their first week."
3. **One idea at a time.** "The bank step is too early and the copy is
   confusing" is two. Split it, so each can be supported or not on its
   own.
4. **Says what would change the team's mind.** Name the result that
   would count against it: "If most owners who stop name a reason other
   than trust (no login to hand, a bank not supported), we drop this."
   A hypothesis nothing could disprove isn't one.
5. **Testable by this study.** Eight interviews can show whether a reason
   exists and what it looks like, not how common it is. If the
   hypothesis is about a rate, say so and point to the data that could
   test it (analytics, a survey).
6. **Held by someone.** Each names who holds it (the PM, design, sales,
   the team). It shows whose mind the study may change, and it keeps the
   hypothesis from reading as the researcher's own conclusion.
7. **Plain words.** No internal names a new team member would have to
   look up.

## Basis

Practitioner judgment. Rules 2 to 4 follow the common advice that a
hypothesis worth testing is specific and can be shown wrong. Sources will
be added to `sources.md` as they are checked.

---

Part of Magpie version 2026-11-05, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: checks-release.md -->

# Check: release

Run this before any output meant for other people is offered for the
researcher's yes: the readout and the report at stage 8, and also a
findings summary, a workshop summary, a persona, a journey map, a
research library entry, an opportunity brief, or anything else the
researcher says they'll share. Run it again if the destination changes.
The question it answers: can this leave the researcher's hands and go
where it's going without carrying a person with it?

## The destination

Ask once, with the stage's other questions, where the output goes after the
room:

- **The team:** the people who ran or sponsored the study.
- **The company:** anyone inside it, now or later, through a wiki, a
  library or a forwarded deck.
- **Outside:** customers, partners, a conference, a public post.

Until the researcher answers, run the check for the company. Most
research stays inside the company, and a deck travels further than the
room it was made for. If the researcher later says it's going outside,
run the check again for outside.

## What's allowed where

Every item is a blocking item at every challenge level. Fix it, say what
changed in one line, and only then ask for the yes.

| | Team | Company | Outside |
| --- | --- | --- | --- |
| Participants' names, emails, phone numbers, handles; colleagues' names | Never | Never | Never |
| Customers' or employers' company names | Only if the team profile allows | Only if the team profile allows | Never |
| Role descriptions | As written | Broadened where they point to one person | Broadened further: no mix of size, location and role that narrows to a few people |
| Quotes | Fine | Fine | Only with consent for use outside the company |
| Clips, screenshots, photos, faces, voices | As consent allows | As consent allows | Only with separate consent for that use; otherwise left out |
| Participant list, raw counts with line references, risks log, partner data | Fine | Appendix only | Left out |

- **Names.** Participants appear as codes (P1, P2) with a descriptor
  from the participant list. In a quote, a name, email or phone number
  becomes a placeholder such as [name] (`operating.md`, "Personal details
  in the material"). This holds for every destination and no team rule
  changes it.
- **Company names.** Customers' and employers' names become [company]
  unless the team profile's "Company names in internal outputs" line
  says they're allowed, and then only for the team and the company.
  Rules on this differ by country and by company, so the default is the
  strict one. Never outside.
- **One-person labels.** Where a descriptor, or a descriptor with a
  detail in the quote, would point to one person (the only CTO in the
  sample; the one small business in a given city), broaden it and say
  once why (standard 7.4).
- **Consent matches use.** A quote, a clip, a screenshot or a photo going
  beyond ordinary use of the findings has its own consent on record.
  Where it doesn't, the item comes out or goes back to the researcher to
  ask for consent (`checks-ethics-and-consent.md`).
- **Sensitive findings as agreed.** A finding that reflects on a person or
  a team is framed the way the researcher said in the "Before you build"
  answers. If they said nothing, it's framed for the destination and
  flagged in the reply.
- **Status on the document.** The document details block says Draft until
  the yes, and the destination appears in the details or the appendix, so a
  reader who forwards it can see where it was meant to go.

## How to check

Where Magpie can run code, save the output to a file and run
`python3 scripts/personal_details_check.py output.md --names "..."`,
passing the names Magpie noted in the material (participants,
colleagues, and companies unless the team profile allows them). It flags
emails, phone numbers, handles and those names. Pass the names on the
command line only; never write them to a file. Then read the output for
what code can't catch: one-person labels, consent and sensitive
findings. Where Magpie can't run code, do all of it by reading and say
so.

The independent review also asks whether anyone could be identified
(`review-independent-review.md`, question 11). Treat its points the same
way.

## What to say

One line naming the destination and the changes, in the same reply as the
draft: "Checked for the company: two employer names became [company], P7's
label is now 'technical leader, enterprise', and the Q3 screenshot is out
until there's consent for it." If nothing changed, say that in half a line.
Don't ask about any of it.

---

Part of Magpie version 2026-11-05, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: checks-research-questions.md -->

# Check: research questions

Run this over the research questions at stage 3, the researcher's own
included, before they go in the record. For each one that fails, say which
rule it broke and offer a rewrite. Research questions are what the study
must answer, not what participants are asked, but a flawed research
question produces a flawed guide.

## Rules

1. **One question at a time.** "Why do admins stall and what would help
   them?" is two. Split it, or make one primary and one secondary.
2. **Doesn't assume its answer.** "Why is the permissions step confusing?"
   assumes it is. → "What happens when admins reach the permissions
   step?"
3. **About people, not the product.** "Do users like the tracker?" →
   "How do people keep track of X today?"
4. **Open.** A question a yes or no answers ("Do admins invite others in
   week one?") is a metric to look up, not a research question. Ask how
   or why, or turn it into a hypothesis.
5. **Answerable by a study you could run.** Not "what will the market want
   in five years", and not a rate from eight interviews.
6. **Tied to the decision.** Each names the decision it serves. If the
   answer wouldn't change what the team does, it goes under "nice to know".
7. **Plain words.** No internal names a new team member would have to look
   up.

## Basis

Practitioner judgment, consistent with widely published guidance on
framing research questions. Sources will be added to `sources.md`
as they are checked.

---

Part of Magpie version 2026-11-05, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: checks-survey-wording.md -->

# Check: survey wording

Run this over every survey before it goes out. For each item that fails, say
which rule it broke and offer a rewrite.

## Item rules

1. **One idea per item.** *"The app is fast and reliable"* is two items.
2. **No leading or loaded wording.** *"How much do you enjoy the new
   design?"* assumes enjoyment. Ask neutrally: *"How would you rate the new
   design?"*
3. **Balanced scales.** As many positive as negative points, with a true
   midpoint if you offer one, and labels on every point or on the ends at
   least.
4. **Agree/disagree sparingly.** People lean toward agreeing. Where you can,
   ask the thing directly (*"How often do you…"*) instead of asking whether
   they agree with a statement.
5. **Answer options are complete and don't overlap.** Add "other" and
   "don't know" or "not applicable" where they're honestly possible.
6. **Ask about behavior over a specific period.** *"In the last 30 days,
   how many times…"* beats *"How often do you usually…"*.
7. **No jargon or internal names.** If you must name a feature, describe it.
8. **Ask only what you'll use.** Every item maps to a research question. If
   you won't analyze it, cut it.
9. **Sensitive items late and optional.** Demographics and anything personal
   go at the end, with a "prefer not to say".
10. **Open-ends have a purpose.** One or two, placed where a story helps.
    Don't make them required.

## Structure rules

- Screener first, and it screens on behavior, not on self-description.
- Group items by topic; move from general to specific.
- Length stated up front and honest. Under ten minutes unless there's a
  strong reason.
- Mobile-friendly: no grids wider than the screen.

## Analysis cautions

Say these to the researcher before the survey goes out, not after:

- A small or self-selected sample describes the people who answered, not the
  population. Say who answered.
- Differences between groups need enough people in each group to mean
  anything. Don't plan a cross-tab you can't fill.
- Don't claim a statistically significant difference unless a test was
  actually run, and even then say what it means in plain words.

## Basis

Practitioner judgment, consistent with widely published survey design
guidance. Sources will be added to `sources.md` as they are checked.

---

Part of Magpie version 2026-11-05, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.
