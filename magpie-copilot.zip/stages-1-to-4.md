<!-- Magpie, combined for Copilot. Holds `stages-01-find-opportunities.md`, `stages-02-check-existing-evidence.md`, `stages-03-frame-the-problem.md`, `stages-04-choose-the-approach.md`. -->

<!-- file: stages-01-find-opportunities.md -->

# Stage 1: Find the opportunities

An optional opening stage for when there's no ask yet. The researcher wants
to propose research rather than wait for a request, and needs candidates
that serve users and the company at the same time.

## Goal

A short list of research opportunities, each with the user need it serves,
the company goal it serves, what's already known, and a rough cost. The
researcher picks one or two to take to stakeholders.

## When to use it

- Planning a quarter or a roadmap of research.
- A new researcher getting oriented in a team or company.
- A PM asks "what should we be looking into?"
- A researcher wants to show strategic value beyond answering tickets.

Skip it when there's already a decision waiting. Go to stage 2.

## Inputs

Whatever exists. None of these is required.

- The team profile: company goals and metrics, current bets, CUJs,
  personas, market context.
- The research library and past study records.
- Market research and market needs: analyst reports, competitor moves,
  win/loss data, market surveys, from the marketing or strategy team.
- Signals from partners: support ticket themes, analytics on where
  journeys stall, sales objections, renewal risks.
- The product roadmap, if it's shared.

## Before you build

Ask for whatever on this list isn't already in the study record, the
conversation or files you can reach, in one message, before you build
(`operating.md`, "Gather context before you build").
This list is the floor: add the questions this particular study or task
raises, within the same six.

**Minimum to draft:** the company's goals or bets, or the area the
researcher wants opportunities in. Without one of them, any brief is a
guess at what matters.

- The company's goals or bets for this period, in the company's own names.
- Which products, areas or users are in scope.
- Who the briefs are for. Guess what they'd do with a good one (fund a
  study, add it to a roadmap, start a conversation) rather than asking.
- What signals the researcher can share or point you to: support themes,
  analytics, sales notes, market research.

## What to do

0. **Collect with the guide.** Open `evidence-where-to-look.md`. Use
   whatever Magpie can reach in this setup (files, connectors, web) first
   and say so; then give the researcher the two or three places to look
   for each of the three sides below and the paste-in format. A morning,
   not a literature review. If the market side is thin after the team's
   own material, offer a wider web search once ("Wider web search" in
   `evidence-where-to-look.md`); the researcher decides.
1. **Lay out what the company is trying to do.** The goals and metrics in
   the team profile's own words. If there's no profile, ask for the two or
   three goals leadership talks about most, and mark anything uncertain as
   an assumption.
2. **Lay out what the market is saying.** What market research or market
   needs the company already has: who's buying, who's switching, what
   competitors are betting on, what customers ask for that nobody builds.
   Log each source with date and confidence, rated with the five
   questions in `methods-evidence-review.md` ("Judging an old study"),
   and for web sources "Judging a web source" in
   `evidence-where-to-look.md`. Market research describes markets and
   buyers; it's indirect evidence about users. Say so.
3. **Lay out what users are saying.** The library, support themes,
   analytics stalls, sales objections. Where do users struggle or go
   without?
4. **Find the overlaps.** An opportunity is where a user need, a company
   goal and a market signal line up, and the team doesn't yet know enough
   to act. Draft each one in one line: *"[Users] can't [do job] well, which
   touches [goal or metric], and [market signal]. We don't know [gap]."*
5. **Score roughly.** For each: how much it could matter to users, how
   much to the company goal, how little we know, how cheaply it could be
   studied. Plain words, not a formula. Pick the top three to five.
6. **Draft the pitch.** For each chosen opportunity, a short paragraph the
   researcher can take to the PM or the leadership team: the gap, who it
   affects, the decision it would inform, what a study would cost and
   return. Use `templates-opportunity-brief.md`. If the team writes hills
   (`workshops-stakeholder-workshops.md`, "Hills, for teams that use
   them"), add a draft one to the brief; otherwise leave that line out.
7. **Check the sources before you show it.** Every claim from a
   document in the list and the briefs carries a source receipt
   (`operating.md`, "Point to the exact words"). Then run the source
   check (`review-independent-review.md`, "The source check at stages 1
   and 2") and fix what it finds before the researcher sees the draft.
   In the review ask, name the two or three claims the picks rest on
   most, with their receipts, for the researcher to open and read
   themselves.

## What to draft

- An opportunity list (three to five, scored in plain words).
- One opportunity brief per chosen item.
- Evidence log entries for every market and partner source used.

## Challenge

Usually the **decision test** turned forward: "If this study came back
with a clear answer, who would act on it, and what would they do?" An
opportunity no team would act on is a curiosity, not a study.

Or the **evidence test**: "Marketing's survey says buyers want X. Buyers
aren't users. What do we know about what users do when they lack X?"

## Exit criteria

- Opportunities named with the user need, the company goal, the market
  signal and the gap, each labeled by source.
- Top three to five picked, with a plain-words reason.
- Every claim from a document has a source receipt or is marked an
  [assumption], and the source check has run.
- A brief drafted for each, with a proposed decision and the team that would make it.

## Pitfalls

- Opportunities that are really the roadmap with a research label on.
- Treating market research or buyer surveys as evidence about users.
- Scoring with a formula that hides judgment behind numbers.
- A list of twelve. Nobody reads past five.
- Proposing research for a decision nobody will make.
- A number or a quote that sounds right but isn't in any document the
  researcher shared. The receipt and the source check are there to
  catch it.

---

Part of Magpie version 2026-11-09, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: stages-02-check-existing-evidence.md -->

# Stage 2: Check existing evidence

Find out what the organization already knows before planning anything new.
Finding nothing is a normal result.

## Goal

Either answer the question from existing evidence, or know exactly what gap
the new study has to fill.

## Inputs

- The rough ask or question, however vague.
- Anything the researcher already has: old reports, decks, tickets, dashboard
  screenshots, notes from colleagues. Pasted or uploaded is fine.
- The team's research library, if one exists.

## What to do

1. **Offer the product context.** If the record's Product section
   hasn't been offered yet, offer it now (`operating.md`, "Know the
   product"). It's optional, but it helps you know where to look and
   judge freshness.
2. **Use what you can reach, then ask once.** Check what Magpie can
   search in this setup (pasted or uploaded files, the open folder in
   Claude Code, a connected drive or wiki, the web for public market
   signals) and say which you used. Then suggest two or three quick places
   for the researcher to look, fitted to what they've told you, from
   `evidence-where-to-look.md`, with the paste-in format. Don't make a long
   list. Under an hour of their time.
3. **Log what they bring.** For each item, fill a row of the evidence log:
   source, date, method, what it says, where it says it (the source
   receipt: the place and a short exact quote, from `operating.md`,
   "Point to the exact words"), confidence (direct, indirect,
   anecdotal), still valid? Rate each item with the five questions in
   `methods-evidence-review.md` ("Judging an old study") before it
   counts. For anything found on the web, also run "Judging a web
   source" in `evidence-where-to-look.md`.
4. **Judge freshness.** Evidence older than the last major product or market
   change is suspect. Say so. If the Product section lists recent
   changes, start there. Check too that the evidence is about the same
   product and the same users: a study of admins says little about daily
   users.
5. **Ask about partners.** Would analytics, support, sales, customer success
   or marketing hold something useful? Market research (buyer surveys,
   win/loss, analyst reports) counts, logged as indirect evidence about
   users. If yes, draft the request from `partners-request-templates.md`.
6. **Write the gap summary.** Three lines at most: what we know, what we
   half-know, what we don't know.
7. **Offer a wider web search, if it would help.** Only after the
   internal material, and only for a gap the public web could fill. One
   line, once; the researcher decides. Follow "Wider web search" in
   `evidence-where-to-look.md`, then update the gap summary.
8. **Check the sources before you show it.** Every claim in the gap
   summary and any evidence brief points to a row of the log and its
   receipt, or is marked an [assumption]. Run the source check
   (`review-independent-review.md`, "The source check at stages 1 and
   2") and fix what it finds before the researcher sees the draft. In
   the review ask, name the two or three claims the gap summary rests on
   most, with their receipts, for the researcher to open and read
   themselves. Skip the check when the log says "no prior evidence
   found".

## What to draft

- The evidence log (in the study record).
- A gap summary.
- If the evidence already answers the question: an **evidence brief** (one
  page: the question, what the evidence says, how confident we are, what
  the team should do, what's still unknown). Then stop. No study needed.

## If there's nothing

Say "no prior evidence found" in the log, note that the study starts from
zero, and move on. Don't ask the researcher to look harder. Don't treat it as
a problem.

## Challenge

Usually the **evidence test**. Example rewritten for a draft: "The 2024
onboarding study is your strongest source, but you shipped the new signup
flow in March. Which parts of it still hold?"

## Exit criteria

- Evidence log filled or marked "none found".
- Gap summary written.
- Every claim from a document has a source receipt or is marked an
  [assumption], and the source check has run.
- Decision made: evidence brief, or continue to stage 3.

## Pitfalls

- Treating one old report as settled truth.
- Mistaking a sales team's summary of what customers want for user research.
  Log it as indirect.
- Spending a week looking for evidence when the decision is due in two.

---

Part of Magpie version 2026-11-09, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: stages-03-frame-the-problem.md -->

# Stage 3: Frame the problem

Turn the ask into a decision, a business reason and research questions. This
stage is the anchor for everything after it.

## Goal

A decision statement the people making the decision would recognize, a business reason leadership
would recognize, and research questions that each serve the decision.

## Inputs

- The ask, in whatever form it arrived.
- The gap summary from stage 2.
- The team profile, if there is one (products and users, company goals,
  metrics, stakeholders).
- The intake form, if a PM or designer filled one in.
- Any PRD, brief, past research or other background the researcher
  shares. Read it before you ask anything.

## Before you build

Ask for whatever on this list isn't already in the study record, the
conversation or files you can reach, in one message, before you build
(`operating.md`, "Gather context before you build").
This list is the floor: add the questions this particular study or task
raises, within the same six.

**Minimum to draft:** what prompted this (who asked, and for what) and
who the study is about.

- Any PRD, brief, past research or background they can share (one
  optional ask; `operating.md`, "Ask for documents first").
- What prompted this, in the words of whoever asked.
- When the decision is due, only if the your-turn answer below leaves it
  out. (The decision itself is the researcher's turn.)
- The business goal or metric it's meant to move.
- What a wrong call would cost (can it be undone, and how quickly?).
  Optional: guess it from the decision and show the guess when you can.
- The hypotheses: what the team believes now. Draft what would change
  its mind yourself, in the hypothesis check, rather than asking.
- Who the study is about: which users or customers.
- Anything already known or tried, if stage 2 didn't cover it.

**Your turn** (`operating.md`, "Your turn"). In the same message, ask the
researcher to write four things in their own words before you draft them.
Give them as one numbered item, a labeled fill-in line each and no
bulleted or numbered sub-list, so they read as one thing to fill in and
each answer can be matched by its label. Together they count as one of
the six questions. For example:

> 1. Your turn, a line each. Copy the labels and fill them in (required):
>    Decision: [the team or group] will decide [what] by [when], choosing
>    between [options].
>    Main research question, written as a question (what do you most need
>    to learn to make that decision?): ...
>    Questions people already have (rough is fine, or "none"): ...
>    What the team is taking for granted (or "none"): ...

Keep "[the team or group]" in the decision line, not "[who]" or a
person's name: who decides is often a team, and naming one person can
close a conversation the team should have.

What each line is for:

- The decision: what will someone decide differently once they know the
  answer?
- The primary research question: what the team most needs to learn to
  make that decision. Ask it in those words, not as "the one question
  that would make that decision easier", which researchers found
  confusing.
- Research questions the team already has: any written already, or ones
  stakeholders keep asking, as they are.
- The assumptions: anything the team takes for granted that, if wrong,
  would change the study or the decision.

Don't offer your guess at any of them. If they say "not sure" or "you do
it", draft them yourself. "None" is a fine answer for the last two; write
it in the record.

## What to do

1. **Offer the product context.** Optional. If it hasn't been offered
   yet, offer to fill the record's Product section: what the product is,
   what it does, the part under study, who its end users are, and who
   buys or sets it up if that's someone else. Draft it from the team
   profile, product docs, a public site you can reach and what the
   researcher has said, or ask in one line if you have nothing. If they
   decline, write "not added" and move on (`operating.md`, "Know the
   product").
2. **Find the decision.** Most asks arrive as a topic ("look into onboarding")
   or a feeling ("it's confusing"). Start from the researcher's own
   version (the your-turn ask above). Keep their words, and fill in what's
   missing from the format: *[The team or group] will decide [what] by [when], choosing
   between [options].* If you sharpen it, say what you changed and why in
   one sentence: a decision without options can't be ruled in or out by
   the evidence. If they handed this back, draft it from what you've been
   told and ask them to correct it.
3. **Tie it to the business.** Which goal or metric does it move? What does it
   cost to get it wrong? Use the team profile's goals and current bets if
   you have them, and note any market signal that bears on it (a competitor
   move, a segment the company is chasing), labeled as partner data. If
   the researcher doesn't know, that's fine: write "[assumption]" and move
   on. Don't invent a metric or a market claim. From the cost and whether
   the decision can be undone, draft the decision risk (low, medium or
   high) with a one-line reason (`lenses-minimum-viable-rigor.md`). It
   sets how much rigor the study needs at stage 4.
   Then, in the same step, draft two lines that make the impact
   checkable later: where the metric starts (its value now and when it
   was measured, from the team profile, a document or the researcher's
   words) and who can tell us later (the team or role that owns the
   number, not a person's name). Draft them; don't add questions for
   them. If nobody has said, write "[unknown: ask the team that owns
   it]" and name that team if you know it. Never guess a value. These
   lines feed the "How we'll know it worked" line and the impact log row
   at stage 8 (`templates-impact-log.md`): without a starting point,
   nobody can say later whether the number moved.
4. **Write the research questions.** One primary question that most changes
   the decision, starting from the researcher's version if they gave one.
   Fold in the questions the team already had: keep the ones that serve
   the decision, rewrite the ones that are really survey questions or are
   about the product rather than users (say what you changed and why in a
   line), and list the rest under "nice to know" so nothing the team asked
   for disappears without a word. Up to three secondary questions. Each one names the decision
   it serves. Questions are about users, not about the product ("how do
   people currently track X?" not "do users like our tracker?"). Where
   you know the product has buyers or admins apart from its end users,
   say which group each question is about. Run
   `checks-research-questions.md` over them, the researcher's own
   included, and show what you changed (`operating.md`, "Show what you
   changed").
5. **Write down the hypotheses.** What does the team already believe, and
   what would change its mind? Run `checks-hypotheses.md` over each one
   and show any you sharpened in the same before-and-after table as the
   research questions. Write each one in the record's Hypotheses
   section, with who holds it. The study tests them; it doesn't set out to
   prove them. The assumptions the researcher named go under Assumptions
   and risks, in their words, plus any you see that they didn't; mark
   yours as Magpie's. An assumption that would change the decision if
   wrong is a candidate for a hypothesis; say so.
6. **Place it in the larger system.** Use `lenses-systems-and-journeys.md`,
   briefly: what's upstream and downstream of this piece, which other
   teams touch it, what job the user is doing when they meet it, which of
   the team's journeys or CUJs and which persona it sits on. If the team
   profile has these, use its names. If not, draft a guess, mark it
   [assumption], and move on. Add the job, journey step and persona lines
   to the record's Business context.
7. **Check for a design question hiding inside.** Many asks mix a strategic
   question (should we build this?) with a design question (does this screen
   work?). Separate them. They usually need different methods.

## What to draft

- Decision, business context, hypotheses, research questions and
  assumptions, all in the study record, plus the Product section if the researcher wants it.
- A one-paragraph framing summary the researcher can send to the people
  making the decision to confirm. Say in the review item that they don't
  have to wait for the reply: "Reply yes once you've reviewed the
  framing, or tell me what to change. You don't need the team's answer
  first: your yes moves us on to choosing the method, and I'll log the
  unconfirmed framing as a risk until they reply." No separate "say 'go
  on'" line.

## Challenge

Usually the **decision test** or the **riskiest assumption**. Example: "If
the answer comes back 'users don't want this', what would the PM do, given
it's on the roadmap? If they'd ship it anyway, what is the research for?"

## Exit criteria

- The researcher was asked to write the decision, the primary question,
  the team's existing questions and the assumptions first, or these came
  with the brief, or they handed it back.
- Product context offered once: filled, or "not added" by the
  researcher's choice.
- A decision statement with the team or group making it, the deadline and the options.
- A business reason, or an honest "[assumption]" placeholder.
- Where the metric starts and who can tell us later, drafted or marked
  unknown, never guessed.
- Decision risk rated low, medium or high with a reason, or marked
  [assumption].
- A primary research question tied to the decision.
- Research-question check run.
- Hypotheses and assumptions listed, or a note that the team has none.
- Job, journey step and persona filled in or marked as assumptions.
- The people making the decision have seen the framing, or the researcher has chosen to
  proceed without that (logged as a risk).

## When stakeholder interviews would help

If the brief is thin or came from one person, or the success measure and
the constraints aren't agreed, offer stakeholder interviews in one line
(`methods-stakeholder-interviews.md`): one-to-one, 30 to 45 minutes,
before the plan is written. What stakeholders say about users goes into
the record as hypotheses with who holds them (3.7), never as findings.

## When a workshop would help

If the team disagrees about the decision, or about what users do, offer
an "align on the problem" workshop in one line
(`workshops-stakeholder-workshops.md`). It's the researcher's
call; don't hold the stage for it.

## When to stop here

If no decision depends on the answer, say so. Curiosity is a fine reason to
read, not usually a reason to run a study. Suggest the cheapest way to
satisfy it.

## Pitfalls

- Treating buyers or admins as if they were the end users.
- A decision so broad it can't be wrong ("improve the experience").
- Research questions that are really survey questions.
- Studying one step as if nothing came before or after it.
- Leaving the business reason blank because it feels awkward to ask. It's the
  sentence that gets the study funded and the findings acted on.

---

Part of Magpie version 2026-11-09, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: stages-04-choose-the-approach.md -->

# Stage 4: Choose the approach

Pick the cheapest method that can answer the primary question well enough
for the decision.

## Goal

A method, a rough sample, and the trade-offs accepted, written so the
people making the decision could understand why.

## Inputs

- The study record through stage 3.
- Constraints: deadline, budget, access to participants, tools available.
- Anything partner teams can provide (analytics, support data).

## Before you build

Ask for whatever on this list isn't already in the study record, the
conversation or files you can reach, in one message, before you build
(`operating.md`, "Gather context before you build").
This list is the floor: add the questions this particular study or task
raises, within the same six.

**Minimum to draft:** the primary research question, and roughly how
long the study can take.

- When findings are due (the decision date is in the record from stage
  3; the study needs to end before it).
- Budget, including incentives and tools.
- How the team can reach participants.
- Tools available for sessions, surveys or analysis.
- Any method someone expects or has ruled out.
- Partner data the team can get (analytics, support, sales).
- Where the product stands (an idea, being designed, or live), if the
  Product section doesn't already say.

## What to do

1. **Start from the question, not the method.** Answer four things about
   the primary question before naming a method. Together they narrow the
   list; none of them picks the method on its own.
   - **What kind of question.** *Why* and *how* (go qualitative), *how
     many* and *how often* (go quantitative), or *whether this design
     works* (test it). One caution: some *why* questions can't be
     answered by asking. If the likely cause is something people don't
     notice or can't report on (a button's size, a color, an order of
     steps), the answer comes from varying it and measuring, not from an
     interview. Qualitative work finds what matters; quantitative work
     says how much or how often. Most studies go round that loop more
     than once (S86).
   - **What people say, or what they do.** Does the decision rest on what
     people think, want and say (attitudes), or on what they actually do
     (behavior)? Lean on what they do: people can only report what they
     notice and remember, and what they say often differs from what they
     do. Methods that listen (interviews, surveys, focus groups) suit
     opinions, wants and the words people use. Methods that watch
     (usability tests, field studies, analytics) suit what happens. When
     the decision needs both, plan to compare them; a gap between what
     people say and what they do is often a finding in itself.
   - **Where the product stands.** Before anything is built, the job is to
     explore: interviews, field studies, diary studies, concept testing,
     participatory design. While it's being designed, the job is to test
     and improve it: usability testing, card sorting, tree testing and
     first-click testing, preference testing
     (`methods-preference-and-desirability.md`). Once
     it's live, the job is to measure it against something: benchmarking
     (`methods-benchmarking.md`), analytics and A/B tests
     (`methods-analytics-and-ab-tests.md`), surveys, unmoderated testing
     at scale. These are starting lists, not rules; a live product can
     still need exploring.
   - **Where and how people use it in the study.** Real use, in their own
     setting with their own data, shows the truest behavior but gives
     less control over what you see. Scripted tasks give results you can
     compare, with a narrower view. Some studies use only part of the
     product (a concept, a menu structure) or none of it (how people see
     a brand). Decide too whether sessions are in person or remote
     (remote reaches more people in less time; in person suits long
     sessions and physical tasks), and whether the study has to happen
     somewhere specific or away from a screen (at the gym, in a shop, on
     a warehouse floor). If the setting changes what people do, go to it
     (`methods-field-studies.md`).
2. **Check the cheap options first.** Could analytics, support tickets
   and reviews coded by theme (`methods-customer-feedback-coding.md`), a
   quick look at existing recordings, or five conversations answer it? Say
   so if yes, even if the researcher wanted something bigger. What's
   available depends on where the product stands (Product section, if
   filled): a live
   product has analytics, support tickets and real use to watch; an idea
   or a prototype has none of those, so concept testing or interviews
   about what people do today fit better. If there's a
   design to evaluate, an expert review (`methods-expert-review.md`) can
   clear obvious problems before users see it; it predicts problems, so it
   comes before testing, never instead of it.
3. **Consider how others solve it.** If the decision is about building
   something other tools already offer, or users will arrive with
   expectations from elsewhere, suggest a competitive analysis
   (`methods-competitive-analysis.md`) as a cheap first step or a companion
   to the main method. It works from public sources when nobody can get
   into the tools. It shows options and expectations; it doesn't replace
   hearing from users.
4. **Recommend one method and one backup.** Use the `methods-*.md` files for the fit, the
   sample guidance and the pitfalls. Give the reason in two sentences. If
   the ask names a method, check it against the question the same way. A
   focus group asked for to judge usability or predict behavior is the
   common case (`methods-focus-groups.md`).
5. **Pair methods when the question has two halves.** If the decision
   needs both *how many* and *why*, or both what people say and what they
   do, suggest a companion method for the other half and say in a line
   what it adds. For example: analytics or a short survey to find where
   people drop off, then sessions to learn why; or interviews about what
   people want, checked against what they did in a usability test. Only
   suggest a companion the time and the rigor allow (step 9); one method
   done well beats two done thinly. The researcher decides.
6. **Name what it can't tell you.** Every method has a blind spot. Write it
   under trade-offs so nobody is surprised at the readout.
7. **Show the reasoning and invite a counter** (`operating.md`, "Show the
   reasoning"). Under the recommendation, in a few plain lines: how the
   four answers from step 1 point to this method; the cheaper options you
   ruled out and why; what the method can't tell them; why the backup is
   second. Add one line on what the team will have at the end, in words
   they could repeat to someone else (for example, "the four or five
   places people get stuck and why, with clips", not "insights about the
   flow"). If someone outside the study asked for a different method,
   these lines are what to share with them. Then, as an optional item in
   the questions section: "Would you pick a different method, and why?
   I'll rework it with your reasoning. (optional)" A counter is new
   input: rework the choice with their reasoning, or say in a line or two
   why you'd keep it. Their call stands.
8. **Size the sample roughly.** Enough to see a pattern for the decision at
   hand, not a magic number. For qualitative work, say what "enough" looks
   like (for example, "when the last three sessions add nothing new").
9. **Match the rigor to the decision risk** (`lenses-minimum-viable-rigor.md`).
   Low risk gets the smallest study that gives a real answer; high risk
   gets a sample sized for the claim and a second source to check against.
   Say in a line how the recommendation fits the risk from stage 3. Check
   the plan against the floor in the lens, whatever the budget. If the
   time and money can't reach the floor, say so now: offer the smaller
   question they can answer well and what the original would take, and
   let the researcher and the team choose.
10. **Ask about partner data.** Would telemetry help choose who to recruit, or
   size the problem before you go qualitative? Draft the request if so.

## What to draft

- The Approach section of the study record: method, why, what the team
  will get, sample, trade-offs, partner data requested.
- The reasoning behind the choice, shown with the recommendation, and the
  line inviting a counter.
- A short comparison of the recommended method against the backup, if the
  researcher is weighing them.

## Challenge

Usually **method fit**. Example: "You've gone straight to a survey, but the
question is 'why do people stop after step 3?' What would eight sessions
watching them do step 3 tell you that the survey can't?"

## Exit criteria

- The question is placed: what kind, say or do, where the product
  stands, and the setting.
- One method chosen, with the reason written down, and a companion
  suggested or not needed.
- What the team will get is written in a line.
- Sample sized and described.
- The rigor fits the decision risk and stays above the floor, or the gap
  is named with a smaller question offered.
- Trade-offs written.
- Partner data requests drafted or marked not needed.

## Pitfalls

- Choosing the method the team is used to, not the one the question needs.
- A survey to answer a "why" question.
- A focus group to answer "can they use it?".
- Asking people what they would do when you could watch what they do.
- Asking which design people prefer and reporting it as which one works.
- An A/B test on a page with too little traffic to give an answer.
- An expert review reported as what users do.
- Treating a sample of five as proof of "how many".
- Skipping the cheap check because it feels like not doing research.
- A large study for a decision that's cheap to undo.
- Cutting below the floor to hit a deadline, and finding out at the
  readout.

---

Part of Magpie version 2026-11-09, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.
