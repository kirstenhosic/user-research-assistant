<!-- Magpie, combined for Copilot. Holds `stages-05-plan-the-study.md`, `stages-06-draft-the-guide.md`. -->

<!-- file: stages-05-plan-the-study.md -->

# Stage 5: Plan the study

Write the research plan: who, how, when, and how participants are protected.

## Goal

A plan a stakeholder can read in two minutes and a teammate could run from.

## Inputs

- The study record through stage 4.
- The team's rules on consent, recruiting, incentives and data handling, from
  the team profile if there is one.
- Calendar constraints.

## Before you build

Ask for whatever on this list isn't already in the study record, the
conversation or files you can reach, in one message, before you build
(`operating.md`, "Gather context before you build").
This list is the floor: add the questions this particular study or task
raises, within the same six.

**Minimum to draft:** the decision it serves and who the participants
are.

- The decision it serves, with its date.
- The research questions and hypotheses.
- Who the participants are. Propose how many from the method rather
  than asking.
- Where participants will come from.
- The team's rules for consent and recordings (for example a standard
  form, where recordings are kept, for how long).
- Incentives, if stage 4 didn't settle them.
- Dates when sessions can't run (holidays, team time off).
- Who moderates and takes notes.

If stages 3 and 4 aren't done yet, don't squeeze all of this into one
message. Frame the study and choose the method first, each with its own
questions and its own yes, then ask this list (`operating.md`, "A plan
from scratch goes stage by stage").

## What to do

1. **Draft the plan from `templates-research-plan.md`.** Fill every section
   from the record. Where something is unknown, follow `operating.md`,
   "Gather context before you build": a guess the researcher let stand is
   marked [assumption], and anything that can't be guessed (a date, a
   name, a budget) is a labeled blank such as "[recruiting start date]".
2. **Write the recruiting criteria.** Who's in, who's out, and why each
   criterion matters for the decision. Use the team's persona or segment
   names where they exist, always with the behavior that defines them.
   If the Product section names end users, start from them, and recruit
   buyers or admins only when the decision is about them, saying so. Include the
   people who tried and left if the decision depends on them.
3. **Check the sample for blind spots.** Which groups are missing? Does that
   matter for this decision? Write the answer under trade-offs either way.
   Include disabled participants and people who use assistive technology,
   with the lead time and access arrangements that takes, or say why not
   (`lenses-accessibility.md`).
4. **Plan for consent and data.** What participants are told, what's recorded,
   where it's stored, who can see it, when it's deleted. For a diary
   study, say how entries are captured and cover consent for each
   format (`methods-diary-studies.md`, "Ways to capture entries"). If an
   AI tool will moderate, transcribe, summarize or analyze the sessions,
   Magpie included, write the plain line participants are told about it
   (`checks-ethics-and-consent.md`), without asking whether their form
   has one. If the study touches
   anyone who might be vulnerable, say what extra care is taken. This is a
   red flag if missing.
5. **Set the timeline backwards from the decision deadline.** Readout date
   first, then analysis, then sessions, then recruiting. If it doesn't fit,
   use the smallest-study moves in `lenses-minimum-viable-rigor.md` first,
   since they save time without weakening the answer. Any cut that does
   weaken it goes under trade-offs with what it costs.
6. **Plan for participant quality.** Say where participants come from and
   how much fraud risk that carries (own verified users: low; third-party
   panels: high). Set the disqualification threshold and the replacement
   protocol now, so a bad participant costs an hour, not the study.
   `checks-ai-assisted-research.md`, section 4.
7. **If an AI tool will moderate sessions,** schedule the first-three-
   transcript audit in the timeline, with a stop point before the rest of
   the sessions run. `checks-ai-assisted-research.md`, section 1.
8. **Name the risks.** Pull every skipped challenge from the record into the
   plan's risks section, plus anything new.

## What to draft

- The research plan, as Markdown and Word (`operating.md`, "Files for the
  team").
- The recruiting screener questions, if recruiting is needed.
- An updated study record (Approach and Assumptions and risks).

## Challenge

Usually **sample blind spot**. Example: "Everyone on your list is an admin
who set the product up. The decision is about daily users who didn't. What
would you miss without them?"

## Exit criteria

- A complete plan with no unexplained placeholders.
- Consent and data handling covered.
- Disabled participants included, with access arrangements, or the reason
  they aren't written under trade-offs.
- Timeline fits the decision deadline, or the gap is named.
- Every cut made to fit time or budget is listed with what it costs.
- Risks listed, including skipped challenges.

## Pitfalls

- A plan that lists activities but never says why they answer the question.
- Recruiting whoever's easiest to reach.
- Consent treated as a form to sign rather than a conversation.
- Recruiting from a panel with no plan for the participants who turn out
  to be bots or speed-runners.
- A timeline that ends the day the decision is due, with no time for the
  team to absorb the findings.

---

Part of Magpie version 2026-11-04, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.

<!-- file: stages-06-draft-the-guide.md -->

# Stage 6: Draft the guide or instrument

Write the thing the researcher will put in front of participants: an
interview guide, a usability test script, a survey, diary prompts, a
focus group guide or a concept test.

## Goal

An instrument that answers the research questions, asks nothing it doesn't
need, and leads nobody.

## Inputs

- The study record through stage 5.
- The method guide from the `methods-*.md` files.
- The template for the instrument from the `templates-*.md` files.

## Before you build

Ask for whatever on this list isn't already in the study record, the
conversation or files you can reach, in one message, before you build
(`operating.md`, "Gather context before you build").
This list is the floor: add the questions this particular study or task
raises, within the same six.

**Minimum to draft:** the research questions, and what kind of
instrument it is (interview, usability test, survey or diary).

- How long each session runs. Take the format (moderated or not, remote
  or in person) from the plan, or guess it and show the guess.
- What participants will see or use: a prototype, the live product, a
  concept, or nothing.
- Which topic must not be lost if a session runs short. Take the
  hypotheses to test from the record; ask only if there are none.
- The words participants use for the product and its features, if they
  differ from the team's.
- Anything off limits: topics, unreleased features, legal or brand rules.
- Who will run the sessions: the researcher, a teammate, a PM, or an AI
  tool.

## What to do

1. **Map every question to a research question.** Each item in the guide
   should serve a research question from the record. If it doesn't, cut it
   or move it to a "nice to have" list at the end.
2. **Draft from the template.** Opening, warm-up, the main questions, probes,
   closing. For usability tests: scenario, tasks, success criteria, what to
   observe. For surveys: screener, sections, item wording, response scales.
   For diaries: the entry prompt, its required and optional formats, and
   what not to capture (`methods-diary-studies.md`, "Ways to capture
   entries").
   **Write anything the moderator says the way a person speaks:** the
   opening, the warm-up, every question, and a spoken transition each
   time the topic changes ("Thanks, that's really helpful. Now I'd like to
   shift our focus to how you set up your team."). Short sentences the
   moderator can read aloud as written, not headings or notes. Survey and
   diary intros and section openers get the same plain, friendly voice.
3. **Fit it to the product.** Base tasks and scenarios on what the
   product does and the part under study (Product section, if filled, or
   what the researcher has told you), so they match what participants can
   actually do. In anything participants hear, use
   their words, not the team's internal feature names. If it's a
   prototype, say in the moderator notes what works and what doesn't.
4. **Show the map and invite a counter** (`operating.md`, "Show the
   reasoning"). Under the draft, a short table: each question or task,
   the research question it serves, and why it sits where it does (easy
   before hard, what they did before what they think, general before
   specific, sensitive late, tasks ordered so one doesn't give away the
   next). Then, as an optional item in the questions section: "Would you
   order it differently or cut something, and why? I'll rework it with
   your reasoning. (optional)" A counter is new input: rework the guide
   with their reasoning, or say in a line or two why you'd keep it. Their
   call stands.
5. **Run the wording check.** Use `checks-guide-wording.md` for interviews,
   tests, focus groups, concept tests and diary prompts, and
   `checks-survey-wording.md` for surveys. Fix what it catches and say what
   you fixed.
6. **Run the question review** (`review-question-review.md`). It's
   required. Start it without waiting to be asked. Where you can start a
   separate agent, run it before you show the draft and wait for it, so
   the researcher sees one reviewed draft (`operating.md`, "Wait for the
   review, then send one message"). Otherwise give the researcher the
   text to paste and say when to bring the result back. Fix what it got
   right and say why you disagree with the rest.
7. **Add the moderator notes.** What to do if a participant says "it's fine"
   to everything, runs short, runs long, or gets upset.
8. **Time it.** Estimate the length. If it runs over, say what to cut and
   why those items matter least.
9. **Suggest a pilot.** One or two pilot sessions catch most problems. Say
   what to watch for in the pilot.
10. **Check it works with assistive technology.** If participants use a
   screen reader, magnification or voice control, try the instrument or
   prototype with it before the sessions (`lenses-accessibility.md`).

## What to draft

- The instrument, from the right template, opening with the document
  details, as a Markdown file and a Word file (`operating.md`, "Files for
  the team").
- For interviews, usability tests and diary studies, a note-taking sheet
  (`templates-notes-sheet.md`) as an Excel file: one row per participant,
  one column per research question, and a summary row.
- The question map: what each item serves and why it sits where it does.
- A list of what the wording check and the question review caught and
  changed.
- An updated Instruments section in the study record.

## If an AI tool will moderate

The moderator's instructions are a guide and get the same wording check.
Add the boundaries (what's in and out of scope) and the fallback for
unclear answers ("ask them to say more; don't rephrase or interpret"), and
plan to read the first three transcripts in full before the rest run.
`checks-ai-assisted-research.md`, section 1.

## Challenge

Usually the **guide pressure test**. Example: "Question 4 asks 'how much
easier is the new flow?' That tells people the answer. What if you asked them
to walk you through the last time they used it?"

## Red flags

Always raise a leading, loaded or double-barreled question, even at "light".

## Exit criteria

- Every item maps to a research question.
- Wording check run and fixes made.
- Question review run and each point fixed or answered, and the status
  line shows it as done. If the researcher is running it in another chat
  and hasn't brought it back, it's listed as waiting in the record and the
  status line.
- Everything the moderator says is written to be said aloud, with a spoken
  transition at each change of topic.
- Moderator notes present.
- The instrument given as a Word file as well as Markdown, or the
  researcher told how to get one, with its document details filled in or
  labeled blank.
- Note-taking sheet given, for interviews, tests and diary studies.
- Pilot planned or deliberately skipped (logged as a risk).

## Pitfalls

- Asking people to predict their future behavior ("would you use…?") when
  you could ask about their past behavior.
- Questions that are really the product team's hopes with a question mark.
- A guide so long the best material comes after the participant is tired.
- No probes, so every answer stays at the surface.
- Topic headings with no spoken line, so the moderator improvises the
  transition or skips it and the participant is jolted from one subject to
  the next.

---

Part of Magpie version 2026-11-04, made by Kirsten Hosic (https://github.com/kirstenhosic/user-research-assistant). MIT License.
